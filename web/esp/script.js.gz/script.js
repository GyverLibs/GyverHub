function render_main(v){head_cont.innerHTML=`
<div class="title" id="title_cont">
<div class="title_inn">
<div id="title_row" class="title_row" onclick="back_h()">
<span class="icon i_hover back_btn" id="back"></span>
<span><span id="title"></span><sup id="conn"></sup><span class='version' id='version'>${v}</span></span>
</div>
<div class="head_btns">
<span id='head_err' style="display:none"><strike>MQTT</strike></span>
<span class="icon i_hover" id='icon_refresh' onclick="refresh_h()"></span>
<span class="icon i_hover" id='icon_fsbr' style="display:none" onclick="fsbr_h()"></span>
<span class="icon i_hover" id='icon_info' style="display:none" onclick="info_h()"></span>
<span class="icon i_hover" id='icon_cfg' style="display:none" onclick="config_h()"></span>
</div>
</div>
</div>
`;cli_cont.innerHTML=`
<div class="cli_block">
<div class="cli_area" id="cli"></div>
<div class="cli_row">
<span class="icon cli_icon"></span>
<input type="text" class="cfg_inp cli_inp" id="cli_input" onkeydown="checkCLI()">
<button class="icon cfg_btn cli_icon cli_enter" onclick="sendCLI()"></button>
</div>
</div>
`;footer_cont.innerHTML=`
<div class="footer_inner">
<a href="https://alexgyver.ru/support_alex/" target="_blank"><span class="icon info_icon info_icon_u"></span>Support</a>
<a href="test.html" target="_blank"><span class="icon info_icon info_icon_u"></span>Test</a>
<a href="https://github.com/GyverLibs/GyverHUB/wiki" target="_blank"><span class="icon info_icon info_icon_u"></span>Docs</a>
</div>
`;main_cont.innerHTML=`
<div class="main_inn">
<div id="devices" class="main_col"></div>
<div id="controls" class="main_col" style="max-width:unset"></div>
<div id="info" class="main_col">
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Settings</label>
</div>
<div class="cfg_row">
<label>Console</label>
<label class="switch"><input type="checkbox" id="info_cli_sw" onchange="showCLI(this.checked);save_devices()">
<span class="slider"></span></label>
</div>
<div class="cfg_row">
<label>Break Widgets</label>
<label class="switch"><input type="checkbox" id="info_break_sw" onchange="devices[focused].break_widgets=this.checked;save_devices()">
<span class="slider"></span></label>
</div>
<div class="cfg_row">
<label>Show names</label>
<label class="switch"><input type="checkbox" id="info_names_sw" onchange="devices[focused].show_names=this.checked;save_devices()">
<span class="slider"></span></label>
</div>
</div>
<div class="cfg_col" id="info_topics">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Topics</label>
</div>
</div>
<div class="cfg_col" id="info_version">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Version</label>
</div>
</div>
<div class="cfg_col" id="info_esp">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>ESP info</label>
</div>
</div>
</div>
<div id="fsbr" class="main_col">
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>FS Browser</label>
</div>
<div id="fsbr_inner"></div>
<div class="cfg_row">
<button onclick="format_h()" class="c_btn btn_mini">Format</button>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Upload</label>
</div>
<div class="upload_row">
<input class="cfg_inp upl_input" type="text" id="file_upload_path" value="/">
<input type="file" id="file_upload" style="display:none" onchange="uploadFile(this)">
<button id="file_upload_btn" onclick="file_upload.click()" class="c_btn upl_button">Upload</button>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>OTA FILE</label>
</div>
<div class="cfg_row">
<div>
<input type="file" id="ota_upload" style="display:none" onchange="uploadOta(this, 'flash')">
<button onclick="ota_upload.click()" class="c_btn btn_mini">Flash</button>
<input type="file" id="ota_upload_fs" style="display:none" onchange="uploadOta(this, 'fs')">
<button onclick="ota_upload_fs.click()" class="c_btn btn_mini">Filesystem</button>
</div>
<label style="font-size:18px" id="ota_label">IDLE</label>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>OTA URL</label>
</div>
<div class="upload_row">
<input class="cfg_inp upl_input" type="text" id="ota_url_f" value="http://url_to_flash">
<button id="ota_url_btn" onclick="otaUrl(ota_url_f.value,'flash')" class="c_btn upl_button">Flash</button>
</div>
<div class="upload_row">
<input class="cfg_inp upl_input" type="text" id="ota_url_fs" value="http://url_to_filesystem">
<button id="ota_url_btn" onclick="otaUrl(ota_url_fs.value,'fs')" class="c_btn upl_button">FS</button>
</div>
</div>
</div>
<div id="config" class="cfg_in">
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Search</label>
<div>
<button class="icon cfg_btn_tab" onclick="discover_all()" title="Find new devices"></button>
</div>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label id="ws_label"><span class="icon cfg_icon"></span>WS</label>
<label class="switch"><input type="checkbox" id="use_ws" onchange="update_cfg(this)"><span class="slider"></span></label>
</div>
<div id="ws_block" style="display:none">
<div class="cfg_row" id="http_only_http" style="display:none">
<span style="color:#c60000">Works only on <strong class="span_btn" onclick="window.location.href = window.location.href.replace('https', 'http')">HTTP</strong>!</span>
</div>
<div id="http_settings">
<div class="cfg_row">
<label class="cfg_label">My IP</label>
<div class="cfg_inp_row cfg_inp_row_fix">
<input class="cfg_inp" type="text" id="client_ip" onchange="update_cfg(this)">
<div class="cfg_btn_block">
<button class="icon cfg_btn" onclick="update_ip();update_cfg(EL('client_ip'))"></button>
</div>
</div>
</div>
<div class="cfg_row">
<label>Netmask</label>
<select class="cfg_inp c_inp_block с_inp_fix" id="netmask" onchange="update_cfg(this)"></select>
</div>
<div class="cfg_row">
<label class="cfg_label">Add by IP</label>
<div class="cfg_inp_row cfg_inp_row_fix">
<input class="cfg_inp" type="text" value="192.168.1.1" id="ws_manual_ip">
<div class="cfg_btn_block">
<button class="icon cfg_btn" onclick="manual_ws_h(ws_manual_ip.value)"></button>
</div>
</div>
</div>
<div class="cfg_row">
<label>HTTP hook</label>
<label class="switch"><input type="checkbox" id="use_hook" onchange="update_cfg(this)"><span class="slider"></span></label>
</div>
<span class="notice_block">Disable: <u>${browser()}://flags/#block-insecure-private-network-requests</u></span>
</div>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Settings</label>
</div>
<div class="cfg_row">
<label class="cfg_label">Prefix</label>
<div class="cfg_inp_row cfg_inp_row_fix">
<input class="cfg_inp" type="text" id="prefix" onchange="update_cfg(this)">
</div>
</div>
<div class="cfg_row">
<label class="cfg_label">Client ID</label>
<div class="cfg_inp_row cfg_inp_row_fix"><input class="cfg_inp" type="text" id="hub_id" onchange="update_cfg(this)" oninput="if(this.value.length>8)this.value=this.value.slice(0,-1)">
</div>
</div>
<div class="cfg_row">
<label class="cfg_label">Theme</label>
<select class="cfg_inp c_inp_block с_inp_fix" id='theme' onchange="update_cfg(this)"></select>
</div>
<div class="cfg_row">
<label class="cfg_label">Main Color</label>
<select class="cfg_inp c_inp_block с_inp_fix" id='maincolor' onchange="update_cfg(this)"></select>
</div>
<div class="cfg_row">
<label class="cfg_label">Font</label>
<select class="cfg_inp c_inp_block с_inp_fix" id='font' onchange="update_cfg(this)"></select>
</div>
<div class="cfg_row">
<label class="cfg_label">UI Width</label>
<div class="cfg_inp_row cfg_inp_row_fix">
<input class="cfg_inp" type="number" id="ui_width" onchange="update_cfg(this);updateTheme()">
</div>
</div>
<div class="cfg_row">
<label class="cfg_label">Settings</label>
<div>
<button class="c_btn btn_mini" onclick="cfg_export()">Export</button>
<button class="c_btn btn_mini" onclick="cfg_import()">Import</button>
</div>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label id="pin_label"><span class="icon cfg_icon"></span>PIN</label>
<label class="switch"><input type="checkbox" id="use_pin" onchange="update_cfg(this)"><span class="slider"></span></label>
</div>
<div id="pin_block" style="display:none">
<div class="cfg_row">
<label class="cfg_label">PIN</label>
<div class="cfg_inp_row cfg_inp_row_fix"><input class="cfg_inp" type="password" pattern="[0-9]*" inputmode="numeric"
id="hub_pin" onchange="this.value=this.value.hashCode();update_cfg(this)" oninput="check_type(this)">
</div>
</div>
</div>
</div>
<div class="cfg_col">
<div class="cfg_info">
Contribution:
<a href="https://github.com/Simonwep/pickr" target="_blank">Pickr</a>
<a href="https://github.com/mqttjs/MQTT.js" target="_blank">MQTT.js</a>
<a href="https://github.com/ghornich/sort-paths" target="_blank">sort-paths</a>
<a href="https://fontawesome.com/v5/cheatsheet/free/solid" target="_blank">Fontawesome</a>
</div>
</div>
</div>
<div id="password" class="main_col">
<div class="pass_inp_inner">
<input class="cfg_inp pass_inp" type="number" pattern="[0-9]*" inputmode="numeric" id="pass_inp" oninput="pass_type('')">
</div>
<div class="cfg_row pass_inner">
<button class="c_btn pass_btn" onclick="pass_type(1)">1</button>
<button class="c_btn pass_btn" onclick="pass_type(2)">2</button>
<button class="c_btn pass_btn" onclick="pass_type(3)">3</button>
</div>
<div class="cfg_row pass_inner">
<button class="c_btn pass_btn" onclick="pass_type(4)">4</button>
<button class="c_btn pass_btn" onclick="pass_type(5)">5</button>
<button class="c_btn pass_btn" onclick="pass_type(6)">6</button>
</div>
<div class="cfg_row pass_inner">
<button class="c_btn pass_btn" onclick="pass_type(7)">7</button>
<button class="c_btn pass_btn" onclick="pass_type(8)">8</button>
<button class="c_btn pass_btn" onclick="pass_type(9)">9</button>
</div>
<div class="cfg_row pass_inner">
<button class="c_btn pass_btn empty_b"></button>
<button class="c_btn pass_btn" onclick="pass_type(0)">0</button>
<button class="c_btn pass_btn red_btn" onclick="pass_inp.value=pass_inp.value.slice(0, -1)">&lt;</button>
</div>
</div>
</div>
<div id="bottom_space"></div>
`;}
const app_title='GyverHUB';const version_notes='Добавлены Canvas API и Gauge. Требуется библиотека версии от 25.05.2023';const ota_url='hub.gyver.ru/ota/projects.json';const non_esp='';const app_version='0.22b';const log_enable=true;const log_network=false;const info_labels_version={info_lib_v:'Library',info_firm_v:'Firmware',};const info_labels_esp={info_mode:'WiFi Mode',info_ssid:'SSID',info_l_ip:'Local IP',info_ap_ip:'AP IP',info_mac:'MAC',info_rssi:'RSSI',info_uptime:'Uptime',info_heap:'Free Heap',info_sketch:'Sketch (Free)',info_flash:'Flash Size',info_cpu:'Cpu Freq.',};const info_labels_topics={info_id:'ID',info_set:'Set',info_read:'Read',info_get:'Get',info_status:'Status',};const colors={ORANGE:0xd55f30,YELLOW:0xd69d27,GREEN:0x37A93C,MINT:0x25b18f,AQUA:0x2ba1cd,BLUE:0x297bcd,VIOLET:0x825ae7,PINK:0xc8589a,};const fonts=['monospace','system-ui','cursive','Arial','Verdana','Tahoma','Trebuchet MS','Georgia','Garamond',];const themes={DARK:0,LIGHT:1};const theme_cols=[['#1b1c20','#26272c','#eee','#ccc','#141516','#444','#0e0e0e','dark','#222','#000'],['#eee','#fff','#111','#333','#ddd','#999','#bdbdbd','light','#fff','#000000a3']];function getMime(name){const mime_table={'bin':'application/octet-stream','bmp':'image/bmp','csv':'text/csv','gz':'application/gzip','gif':'image/gif','jpeg':'image/jpeg','jpg':'image/jpeg','json':'application/json','png':'image/png','txt':'text/plain','wav':'audio/wav','xls':'application/vnd.ms-excel','xml':'application/xml',};let ext=name.split('.').pop();if(ext in mime_table)return mime_table[ext];else return'text/plain';}
function EL(id){return document.getElementById(id);}
function log(text){let texts=text.toString();if(!log_network&&(texts.indexOf('discover')>0||texts.startsWith('Post')||texts.startsWith('Got')))return;console.log(text);}
function window_ip(){return window.location.href.split('/')[2].split(':')[0];}
function openURL(url){window.open(url,'_blank').focus();}
function isSSL(){return window.location.protocol=='https:';}
function isLocal(){return window.location.href.startsWith('file')||checkIP(window_ip());}
function isPWA(){return(window.matchMedia('(display-mode: standalone)').matches)||(window.navigator.standalone)||document.referrer.includes('android-app://');}
function isESP(){return!non_esp;}
String.prototype.hashCode=function(){if(!this.length)return 0;let hash=new Uint32Array(1);for(let i=0;i<this.length;i++){hash[0]=((hash[0]<<5)-hash[0])+this.charCodeAt(i);}
return hash[0];}
function intToCol(val){return"#"+Number(val).toString(16).padStart(6,'0');}
function intToColA(val){return"#"+Number(val).toString(16).padStart(8,'0');}
function colToInt(str){return parseInt(str.substr(1),16);}
function random(min,max){return Math.floor(Math.random()*(max-min+1)+min)}
function randomChar(){let code;switch(random(0,2)){case 0:code=random(48,57);break;case 1:code=random(65,90);break;case 2:code=random(97,122);break;}
return String.fromCharCode(code);}
function notSupported(){alert('Browser not supported');}
function browser(){if(navigator.userAgent.indexOf("Opera")!=-1||navigator.userAgent.indexOf('OPR')!=-1)return'opera';else if(navigator.userAgent.indexOf("Edg")!=-1)return'edge';else if(navigator.userAgent.indexOf("Chrome")!=-1)return'chrome';else if(navigator.userAgent.indexOf("Safari")!=-1)return'safari';else if(navigator.userAgent.indexOf("Firefox")!=-1)return'firefox';else if((navigator.userAgent.indexOf("MSIE")!=-1)||(!!document.documentMode==true))return'IE';else return'unknown';}
function disableScroll(){TopScroll=window.pageYOffset||document.documentElement.scrollTop;LeftScroll=window.pageXOffset||document.documentElement.scrollLeft,window.onscroll=function(){window.scrollTo(LeftScroll,TopScroll);};}
function enableScroll(){window.onscroll=function(){};}
function refreshSpin(val){if(val)EL('icon_refresh').classList.add('spinning');else EL('icon_refresh').classList.remove('spinning');}
function resize_h(){showGauges();}
let popupT1=null,popupT2=null;function showPopup(text,color='#37a93c'){if(popupT1)clearTimeout(popupT1);if(popupT2)clearTimeout(popupT2);EL('notice').innerHTML=text;EL('notice').style.background=color;EL('notice').style.display='block';EL('notice').style.animation="fade-in 0.5s forwards";popupT1=setTimeout(()=>{popupT1=null;EL('notice').style.display='none'},3500);popupT2=setTimeout(()=>{popupT2=null;EL('notice').style.animation="fade-out 0.5s forwards"},3000);}
function showPopupError(text){showPopup(text,'#a93737');}
function showErr(v){EL('head_cont').style.background=v?'var(--err)':'var(--prim)';}
function getLocalIP(){return new Promise(function(resolve,reject){var RTCPeerConnection=window.webkitRTCPeerConnection||window.mozRTCPeerConnection;if(!RTCPeerConnection)reject('Not supported');var rtc=new RTCPeerConnection({iceServers:[]});var addrs={};addrs["0.0.0.0"]=false;function grepSDP(sdp){var hosts=[];var finalIP='';sdp.split('\r\n').forEach(function(line){if(~line.indexOf("a=candidate")){var parts=line.split(' '),addr=parts[4],type=parts[7];if(type==='host'){finalIP=addr;}}else if(~line.indexOf("c=")){var parts=line.split(' '),addr=parts[2];finalIP=addr;}});return finalIP;}
if(1||window.mozRTCPeerConnection){rtc.createDataChannel('',{reliable:false});};rtc.onicecandidate=function(evt){if(evt.candidate){var addr=grepSDP("a="+evt.candidate.candidate);resolve(addr);}};rtc.createOffer(function(offerDesc){rtc.setLocalDescription(offerDesc);},function(e){return;});});}
function update_ip(){if(!Boolean(window.webkitRTCPeerConnection||window.mozRTCPeerConnection))notSupported();else getLocalIP().then((ip)=>{if(ip.indexOf("local")>0)alert(`Disable WEB RTC anonymizer: ${browser()}://flags/#enable-webrtc-hide-local-ips-with-mdns`);else EL('client_ip').value=ip;});}
function checkIP(ip){return Boolean(ip.match(/^((25[0-5]|(2[0-4]|1[0-9]|[1-9]|)[0-9])(\.(?!$)|$)){4}$/));}
function intToOctets(ip){let o1=(ip>>>24)&0xff;let o2=(ip>>>16)&0xff;let o3=(ip>>>8)&0xff;let o4=ip&0xff;return(o1+'.'+o2+'.'+o3+'.'+o4);}
function getIPs(){let ip=EL('client_ip').value;if(!checkIP(ip)){showPopupError('Wrong IP!');return null;}
let ip_a=ip.split('.');let sum_ip=(ip_a[0]<<24)|(ip_a[1]<<16)|(ip_a[2]<<8)|ip_a[3];let cidr=Number(EL('netmask').value);let mask=~(0xffffffff>>>cidr);let network=0,broadcast=0,start_ip=0,end_ip=0;if(cidr===32){network=sum_ip;broadcast=network;start_ip=network;end_ip=network;}else{network=sum_ip&mask;broadcast=network+(~mask);if(cidr===31){start_ip=network;end_ip=broadcast;}else{start_ip=network+1;end_ip=broadcast-1;}}
let ips=[];for(let ip=start_ip;ip<=end_ip;ip++){ips.push(intToOctets(ip));}
return ips;}
let devices={};let devices_t={};let controls={};let focused=null;let touch=0;let pressId=null;let pickers={};let dup_names=[];let gauges={};let wid_row_id=null;let wid_row_count=0;let wid_row_size=0;let btn_row_id=null;let btn_row_count=0;let dis_scroll_f=false;function save_devices(){localStorage.setItem('devices',JSON.stringify(devices));}
function load_devices(){if(localStorage.hasOwnProperty('devices')){devices=JSON.parse(localStorage.getItem('devices'));}}
function addDevice(id){EL('devices').innerHTML+=`<div class="device offline" id="device#${id}" onclick="device_h('${id}')" title="${id} [${devices[id].prefix}]">
<div class="device_inner">
<div class="d_icon"><span class="icon" id="icon#${id}">${devices[id].icon}</span></div>
<div class="d_head">
<span><span class="d_name" id="name#${id}">${devices[id].name}</span><sup class="conn_dev" id="Serial#${id}">S</sup><sup class="conn_dev" id="BT#${id}">B</sup><sup class="conn_dev" id="WS#${id}">W</sup><sup class="conn_dev" id="MQTT#${id}">M</sup></span>
</div>
<div class="d_delete" onclick="delete_h('${id}')">x</div>
</div>
</div>`;}
function addButton(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);if(wid_row_id){endButtons();let inner=renderButton(ctrl.name,'icon btn_icon',ctrl.name,'',ctrl.size*3,ctrl.color,true);addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{if(!btn_row_id)beginButtons();EL(btn_row_id).innerHTML+=`${renderButton(ctrl.name, 'c_btn', ctrl.name, ctrl.label, ctrl.size, ctrl.color, false)}`;}}
function addButtonIcon(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);if(wid_row_id){endButtons();let inner=renderButton(ctrl.name,'icon btn_icon',ctrl.name,ctrl.label,ctrl.size,ctrl.color,true);addWidget(ctrl.tab_w,ctrl.name,'',inner,0,true);}else{if(!btn_row_id)beginButtons();EL(btn_row_id).innerHTML+=`${renderButton(ctrl.name, 'icon btn_icon', ctrl.name, ctrl.label, ctrl.size, ctrl.color, true)}`;}}
function addTabs(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let tabs='';let labels=ctrl.text.toString().split(',');for(let i in labels){let sel=(i==ctrl.value)?'class="tab_act"':'';tabs+=`<li onclick="set_h('${ctrl.name}','${i}')" ${sel}>${labels[i]}</li>`;}
if(wid_row_id){let inner=`
<div class="navtab_tab">
<ul>
${tabs}
</ul>
</div>
`;addWidget(ctrl.tab_w,'',ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="navtab">
<ul>
${tabs}
</ul>
</div>
`;}}
function addSpace(ctrl){endButtons();EL('controls').innerHTML+=`
<div style="height:${ctrl.height}px"></div>
`;}
function addTitle(ctrl){endWidgets();endButtons();EL('controls').innerHTML+=`
<div class="control control_title">
<span class="c_title">${ctrl.label}</span>
</div>
`;}
function addLED(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let ch=ctrl.value?'checked':'';if(ctrl.text){if(wid_row_id){let inner=`
<label id="swlabel_${ctrl.name}" class="led_i_cont led_i_cont_tab"><input type="checkbox" class="switch_t" id='#${ctrl.name}' ${ch} disabled><span class="switch_i led_i led_i_tab">${ctrl.text}</span></label>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Switch'}</label>
<label id="swlabel_${ctrl.name}" class="led_i_cont"><input type="checkbox" class="switch_t" id='#${ctrl.name}' ${ch} disabled><span class="switch_i led_i">${ctrl.text}</span></label>
</div>
`;}}else{if(wid_row_id){let inner=`
<label class="led_cont"><input type="checkbox" class="switch_t" id='#${ctrl.name}' ${ch} disabled><span class="led"></span></label>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'LED'}</label>
<label class="led_cont"><input type="checkbox" class="switch_t" id='#${ctrl.name}' ${ch} disabled><span class="led"></span></label>
</div>
`;}}}
function addIcon(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let col=(ctrl.color!=null)?`color:${intToCol(ctrl.color)}`:'';if(wid_row_id){let inner=`
<span class="icon icon_t" id='#${ctrl.name}' style="${col}">${ctrl.text}</span>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Icon'}</label>
<span class="icon icon_t" id='#${ctrl.name}' style="${col}">${ctrl.text}</span>
</div>
`;}}
function addLabel(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let col=(ctrl.color)?(`color:${intToCol(ctrl.color)}`):'';if(wid_row_id){let inner=`
<label class="c_label text_t c_label_tab" id='#${ctrl.name}' style="${col};font-size:${ctrl.size}px">${ctrl.value}</label>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Label'}</label>
<label class="c_label text_t" id='#${ctrl.name}' style="${col};font-size:${ctrl.size}px">${ctrl.value}</label>
</div>
`;}}
function addInput(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let col=(ctrl.color!=null)?('box-shadow: 0px 2px 0px 0px '+intToCol(ctrl.color)):'';if(wid_row_id){let inner=`
<div class="cfg_inp_row cfg_inp_row_tab">
<input class="cfg_inp c_inp input_t" style="${col}" type="text" value="${ctrl.value}" id="#${ctrl.name}" name="${ctrl.name}" onkeydown="checkEnter(this)" oninput="checkLen(this,${ctrl.max})">
<div class="cfg_btn_block">
<button class="icon cfg_btn" onclick="set_h('${ctrl.name}',EL('#${ctrl.name}').value)"></button>
</div>
</div>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Input'}</label>
<div class="cfg_inp_row">
<input class="cfg_inp c_inp input_t" style="${col}" type="text" value="${ctrl.value}" id="#${ctrl.name}" name="${ctrl.name}" onkeydown="checkEnter(this)" oninput="checkLen(this,${ctrl.max})">
<div class="cfg_btn_block">
<button class="icon cfg_btn" onclick="set_h('${ctrl.name}',EL('#${ctrl.name}').value)"></button>
</div>
</div>
</div>
`;}}
function addPass(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let col=(ctrl.color!=null)?('box-shadow: 0px 2px 0px 0px '+intToCol(ctrl.color)):'';if(wid_row_id){let inner=`
<div class="cfg_inp_row cfg_inp_row_tab">
<input class="cfg_inp c_inp input_t" style="${col}" type="password" value="${ctrl.value}" id="#${ctrl.name}" name="${ctrl.name}" onkeydown="checkEnter(this)" oninput="checkLen(this,${ctrl.max})">
<div class="cfg_btn_block2">
<button class="icon cfg_btn" onclick="togglePass('#${ctrl.name}')"></button>
<button class="icon cfg_btn" onclick="set_h('${ctrl.name}',EL('#${ctrl.name}').value)"></button>
</div>
</div>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Password'}</label>
<div class="cfg_inp_row">
<input class="cfg_inp c_inp input_t" style="${col}" type="password" value="${ctrl.value}" id="#${ctrl.name}" name="${ctrl.name}" onkeydown="checkEnter(this)" oninput="checkLen(this,${ctrl.max})">
<div class="cfg_btn_block2">
<button class="icon cfg_btn" onclick="togglePass('#${ctrl.name}')"></button>
<button class="icon cfg_btn" onclick="set_h('${ctrl.name}',EL('#${ctrl.name}').value)"></button>
</div>
</div>
</div>
`;}}
function addSliderW(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();EL('controls').innerHTML+=`
<div class="control">
<div class="sld_name">
<label title='${ctrl.name}'>${ctrl.label}</label>
</div>
<div class="cfg_inp_row">
<input name="${ctrl.name}" id="#${ctrl.name}" onchange="set_h('${ctrl.name}',this.value)" oninput="moveSlider(this)" type="range" class="c_rangeW slider_t" value="${ctrl.value}" min="${ctrl.min}" max="${ctrl.max}" step="${ctrl.step}"><div class="sldW_out"><output id="out#${ctrl.name}">${ctrl.value}</output></div>
</div>
</div>
`;}
function addSlider(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let col=(ctrl.color!=null)?`background-image: linear-gradient(${intToCol(ctrl.color)}, ${intToCol(ctrl.color)})`:'';let formatted=formatToStep(ctrl.value,ctrl.step);if(wid_row_id){let inner=`
<input ontouchstart="dis_scroll_f=2" ontouchend="dis_scroll_f=0;enableScroll()" name="${ctrl.name}" id="#${ctrl.name}" oninput="moveSlider(this)" type="range" class="c_rangeW slider_t" style="${col}" value="${ctrl.value}" min="${ctrl.min}" max="${ctrl.max}" step="${ctrl.step}"><div class="sldW_out"><output id="out#${ctrl.name}">${formatted}</output></div>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<div class="sld_name">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Slider'}</label>
<label>:&nbsp;</label>
<output id="out#${ctrl.name}">${formatted}</output>
</div>
<div class="cfg_inp_row">
<input ontouchstart="dis_scroll_f=2" ontouchend="dis_scroll_f=0;enableScroll()" name="${ctrl.name}" id="#${ctrl.name}" oninput="moveSlider(this)" type="range" class="c_range slider_t" style="${col}" value="${ctrl.value}" min="${ctrl.min}" max="${ctrl.max}" step="${ctrl.step}">      
</div>
</div>
`;}}
function addSwitch(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let ch=ctrl.value?'checked':'';let col=(ctrl.color!=null)?`<style>#swlabel_${ctrl.name} input:checked+.slider{background:${intToCol(ctrl.color)}}</style>`:'';if(wid_row_id){let inner=`${col}
<label id="swlabel_${ctrl.name}" class="switch"><input type="checkbox" class="switch_t" id='#${ctrl.name}' onclick="set_h('${ctrl.name}',(this.checked ? 1 : 0))" ${ch}><span class="slider"></span></label>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`${col}
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Switch'}</label>
<label id="swlabel_${ctrl.name}" class="switch"><input type="checkbox" class="switch_t" id='#${ctrl.name}' onclick="set_h('${ctrl.name}',(this.checked ? 1 : 0))" ${ch}><span class="slider"></span></label>
</div>
`;}}
function addSwitchIcon(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let ch=ctrl.value?'checked':'';let text=ctrl.text?ctrl.text:'';if(wid_row_id){let col=(ctrl.color!=null)?`<style>#swlabel_${ctrl.name} input:checked+.switch_i_tab{background:${intToCol(ctrl.color)};color:var(--font_inv)} #swlabel_${ctrl.name} .switch_i_tab{box-shadow: 0 0 0 2px ${intToCol(ctrl.color)};color:${intToCol(ctrl.color)}}</style>`:'';let inner=`${col}
<label id="swlabel_${ctrl.name}" class="switch_i_cont switch_i_cont_tab"><input type="checkbox" onclick="set_h('${ctrl.name}',(this.checked ? 1 : 0))" class="switch_t" id='#${ctrl.name}' ${ch}><span class="switch_i switch_i_tab">${text}</span></label>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner,120);}else{let col=(ctrl.color!=null)?`<style>#swlabel_${ctrl.name} input:checked+.switch_i{color:${intToCol(ctrl.color)}}</style>`:'';EL('controls').innerHTML+=`${col}
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Switch'}</label>
<label id="swlabel_${ctrl.name}" class="switch_i_cont"><input type="checkbox" onclick="set_h('${ctrl.name}',(this.checked ? 1 : 0))" class="switch_t" id='#${ctrl.name}' ${ch}><span class="switch_i">${text}</span></label>
</div>
`;}}
function addSwitchText(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let ch=ctrl.value?'checked':'';let text=ctrl.text?ctrl.text:'ON';if(wid_row_id){let col=(ctrl.color!=null)?`<style>#swlabel_${ctrl.name} input:checked+.switch_i_tab{background:${intToCol(ctrl.color)};color:var(--font_inv)} #swlabel_${ctrl.name} .switch_i_tab{box-shadow: 0 0 0 2px ${intToCol(ctrl.color)};color:${intToCol(ctrl.color)}}</style>`:'';let inner=`${col}
<label id="swlabel_${ctrl.name}" class="switch_i_cont switch_i_cont_tab"><input type="checkbox" onclick="set_h('${ctrl.name}',(this.checked ? 1 : 0))" class="switch_t" id='#${ctrl.name}' ${ch}><span class="switch_i switch_i_tab switch_txt switch_txt_tab">${text}</span></label>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner,120);}else{let col=(ctrl.color!=null)?`<style>#swlabel_${ctrl.name} input:checked+.switch_i{color:${intToCol(ctrl.color)}}</style>`:'';EL('controls').innerHTML+=`${col}
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Switch'}</label>
<label id="swlabel_${ctrl.name}" class="switch_i_cont"><input type="checkbox" onclick="set_h('${ctrl.name}',(this.checked ? 1 : 0))" class="switch_t" id='#${ctrl.name}' ${ch}><span class="switch_i switch_txt">${text}</span></label>
</div>
`;}}
function addDate(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let date=new Date(ctrl.value*1000).toISOString().split('T')[0];let col=(ctrl.color!=null)?`color:${intToCol(ctrl.color)}`:'';if(wid_row_id){let inner=`
<input id='#${ctrl.name}' class="cfg_inp c_inp_block c_inp_block_tab date_t" style="${col}" type="date" value="${date}" onclick="this.showPicker()" onchange="set_h('${ctrl.name}',getUnix(this))">
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Date'}</label>
<input id='#${ctrl.name}' class="cfg_inp c_inp_block datime date_t" style="${col}" type="date" value="${date}" onclick="this.showPicker()" onchange="set_h('${ctrl.name}',getUnix(this))">
</div>
`;}}
function addTime(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let time=new Date(ctrl.value*1000).toISOString().split('T')[1].split('.')[0];let col=(ctrl.color!=null)?`color:${intToCol(ctrl.color)}`:'';if(wid_row_id){let inner=`
<input id='#${ctrl.name}' class="cfg_inp c_inp_block c_inp_block_tab time_t" style="${col}" type="time" value="${time}" onclick="this.showPicker()" onchange="set_h('${ctrl.name}',getUnix(this))" step="1">
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Time'}</label>
<input id='#${ctrl.name}' class="cfg_inp c_inp_block datime time_t" style="${col}" type="time" value="${time}" onclick="this.showPicker()" onchange="set_h('${ctrl.name}',getUnix(this))" step="1">
</div>
`;}}
function addDateTime(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let datetime=new Date(ctrl.value*1000).toISOString().split('.')[0];let col=(ctrl.color!=null)?`color:${intToCol(ctrl.color)}`:'';if(wid_row_id){let inner=`
<input id='#${ctrl.name}' class="cfg_inp c_inp_block c_inp_block_tab datetime_t" style="${col}" type="datetime-local" value="${datetime}" onclick="this.showPicker()" onchange="set_h('${ctrl.name}',getUnix(this))" step="1">
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Datime'}</label>
<input id='#${ctrl.name}' class="cfg_inp c_inp_block datime datime_w datetime_t" style="${col}" type="datetime-local" value="${datetime}" onclick="this.showPicker()" onchange="set_h('${ctrl.name}',getUnix(this))" step="1">
</div>
`;}}
function addSelect(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let elms=ctrl.text.toString().split(',');let options='';for(let i in elms){let sel=(i==ctrl.value)?'selected':'';options+=`<option value="${i}" ${sel}>${elms[i]}</option>`;}
let col=(ctrl.color!=null)?`color:${intToCol(ctrl.color)}`:'';if(wid_row_id){let inner=`
<select class="cfg_inp c_inp_block select_t" style="${col}" id='#${ctrl.name}' onchange="set_h('${ctrl.name}',this.value)">
${options}
</select>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Select'}</label>
<select class="cfg_inp c_inp_block select_t" style="${col}" id='#${ctrl.name}' onchange="set_h('${ctrl.name}',this.value)">
${options}
</select>
</div>
`;}}
function addColor(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let color=intToCol(ctrl.value);let inner=`
<div id="color_cont#${ctrl.name}" style="visibility: hidden">
<div id='#${ctrl.name}'></div>
</div>
<button id="color_btn#${ctrl.name}" style="margin-left:-30px;color:${color}" class="icon cfg_btn_tab" onclick="openColor('${ctrl.name}')"></button>
`;if(wid_row_id){addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Color'}</label>
${inner}
</div>
`;}
pickers['#'+ctrl.name]=color;}
function addSpinner(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let formatted=formatToStep(ctrl.value,ctrl.step);if(wid_row_id){let inner=`
<div class="spinner_row">
<button class="icon cfg_btn btn_no_pad" onclick="spinSpinner(this, -1);set_h('${ctrl.name}',EL('#${ctrl.name}').value);"></button>
<input id="#${ctrl.name}" class="cfg_inp spinner input_t" type="number" oninput="resizeSpinner(this)" value="${formatted}" min="${ctrl.min}"
max="${ctrl.max}" step="${ctrl.step}">
<button class="icon cfg_btn btn_no_pad" onclick="spinSpinner(this, 1);set_h('${ctrl.name}',EL('#${ctrl.name}').value);"></button>
</div>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Spinner'}</label>
<div class="spinner_row">
<button class="icon cfg_btn btn_no_pad" onclick="spinSpinner(this, -1);set_h('${ctrl.name}',EL('#${ctrl.name}').value);"></button>
<input id="#${ctrl.name}" class="cfg_inp spinner input_t" type="number" oninput="resizeSpinner(this)" value="${formatted}" min="${ctrl.min}"
max="${ctrl.max}" step="${ctrl.step}">
<button class="icon cfg_btn btn_no_pad" onclick="spinSpinner(this, 1);set_h('${ctrl.name}',EL('#${ctrl.name}').value);"></button>
</div>
</div>
`;}}
function addFlags(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let flags="";let val=ctrl.value;let labels=ctrl.text.toString().split(',');for(let i=0;i<labels.length;i++){let ch=(!(val&1))?'':'checked';val>>=1;flags+=`<label id="swlabel_${ctrl.name}" class="chbutton chtext">
<input name="${ctrl.name}" type="checkbox" onclick="set_h('${ctrl.name}',chbuttonEncode('${ctrl.name}'))" ${ch}>
<span class="chbutton_s chtext_s">${labels[i]}</span></label>`;}
let col=(ctrl.color!=null)?`<style>#swlabel_${ctrl.name} input:checked+.chbutton_s{background:${intToCol(ctrl.color)}}</style>`:'';if(wid_row_id){let inner=`${col}
<div class="chbutton_cont chbutton_cont_tab flags_t" id='#${ctrl.name}'>
${flags}
</div>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label,inner);}else{EL('controls').innerHTML+=`${col}
<div class="control">
<label title='${ctrl.name}'>${ctrl.label ? ctrl.label : 'Flags'}</label>
<div class="chbutton_cont flags_t" id='#${ctrl.name}'>
${flags}
</div>
</div>
`;}}
function addLog(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();if(ctrl.text.endsWith('\n'))ctrl.text=ctrl.text.slice(0,-1);if(wid_row_id){let inner=`
<textarea id="#${ctrl.name}" title='${ctrl.name}' class="cfg_inp c_log text_t" readonly>${ctrl.text}</textarea>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label?ctrl.label:'Log',inner);}else{EL('controls').innerHTML+=`
<div class="control">
<textarea id="#${ctrl.name}" title='${ctrl.name}' class="cfg_inp c_log text_t" readonly>${ctrl.text}</textarea>
</div>
`;}}
function addDisplay(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let col=(ctrl.color!=null)?('background:'+intToCol(ctrl.color)):'';if(wid_row_id){let inner=`
<textarea id="#${ctrl.name}" title='${ctrl.name}' class="cfg_inp c_area c_disp text_t" style="font-size:${ctrl.size}px;${col}" rows="${ctrl.rows}" readonly>${ctrl.value}</textarea>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label?ctrl.label:'Display',inner);}else{EL('controls').innerHTML+=`
<div class="control">
<textarea id="#${ctrl.name}" title='${ctrl.name}' class="cfg_inp c_area c_disp text_t" style="font-size:${ctrl.size}px;${col}" rows="${ctrl.rows}" readonly>${ctrl.value}</textarea>
</div>
`;}}
function addHTML(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();if(wid_row_id){let inner=`
<div name="text" id="#${ctrl.name}" title='${ctrl.name}' class="c_text text_t">${ctrl.value}</div>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label?ctrl.label:'HTML',inner);}else{EL('controls').innerHTML+=`
<div class="control">
<div name="text" id="#${ctrl.name}" title='${ctrl.name}' class="c_text text_t">${ctrl.value}</div>
</div>
`;}}
function addCanvas(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();if(wid_row_id){let inner=`
<canvas class="canvas_t" id="#${ctrl.name}"></canvas>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label?ctrl.label:'CANVAS',inner);}else{EL('controls').innerHTML+=`
<div class="cv_block">
<canvas class="canvas_t" id="#${ctrl.name}"></canvas>
</div>
`;}}
function addGauge(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();if(wid_row_id){let inner=`
<canvas class="gauge_t" id="#${ctrl.name}"></canvas>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.label?ctrl.label:'GAUGE',inner);}else{EL('controls').innerHTML+=`
<div class="cv_block cv_block_back">
<canvas class="gauge_t" id="#${ctrl.name}"></canvas>
</div>
`;}
gauges[ctrl.name]={name:ctrl.name,value:Number(ctrl.value),min:Number(ctrl.min),max:Number(ctrl.max),step:Number(ctrl.step),text:ctrl.text,color:ctrl.color};gauges[ctrl.name].value_t=ctrl.value;}
function checkWidget(ctrl){if(ctrl.tab_w&&!wid_row_id)beginWidgets(null,true);}
function beginWidgets(ctrl=null,check=false){if(!check)endButtons();wid_row_size=0;if(devices[focused].break_widgets)return;let st=(ctrl&&ctrl.height)?`style="height:${ctrl.height}px"`:'';wid_row_id='widgets_row#'+wid_row_count;wid_row_count++;EL('controls').innerHTML+=`
<div class="widget_row" id="${wid_row_id}" ${st}></div>
`;}
function endWidgets(){endButtons();wid_row_id=null;}
function addWidget(width,name,label,inner,height=0,noback=false){wid_row_size+=width;if(wid_row_size>100){beginWidgets();wid_row_size=width;}
let h=height?('height:'+height+'px'):'';let lbl=label?`<div class="widget_label" title="${name}">${label}</div>`:'';EL(wid_row_id).innerHTML+=`
<div class="widget" style="width:${width}%;${h}">
<div class="widget_inner ${noback ? 'widget_space' : ''}">
${lbl}
<div class="widget_block">
${inner}
</div>
</div>
</div>
`;}
function openColor(id){EL('color_cont#'+id).getElementsByTagName('button')[0].click()}
function showColors(){Object.keys(pickers).forEach(pick=>{Pickr.create({el:EL(pick),theme:'nano',default:pickers[pick],defaultRepresentation:'HEXA',components:{preview:true,hue:true,interaction:{hex:false,input:true,save:true}}}).on('save',(color)=>{let col=color.toHEXA().toString();set_h('color',colToInt(col));EL('color_btn'+pick).style.color=col;});});}
function renderButton(title,className,name,label,size,color=null,is_icon=false){let col=(color!=null)?((is_icon?';color:':';background:')+intToCol(color)):'';return`<button id="#${name}" title='${title}' style="font-size:${size}px${col}" class="${className}" onmousedown="if(!touch)click_h('${name}',1)" onmouseup="if(!touch&&pressId)click_h('${name}',0)" onmouseleave="if(pressId&&!touch)click_h('${name}',0);" ontouchstart="touch=1;click_h('${name}',1)" ontouchend="click_h('${name}',0)">${label}</button>`;}
function beginButtons(){btn_row_id='buttons_row#'+btn_row_count;btn_row_count++;EL('controls').innerHTML+=`
<div id="${btn_row_id}" class="control control_nob control_scroll"></div>
`;}
function endButtons(){if(btn_row_id&&EL(btn_row_id).getElementsByTagName('*').length==1){EL(btn_row_id).innerHTML="<div></div>"+EL(btn_row_id).innerHTML+"<div></div>";}
btn_row_id=null;}
function spinSpinner(el,dir){let num=(dir==1)?el.previousElementSibling:el.nextElementSibling;let val=Number(num.value)+Number(num.step)*Number(dir);val=Math.max(Number(num.min),val);val=Math.min(Number(num.max),val);num.value=formatToStep(val,num.step);resizeSpinner(num);}
function resizeSpinner(el){el.style.width=el.value.length+'ch';}
function resizeSpinners(){let spinners=document.querySelectorAll(".spinner");spinners.forEach((sp)=>resizeSpinner(sp));}
function moveSliders(){document.querySelectorAll('.c_range, .c_rangeW').forEach(x=>{moveSlider(x,false)});}
function moveSlider(arg,sendf=true){if(dis_scroll_f){dis_scroll_f--;if(!dis_scroll_f)disableScroll();}
arg.style.backgroundSize=(arg.value-arg.min)*100/(arg.max-arg.min)+'% 100%';EL('out'+arg.id).value=formatToStep(arg.value,arg.step);if(sendf)input_h(arg.name,arg.value);}
function showCanvases(controls){for(ctrl of controls){if(ctrl.type=='canvas'){let cv=EL('#'+ctrl.name);cv.width=cv.parentNode.clientWidth;cv.height=cv.width*ctrl.size/1000;drawCanvas(cv,ctrl.value);}}}
function drawCanvas(cv,data){function cv_map(cv,v,h){v=cv.width*v/1000;return v>=0?v:(h?cv.height:cv.width)-v;}
function cv_scale(cv,v){return cv.parentNode.clientWidth*v/1000;}
let cx=cv.getContext("2d");const cmd_list=['fillStyle','strokeStyle','shadowColor','shadowBlur','shadowOffsetX','shadowOffsetY','lineWidth','miterLimit','font','textAlign','textBaseline','lineCap','lineJoin','globalCompositeOperation','globalAlpha','scale','rotate','rect','fillRect','strokeRect','clearRect','moveTo','lineTo','quadraticCurveTo','bezierCurveTo','translate','arcTo','arc','fillText','strokeText','drawImage','fill','stroke','beginPath','closePath','clip','save','restore'];const const_list=['butt','round','square','square','bevel','miter','start','end','center','left','right','alphabetic','top','hanging','middle','ideographic','bottom','source-over','source-atop','source-in','source-out','destination-over','destination-atop','destination-in','destination-out','lighter','copy','xor','top','bottom','middle','alphabetic'];for(d of data){let div=d.indexOf(':');let cmd=parseInt(d,10);if(!isNaN(cmd)&&cmd<=37){if(div==1||div==2){let val=d.slice(div+1);let vals=val.split(',');if(cmd<=2)eval('cx.'+cmd_list[cmd]+'=\''+intToColA(val)+'\'');else if(cmd<=7)eval('cx.'+cmd_list[cmd]+'='+cv_scale(cv,val));else if(cmd<=13)eval('cx.'+cmd_list[cmd]+'=\''+const_list[val]+'\'');else if(cmd<=14)eval('cx.'+cmd_list[cmd]+'='+val);else if(cmd<=16)eval('cx.'+cmd_list[cmd]+'('+val+')');else if(cmd<=26){let str='cx.'+cmd_list[cmd]+'(';for(let i in vals){if(i>0)str+=',';str+=`cv_map(cv,${vals[i]},${(i % 2)})`;}
eval(str+')');}else if(cmd==27){eval(`cx.${cmd_list[cmd]}(cv_map(cv,${vals[0]},0),cv_map(cv,${vals[1]},1),cv_map(cv,${vals[2]},0),${vals[3]},${vals[4]},${vals[5]})`);}else if(cmd<=29){eval(`cx.${cmd_list[cmd]}(${vals[0]},cv_map(cv,${vals[1]},0),cv_map(cv,${vals[2]},1),${vals[3]})`);}else if(cmd==30){let str='cx.'+cmd_list[cmd]+'(';for(let i in vals){if(i>0){str+=`,cv_map(cv,${vals[i]},${!(i % 2)})`;}else str+=vals[i];}
eval(str+')');}}else{if(cmd>=31)eval('cx.'+cmd_list[cmd]+'()');}}else{eval(d);}}}
function drawGauge(g){let cv=EL('#'+g.name);if(!cv)return;if(Math.abs(g.value-g.value_t)<=0.1)g.value_t=g.value;else g.value_t+=(g.value-g.value_t)*0.2;if(g.value_t!=g.value)setTimeout(()=>drawGauge(g),30);let cx=cv.getContext("2d");let perc=(g.value_t-g.min)*100/(g.max-g.min);let col=g.color==null?intToCol(colors[cfg.maincolor]):intToCol(g.color);let v=themes[cfg.theme];if(perc<0)perc=0;if(perc>100)perc=100;cv.width=cv.parentNode.clientWidth;cv.height=cv.width*0.47;cx.clearRect(0,0,cv.width,cv.height);cx.lineWidth=cv.width/8;cx.strokeStyle=theme_cols[v][4];cx.beginPath();cx.arc(cv.width/2,cv.height*0.97,cv.width/2-cx.lineWidth,Math.PI*(1+perc/100),Math.PI*2);cx.stroke();cx.strokeStyle=col;cx.beginPath();cx.arc(cv.width/2,cv.height*0.97,cv.width/2-cx.lineWidth,Math.PI,Math.PI*(1+perc/100));cx.stroke();cx.fillStyle=col;cx.font='10px '+cfg.font;cx.textAlign="center";let text=g.text;let len=Math.max((formatToStep(g.value,g.step)+text).length,(formatToStep(g.min,g.step)+text).length,(formatToStep(g.max,g.step)+text).length);if(len==1)text+='  ';else if(len==2)text+=' ';let w=Math.max(cx.measureText(formatToStep(g.value,g.step)+text).width,cx.measureText(formatToStep(g.min,g.step)+text).width,cx.measureText(formatToStep(g.max,g.step)+text).width);cx.fillStyle=theme_cols[v][3];cx.font=cv.width*0.5*10/w+'px '+cfg.font;cx.fillText(formatToStep(g.value,g.step)+g.text,cv.width/2,cv.height*0.93);cx.font='10px '+cfg.font;w=Math.max(cx.measureText(Math.round(g.min)).width,cx.measureText(Math.round(g.max)).width);cx.fillStyle=theme_cols[v][2];cx.font=cx.lineWidth*0.6*10/w+'px '+cfg.font;cx.fillText(g.min,cx.lineWidth,cv.height*0.92);cx.fillText(g.max,cv.width-cx.lineWidth,cv.height*0.92);}
function showGauges(){Object.values(gauges).forEach(gauge=>{drawGauge(gauge);});}
function checkLen(arg,len){if(len&&arg.value.length>len)arg.value=arg.value.substring(0,len);}
function checkEnter(arg){if(event.key=='Enter')set_h(arg.name,arg.value);}
function getUnix(arg){return Math.floor(arg.valueAsNumber/1000);}
function showNotif(text,name){if(!("Notification"in window)||Notification.permission!='granted')return;let descr=name+' ('+new Date(Date.now()).toLocaleString()+')';navigator.serviceWorker.getRegistration().then(function(reg){reg.showNotification(text,{body:descr,vibrate:true});});}
function checkDup(ctrl){if(EL('#'+ctrl.name)){dup_names.push(' '+ctrl.name);return 1;}
return 0;}
function formatToStep(val,step){step=step.toString();if(step.indexOf('.')>0)return Number(val).toFixed((step.split('.')[1]).toString().length);else return val;}
function togglePass(id){if(EL(id).type=='text')EL(id).type='password';else EL(id).type='text';}
function resizeChbuttons(){let chtext=document.querySelectorAll(".chtext");let chtext_s=document.querySelectorAll(".chtext_s");chtext.forEach((ch,i)=>{let len=chtext_s[i].innerHTML.length+2;chtext[i].style.width=(len+0.5)+'ch';chtext_s[i].style.width=len+'ch';});}
function chbuttonEncode(name){let weeks=document.getElementsByName(name);let encoded=0;weeks.forEach((w,i)=>{if(w.checked)encoded|=(1<<weeks.length);encoded>>=1;});return encoded;}
function scrollDown(){let logs=document.querySelectorAll(".c_log");logs.forEach((log)=>log.scrollTop=log.scrollHeight);}
const http_port=80;const ws_port=81;const tout_prd=2800;const ping_prd=3000;const oninput_prd=100;const ws_tout=4000;let discovering=false;let mq_client;let mq_discover_flag=false;let mq_pref_list=[];let ws_focus_flag=false;let tout_interval=null;let ping_interval=null;let oninput_tout=null;let refresh_ui=false;let oninp_buffer={};const Conn={SERIAL:0,BT:1,WS:2,MQTT:3,NONE:4,ERROR:5,};const ConnNames=['Serial','BT','WS','MQTT','None','Error'];function post(cmd,name='',value=''){if(!focused)return;let id=focused;cmd=cmd.toString();name=name.toString();value=value.toString();let uri0=devices[id].prefix+'/'+id+'/'+cfg.hub_id+'/'+cmd;let uri=uri0;if(name)uri+='/'+name;if(value)uri+='='+value;switch(devices_t[id].conn){case Conn.SERIAL:break;case Conn.BT:break;case Conn.WS:ws_send(id,uri);break;case Conn.MQTT:mq_send(uri0+(name.length?('/'+name):''),value);break;}
reset_ping();reset_tout();log('Post to #'+id+' via '+ConnNames[devices_t[id].conn]+', cmd='+cmd+(name?(', name='+name):'')+(value?(', value='+value):''))}
function click_h(name,dir){pressId=(dir==1)?name:null;post('click',name,dir);reset_ping();}
function set_h(name,value=''){post('set',name,value);reset_ping();}
function input_h(name,value){if(!(name in oninp_buffer))oninp_buffer[name]={'value':null,'tout':null};if(!oninp_buffer[name].tout){set_h(name,value);oninp_buffer[name].tout=setTimeout(()=>{if(oninp_buffer[name].value!=null&&!tout_interval)set_h(name,oninp_buffer[name].value);oninp_buffer[name].tout=null;oninp_buffer[name].value=null;},oninput_prd);}else{oninp_buffer[name].value=value;}}
function reboot_h(){post('reboot');}
function change_conn(conn){EL('conn').innerHTML=ConnNames[conn];}
function stop_tout(){refreshSpin(false);if(tout_interval)clearTimeout(tout_interval);tout_interval=null;}
function reset_tout(){if(tout_interval)return;refreshSpin(true);tout_interval=setTimeout(function(){log('Connection lost');refresh_ui=true;change_conn(Conn.ERROR);showErr(true);stop_tout();},tout_prd);}
function stop_ping(){if(ping_interval)clearInterval(ping_interval);ping_interval=null;}
function reset_ping(){stop_ping();ping_interval=setInterval(()=>{if(refresh_ui){refresh_ui=false;post('focus');}else{post('ping');}},ping_prd);}
function ws_start(id){if(!cfg.use_ws)return;if(devices_t[id].ws)return;if(devices[id].ip=='unset')return;log(`WS ${id} open...`);devices_t[id].ws=new WebSocket(`ws://${devices[id].ip}:${ws_port}/`,['hub']);devices_t[id].ws.onopen=function(){log(`WS ${id} opened`);if(ws_focus_flag){ws_focus_flag=false;post('focus');}
if(id!=focused)devices_t[id].ws.close();};devices_t[id].ws.onclose=function(){log(`WS ${id} closed`);devices_t[id].ws=null;ws_focus_flag=false;if(id==focused)setTimeout(()=>ws_start(id),500);};devices_t[id].ws.onerror=function(){log(`WS ${id} error`);};devices_t[id].ws.onmessage=function(event){reset_tout();let st=event.data.startsWith('\n{');let end=event.data.endsWith('}\n');if(st&&end)parseDevice(id,event.data,Conn.WS);else if(st){devices_t[id].buffer.ws=event.data;}else if(end){log('End WS UI chunk #'+id);devices_t[id].buffer.ws+=event.data;parseDevice(id,devices_t[id].buffer.ws,Conn.WS);}else{devices_t[id].buffer.ws+=event.data;}};}
function ws_stop(id){if(!devices_t[id].ws||devices_t[id].ws.readyState>=2)return;log(`WS ${id} close...`);devices_t[id].ws.close();}
function ws_state(id){return(devices_t[id].ws&&devices_t[id].ws.readyState==1);}
function ws_send(id,text){if(ws_state(id))devices_t[id].ws.send(text.toString()+'\0');}
function ws_discover(){Object.keys(devices).forEach(id=>{if(devices[id].ip=='unset')return;ws_discover_ip(devices[id].ip,id);log('WS discover');});}
function ws_discover_ip(ip,id='broadcast'){let ws=new WebSocket(`ws://${ip}:${ws_port}/`,['hub']);let tout=setTimeout(()=>{if(ws)ws.close();},ws_tout);ws.onopen=()=>ws.send(cfg.prefix+(id!='broadcast'?('/'+id):'')+'\0');ws.onerror=()=>ws.close();ws.onclose=()=>ws=null;ws.onmessage=function(event){clearTimeout(tout);parseDevice(id,event.data,Conn.WS,ip);ws.close();};}
function ws_discover_ips(ips){discovering=true;refreshSpin(true);setTimeout(()=>{refreshSpin(false);discovering=false;},ws_tout/200*ips.length);for(let i in ips){setTimeout(()=>ws_discover_ip(ips[i]),ws_tout/200*i);}
log('WS discover all');}
function http_hook(ips){discovering=true;refreshSpin(true);setTimeout(()=>{refreshSpin(false);discovering=false;},ws_tout);function hook(ip){try{let xhr=new XMLHttpRequest();xhr.onreadystatechange=function(){if(this.readyState==4&&this.status==200){if(this.responseText=='OK')ws_discover_ip(ip);}}
xhr.timeout=tout_prd;xhr.open("GET",'http://'+ip+':'+http_port+'/hub_discover_all');xhr.send();}catch(e){}}
for(let i in ips){setTimeout(()=>hook(ips[i]),10*i);}
log('WS hook discover all');}
function ws_discover_all(){let ip_arr=getIPs();if(ip_arr==null)return;if(cfg.use_hook)http_hook(ip_arr);else ws_discover_ips(ip_arr);}
function manual_ws_h(ip){if(!checkIP(ip)){showPopupError('Wrong IP!');return;}
log('WS manual '+ip);ws_discover_ip(ip);back_h();}
let fs_arr=[];let fetching=null;let fetch_name;let fetch_index;let fetch_file='';let fetch_tout;let uploading=null;let upload_tout;let upload_bytes=[];let upload_size;let ota_tout;function stopFS(){stop_fetch_tout();stop_upload_tout();stop_ota_tout();upload_bytes=[];fetching=null;uploading=null;}
function stop_fetch_tout(){if(fetch_tout)clearTimeout(fetch_tout);}
function reset_fetch_tout(){stop_fetch_tout();fetch_tout=setTimeout(()=>{stopFS();EL('process#'+fetch_index).innerHTML='Error!';},tout_prd);}
function stop_upload_tout(){if(upload_tout)clearTimeout(upload_tout);}
function reset_upload_tout(){stop_upload_tout();upload_tout=setTimeout(()=>{stopFS();EL('file_upload_btn').innerHTML='Error!';setTimeout(()=>EL('file_upload_btn').innerHTML='Upload',2000);},tout_prd);}
function stop_ota_tout(){if(ota_tout)clearTimeout(ota_tout);}
function reset_ota_tout(){stop_ota_tout();ota_tout=setTimeout(()=>{stopFS();EL('ota_label').innerHTML='Error!';setTimeout(()=>EL('ota_label').innerHTML='IDLE',3000);},tout_prd);}
function showFsbr(device){fs_arr=[];Object.keys(device.fs).forEach(path=>fs_arr.push(path));fs_arr=sortPaths(fs_arr,'/');let inner='';for(let i in fs_arr){if(fs_arr[i].endsWith('/')){inner+=`<div class="fs_file fs_folder" onclick="file_upload_path.value='${fs_arr[i]}'/*;file_upload_btn.click()*/">${fs_arr[i]}</div>`;}else{inner+=`<div class="fs_file" onclick="openFSctrl(${i})">${fs_arr[i]}<div class="fs_weight">${(device.fs[fs_arr[i]] / 1000).toFixed(2)} kB</div></div>
<div id="fs#${i}" class="fs_controls">
<button title="Rename" class="icon cfg_btn_tab" onclick="renameFile(${i})"></button>
<button title="Delete" class="icon cfg_btn_tab" onclick="deleteFile(${i})"></button>
<button title="Fetch" class="icon cfg_btn_tab" onclick="fetchFile(${i})"></button>
<label id="process#${i}"></label>
<a id="download#${i}" title="Download" class="icon cfg_btn_tab" href="" download="" style="display:none"></a>
<button id="open#${i}" title="Open" class="icon cfg_btn_tab" onclick="openFile(EL('download#${i}').href)" style="display:none"></button>
</div>`;}}
inner+=`<div class="fs_info">Used ${(device.used / 1000).toFixed(2)} kB (${Math.round(device.used / device.total * 100)}%) from ${(device.total / 1000).toFixed(2)} kB (${((device.total - device.used) / 1000).toFixed(2)} kB free)</div>`;EL('fsbr_inner').innerHTML=inner;let accept=device.gzip?'.gz':'.bin';EL('ota_upload').accept=accept;EL('ota_upload_fs').accept=accept;}
function openFSctrl(i){let current=EL(`fs#${i}`).style.display=='flex';document.querySelectorAll('.fs_controls').forEach(el=>el.style.display='none');if(!current)EL(`fs#${i}`).style.display='flex';}
function renameFile(i){if(fetching||uploading){showPopupError('Busy');return;}
let path=fs_arr[i];let res=prompt('Rename '+path+' to',path);if(res&&res!=path)post('rename',path,res);}
function deleteFile(i){if(fetching||uploading){showPopupError('Busy');return;}
let path=fs_arr[i];if(confirm('Delete '+path+'?'))post('delete',path);}
function fetchFile(i){if(fetching||uploading){showPopupError('Busy');return;}
EL('download#'+i).style.display='none';EL('open#'+i).style.display='none';EL('process#'+i).style.display='unset';EL('process#'+i).innerHTML='';let path=fs_arr[i];fetch_index=i;fetch_name=path.split('/').pop();post('fetch',path);}
function openFile(src){let w=window.open();w.document.write('<iframe src="'+src+'" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>');}
function format_h(){if(confirm('Format filesystem?'))post('format');}
function uploadFile(arg){if(fetching||uploading){showPopupError('Busy');return;}
let reader=new FileReader();reader.onload=function(e){if(!e.target.result)return;let buffer=new Uint8Array(e.target.result);if(!confirm('Upload '+file_upload_path.value+arg.files[0].name+' ('+buffer.length+' bytes)?'))return;upload_bytes=[];for(b of buffer)upload_bytes.push(b);upload_size=upload_bytes.length;post('upload',file_upload_path.value+arg.files[0].name);arg.value=null;}
reader.readAsArrayBuffer(arg.files[0]);}
function uploadNextChunk(){let i=0;let data='';while(true){if(!upload_bytes.length)break;i++;data+=String.fromCharCode(upload_bytes.shift());if(i>=devices[focused].max_upl*3/4)break;}
EL('file_upload_btn').innerHTML=Math.round((upload_size-upload_bytes.length)/upload_size*100)+'%';post('upload_chunk',(upload_bytes.length)?'next':'last',window.btoa(data));}
function uploadOta(arg,type){if(fetching||uploading){showPopupError('Busy');return;}
if(!confirm('Upload OTA '+type+'?'))return;let reader=new FileReader();reader.onload=function(e){if(!e.target.result)return;let buffer=new Uint8Array(e.target.result);upload_bytes=[];for(b of buffer)upload_bytes.push(b);upload_size=upload_bytes.length;post('ota',type);arg.value=null;}
reader.readAsArrayBuffer(arg.files[0]);}
function otaNextChunk(){let i=0;let data='';while(true){if(!upload_bytes.length)break;i++;data+=String.fromCharCode(upload_bytes.shift());if(i>=devices[focused].max_upl*3/4)break;}
EL('ota_label').innerHTML=Math.round((upload_size-upload_bytes.length)/upload_size*100)+'%';post('ota_chunk',(upload_bytes.length)?'next':'last',window.btoa(data));}
function otaUrl(url,type){post('ota_url',type,url);}
let push_timer=0;function applyUpdate(name,value){let el=EL('#'+name);if(!el)return;cl=el.classList;if(cl.contains('icon_t'))el.style.color=value;else if(cl.contains('text_t'))el.innerHTML=value;else if(cl.contains('input_t'))el.value=value;else if(cl.contains('date_t'))el.value=new Date(ctrl.value*1000).toISOString().split('T')[0];else if(cl.contains('time_t'))el.value=new Date(ctrl.value*1000).toISOString().split('T')[1].split('.')[0];else if(cl.contains('datetime_t'))el.value=new Date(ctrl.value*1000).toISOString().split('.')[0];else if(cl.contains('slider_t'))el.value=value,EL('out#'+name).innerHTML=value,moveSlider(el,false);else if(cl.contains('switch_t'))el.checked=(value=='1');else if(cl.contains('select_t'))el.value=value;else if(cl.contains('canvas_t'))drawCanvas(el,value);else if(cl.contains('gauge_t')){if(name in gauges){gauges[name].value=Number(value);drawGauge(gauges[name]);}}
else if(cl.contains('flags_t')){let flags=document.getElementById('#'+name).getElementsByTagName('input');let val=value;for(let i=0;i<flags.length;i++){flags[i].checked=val&1;val>>=1;}}}
function updateDevice(mem,dev){mem.id=dev.id;mem.name=dev.name;mem.icon=dev.icon;mem.PIN=dev.PIN;mem.version=dev.version;mem.max_upl=dev.max_upl;mem.esp=dev.esp;save_devices();}
function compareDevice(mem,dev){return mem.id!=dev.id||mem.name!=dev.name||mem.icon!=dev.icon||mem.PIN!=dev.PIN||mem.version!=dev.version||mem.max_upl!=dev.max_upl||mem.esp!=dev.esp;}
function parseDevice(fromID,text,conn,ip='unset'){let device;try{device=JSON.parse(text.replaceAll("\'","\""));}catch(e){log('Wrong packet (JSON)');return;}
let id=device.id;if(!id)return log('Wrong packet (ID)');if(fromID!='broadcast'&&fromID!=id)return log('Wrong packet (Unknown ID)');if(fromID=='broadcast'&&device.type!='discover'&&device.type!='update'&&device.type!='push'&&device.type!='print')return log('Wrong packet (error)');log('Got packet from #'+id+' '+device.type+' via '+ConnNames[conn]);if(id==focused){stop_tout();showErr(false);change_conn(devices_t[focused].conn);}
switch(device.type){case'OK':break;case'ERR':showPopupError('Error');break;case'discover':if(focused)return;if(id in devices){let upd=false;if(compareDevice(devices[id],device))upd=true;if(devices[id].ip=='unset'&&ip!='unset'){devices[id].ip=ip;upd=true;}
if(upd){log('Update device #'+id);updateDevice(devices[id],device);EL(`icon#${id}`).innerHTML=device.icon?device.icon:'';EL(`name#${id}`).innerHTML=device.name?device.name:'Unknown';}}else{log('Add new device #'+id);devices[id]={prefix:cfg.prefix,break_widgets:false,show_names:false,skip_version:device.version,ip:ip};updateDevice(devices[id],device);if(mq_state()){mq_client.subscribe(devices[id].prefix+'/hub/'+id+'/get/#');mq_client.subscribe(devices[id].prefix+'/hub/'+cfg.hub_id+'/#');if(!mq_pref_list.includes(devices[id].prefix))mq_pref_list.push(devices[id].prefix);}
addDevice(id);}
if(!(id in devices_t)){devices_t[id]={conn:Conn.NONE,ws:null,controls:null,granted:false,buffer:{ws:'',mq:'',serial:'',bt:''}};}
EL(`device#${id}`).className="device";EL(`${ConnNames[conn]}#${id}`).style.display='unset';if(conn<devices_t[id].conn)devices_t[id].conn=conn;break;case'print':if(id!=focused)return;printCLI(device.text,device.color);break;case'update':if(id!=focused)return;if(!(id in devices))return;Object.keys(device.updates).forEach(name=>{applyUpdate(name,device.updates[name]);});break;case'ui':if(id!=focused)return;devices_t[id].controls=device.controls;showControls(device.controls,id);break;case'info':if(id!=focused)return;showInfo(device);break;case'push':if(!(id in devices))return;let date=(new Date).getTime();if(date-push_timer<3000)return;push_timer=date;showNotif(device.text,devices[id].name);break;case'fsbr':if(id!=focused)return;showFsbr(device);break;case'fs_error':if(id!=focused)return;EL('fsbr_inner').innerHTML='<div class="fs_err">FS ERROR</div>';break;case'fetch_err':if(id!=focused)return;EL('process#'+fetch_index).innerHTML='Aborted';showPopupError('Fetch aborted');stopFS();break;case'fetch_start':if(id!=focused)return;fetching=focused;fetch_file='';post('fetch_chunk');reset_fetch_tout();break;case'fetch_next_chunk':if(id!=fetching)return;fetch_file+=device.data;if(device.chunk==device.amount-1){EL('download#'+fetch_index).style.display='unset';EL('download#'+fetch_index).href='data:'+getMime(fetch_name)+';base64,'+fetch_file;EL('download#'+fetch_index).download=fetch_name;EL('open#'+fetch_index).style.display='unset';EL('process#'+fetch_index).style.display='none';stopFS();}else{EL('process#'+fetch_index).innerHTML=Math.round(device.chunk/device.amount*100)+'%';post('fetch_chunk');reset_fetch_tout();}
break;case'upload_err':showPopupError('Upload aborted');EL('file_upload_btn').innerHTML='Error!';setTimeout(()=>EL('file_upload_btn').innerHTML='Upload',2000);stopFS();break;case'upload_start':if(id!=focused)return;uploading=focused;uploadNextChunk();reset_upload_tout();break;case'upload_next_chunk':if(id!=uploading)return;uploadNextChunk();reset_upload_tout();break;case'upload_end':showPopup('Upload Done!');stopFS();EL('file_upload_btn').innerHTML='Done!';setTimeout(()=>EL('file_upload_btn').innerHTML='Upload',2000);post('fsbr');break;case'ota_err':showPopupError('Ota aborted');EL('ota_label').innerHTML='Error!';setTimeout(()=>EL('ota_label').innerHTML='',3000);stopFS();break;case'ota_start':if(id!=focused)return;uploading=focused;otaNextChunk();reset_ota_tout();break;case'ota_next_chunk':if(id!=uploading)return;otaNextChunk();reset_ota_tout();break;case'ota_end':showPopup('OTA Done!');stopFS();EL('ota_label').innerHTML='Done!';setTimeout(()=>EL('ota_label').innerHTML='',3000);break;case'ota_url_ok':showPopup('OTA Done!');break;case'ota_url_err':showPopupError('OTA Error!');break;}}
function showControls(controls){EL('controls').innerHTML='';if(!controls)return;gauges={};pickers={};dup_names=[];wid_row_count=0;btn_row_count=0;wid_row_id=null;btn_row_id=null;for(ctrl of controls){if(devices[focused].show_names&&ctrl.name)ctrl.label=ctrl.name;switch(ctrl.type){case'gauge':addGauge(ctrl);break;case'js':eval(ctrl.value);break;case'canvas':addCanvas(ctrl);break;case'button':addButton(ctrl);break;case'button_i':addButtonIcon(ctrl);break;case'spacer':addSpace(ctrl);break;case'tabs':addTabs(ctrl);break;case'title':addTitle(ctrl);break;case'led':addLED(ctrl);break;case'label':addLabel(ctrl);break;case'icon':addIcon(ctrl);break;case'input':addInput(ctrl);break;case'pass':addPass(ctrl);break;case'slider':addSlider(ctrl);break;case'sliderW':addSliderW(ctrl);break;case'switch':addSwitch(ctrl);break;case'switch_i':addSwitchIcon(ctrl);break;case'switch_t':addSwitchText(ctrl);break;case'date':addDate(ctrl);break;case'time':addTime(ctrl);break;case'datetime':addDateTime(ctrl);break;case'select':addSelect(ctrl);break;case'week':addWeek(ctrl);break;case'color':addColor(ctrl);break;case'spinner':addSpinner(ctrl);break;case'display':addDisplay(ctrl);break;case'html':addHTML(ctrl);break;case'flags':addFlags(ctrl);break;case'log':addLog(ctrl);break;case'widget_b':beginWidgets(ctrl);break;case'widget_e':endWidgets();break;}}
if(devices[focused].show_names){let labels=document.querySelectorAll(".widget_label");for(let lbl of labels)lbl.classList.add('widget_label_name');}
setTimeout(()=>{resizeSpinners();resizeChbuttons();scrollDown();moveSliders();showColors();showCanvases(controls);showGauges();if(dup_names.length)showPopupError('Duplicated names: '+dup_names);},10);}
function showInfo(device){EL('info_lib_v').innerHTML=device.info[0];EL('info_firm_v').innerHTML=device.info[1];if(device.info.length==2)return;let count=2;Object.keys(info_labels_esp).forEach(id=>{EL(id).innerHTML=device.info[count];count++;});let ver=EL('info_firm_v').innerHTML;if(projects&&ver.split('@')[0]in projects){EL('info_firm_v').onclick=function(){checkUpdates(focused,true);};EL('info_firm_v').classList.add('info_link');}else{EL('info_firm_v').onclick=function(){};EL('info_firm_v').classList.remove('info_link');}}
let screen='main';let deferredPrompt=null;let pin_id=null;let started=false;let show_version=false;let cfg_changed=false;let projects=null;let cfg={prefix:'MyDevices',use_ws:false,use_hook:true,client_ip:'192.168.1.1',netmask:24,use_bt:false,use_serial:false,use_mqtt:false,mq_host:'test.mosquitto.org',mq_port:'8081',mq_login:'',mq_pass:'',use_pin:false,hub_pin:'',hub_id:navigator.userAgent.toString().hashCode().toString(16),ui_width:450,theme:'DARK',maincolor:'GREEN',font:'monospace',version:app_version};document.addEventListener('keydown',function(e){if(!started)return;switch(e.keyCode){case 116:if(!e.ctrlKey){e.preventDefault();refresh_h();}
break;case 192:if(focused){e.preventDefault();toggleCLI();}
break;default:break;}});window.onload=function(){window.history.pushState({page:1},"","");window.onpopstate=function(e){window.history.pushState({page:1},"","");back_h();}
render_main(app_version);EL('title').innerHTML=app_title;load_cfg();let title='GyverHUB v'+app_version+' ['+cfg.hub_id+'] '+(isPWA()?'PWA ':'')+(isSSL()?'SSL ':'')+(isLocal()?'Local ':'')+(isESP()?'ESP':'');EL('title').title=title;log(title);if(cfg.use_pin)show_keypad(true);else startup();started=true;}
function startup(){if(isESP())cfg.use_ws=true;render_selects();render_info();show_screen('main');apply_cfg();load_devices();render_devices();discover();}
function checkUpdates(id,force=false){return false;}
function pass_type(v){pass_inp.value+=v;let hash=pass_inp.value.hashCode();if(pin_id){if(hash==devices[pin_id].PIN){open_device(pin_id);pass_inp.value='';devices_t[pin_id].granted=true;}}else{if(hash==cfg.hub_pin){EL('password').style.display='none';startup();pass_inp.value='';}}}
function check_type(arg){if(arg.value.length>0){let c=arg.value[arg.value.length-1];if(c<'0'||c>'9')arg.value=arg.value.slice(0,-1);}}
function show_keypad(v){if(v){EL('password').style.display='block';EL('pass_inp').focus();}else{EL('password').style.display='none';}}
function render_devices(){EL('devices').innerHTML='';Object.keys(devices).forEach(id=>{addDevice(id);if(devices[id].prefix==undefined){devices[id].prefix=cfg.prefix;save_devices();}});}
function render_info(){Object.keys(info_labels_topics).forEach(id=>{EL('info_topics').innerHTML+=`
<div class="cfg_row info">
<label>${info_labels_topics[id]}</label>
<label id="${id}" class="lbl_info info_small">-</label>
</div>`;});Object.keys(info_labels_version).forEach(id=>{EL('info_version').innerHTML+=`
<div class="cfg_row info">
<label>${info_labels_version[id]}</label>
<label id="${id}" class="lbl_info">-</label>
</div>`;});Object.keys(info_labels_esp).forEach(id=>{EL('info_esp').innerHTML+=`
<div class="cfg_row info">
<label>${info_labels_esp[id]}</label>
<label id="${id}" class="lbl_info">-</label>
</div>`;});EL('info_esp').innerHTML+='<div style="padding:10px"><button class="c_btn btn_mini" onclick="reboot_h()"><span class="icon info_icon"></span>Reboot</button></div>';EL('info_l_ip').onclick=function(){window.open('http://'+devices[focused].ip,'_blank').focus();};EL('info_l_ip').classList.add('info_link');}
function update_info(){let id=focused;EL('info_break_sw').checked=devices[id].break_widgets;EL('info_names_sw').checked=devices[id].show_names;EL('info_cli_sw').checked=EL('cli_cont').style.display=='block';EL('info_id').innerHTML=id;EL('info_set').innerHTML=devices[id].prefix+'/'+id+'/set/*';EL('info_read').innerHTML=devices[id].prefix+'/'+id+'/read/*';EL('info_get').innerHTML=devices[id].prefix+'/hub/'+id+'/get/*';EL('info_status').innerHTML=devices[id].prefix+'/hub/'+id+'/status';}
function render_selects(){Object.keys(colors).forEach(color=>{EL('maincolor').innerHTML+=`
<option value="${color}">${color}</option>`;});for(let font of fonts){EL('font').innerHTML+=`
<option value="${font}">${font}</option>`;}
Object.keys(themes).forEach(theme=>{EL('theme').innerHTML+=`
<option value="${theme}">${theme}</option>`;});for(let i=0;i<33;i++){let imask;if(i==32)imask=0xffffffff;else imask=~(0xffffffff>>>i);EL('netmask').innerHTML+=`
<option value="${i}">${intToOctets(imask)}</option>`;}}
function refresh_h(){if(screen=='device')post('focus');else if(screen=='info')post('info');else if(screen=='fsbr')post('fsbr');else discover();}
function back_h(){if(screen=='device'){showErr(false);switch(devices_t[focused].conn){case Conn.SERIAL:break;case Conn.BT:break;case Conn.WS:ws_stop(focused);refreshSpin(false);break;case Conn.MQTT:post('unfocus');break;}
log('Close device #'+focused);focused=null;show_screen('main');stop_ping();stop_tout();}
else if(screen=='info')info_h();else if(screen=='fsbr')fsbr_h();else if(screen=='config')config_h();else if(screen=='pin')show_screen('main');}
function config_h(){if(screen=='config'){if(cfg_changed)save_cfg();cfg_changed=false;show_screen('main');discover();}else{show_screen('config');}}
function info_h(){if(screen=='device'){post('info');show_screen('info');}else{post('focus');show_screen('device');}}
function fsbr_h(){if(screen=='device'){post('fsbr');EL('fsbr_inner').innerHTML='<div class="fsbr_wait"><span style="font-size:50px;color:var(--prim)" class="icon spinning"></span></div>';show_screen('fsbr');}else{post('focus');show_screen('device');}}
function device_h(id){if(discovering)return;if(!(id in devices_t)||devices_t[id].conn==Conn.NONE){delete_h(id);return;}
if(!devices[id])return;if(devices[id].PIN&&!devices_t[id].granted){pin_id=id;show_screen('pin');}else open_device(id);}
function open_device(id){if(checkUpdates(id))return;focused=id;switch(devices_t[id].conn){case Conn.SERIAL:break;case Conn.BT:break;case Conn.WS:refreshSpin(true);ws_start(id);ws_focus_flag=true;break;case Conn.MQTT:post('focus');break;}
log('Open device #'+id+' via '+ConnNames[devices_t[id].conn]);showControls(devices_t[id].controls);show_screen('device');reset_ping();}
function clear_all(){EL('devices').innerHTML="";devices={};devices_t={};save_devices();show_screen('main');}
function show_screen(nscreen){screen=nscreen;stopFS();show_keypad(false);let config_s=EL('config').style;let devices_s=EL('devices').style;let controls_s=EL('controls').style;let info_s=EL('info').style;let fsbr_s=EL('fsbr').style;let icon_info_s=EL('icon_info').style;let icon_cfg_s=EL('icon_cfg').style;let icon_fsbr_s=EL('icon_fsbr').style;let icon_refresh_s=EL('icon_refresh').style;let back_s=EL('back').style;let version_s=EL('version').style;let title_row_s=EL('title_row').style;config_s.display='none';devices_s.display='none';controls_s.display='none';info_s.display='none';icon_info_s.display='none';icon_cfg_s.display='none';icon_fsbr_s.display='none';fsbr_s.display='none';back_s.display='none';icon_refresh_s.display='none';version_s.display='none';title_row_s.cursor='pointer';EL('title').innerHTML=app_title;if(screen=='main'){version_s.display='unset';devices_s.display='grid';icon_cfg_s.display='inline-block';icon_refresh_s.display='inline-block';title_row_s.cursor='unset';EL('conn').innerHTML='';showCLI(false);}else if(screen=='device'){controls_s.display='block';icon_info_s.display='inline-block';if(devices[focused].esp){icon_fsbr_s.display='inline-block';}
back_s.display='inline-block';icon_refresh_s.display='inline-block';EL('title').innerHTML=devices[focused].name;}else if(screen=='config'){config_s.display='block';icon_cfg_s.display='inline-block';back_s.display='inline-block';EL('title').innerHTML='Config';}else if(screen=='info'){info_s.display='block';icon_info_s.display='inline-block';icon_fsbr_s.display='inline-block';back_s.display='inline-block';EL('title').innerHTML=devices[focused].name+'/info';update_info();}else if(screen=='fsbr'){fsbr_s.display='block';icon_info_s.display='inline-block';icon_fsbr_s.display='inline-block';back_s.display='inline-block';EL('title').innerHTML=devices[focused].name+'/fs';}else if(screen=='pin'){back_s.display='inline-block';show_keypad(true);}}
function delete_h(id){if(confirm('Delete '+id+'?')){document.getElementById("device#"+id).remove();delete devices[id];save_devices();return 1;}
return 0;}
function printCLI(text,color){if(EL('cli_cont').style.display=='block'){if(EL('cli').innerHTML)EL('cli').innerHTML+='\n';let st=color?`style="color:${intToCol(color)}"`:'';EL('cli').innerHTML+=`><span ${st}">${text}</span>`;EL('cli').scrollTop=EL('cli').scrollHeight;}}
function toggleCLI(){EL('cli').innerHTML="";EL('cli_input').value="";showCLI(!(EL('cli_cont').style.display=='block'));}
function showCLI(v){EL('bottom_space').style.height=v?'170px':'70px';EL('cli_cont').style.display=v?'block':'none';if(v)EL('cli_input').focus();EL('info_cli_sw').checked=v;}
function checkCLI(){if(event.key=='Enter')sendCLI();}
function sendCLI(){post('cli','cli',EL('cli_input').value);EL('cli_input').value="";}
function sendDiscover(){if(cfg.use_mqtt)mq_discover();if(cfg.use_ws&&!isSSL())ws_discover();}
function discover(){if(isESP()){let has=false;Object.keys(devices).forEach(id=>{if(window.location.href.includes(devices[id].ip))has=true;});if(!has)ws_discover_ip(window_ip());}
Object.keys(devices).forEach(id=>{if(id in devices_t)devices_t[id].conn=Conn.NONE;EL(`device#${id}`).className="device offline";EL(`Serial#${id}`).style.display='none';EL(`BT#${id}`).style.display='none';EL(`WS#${id}`).style.display='none';EL(`MQTT#${id}`).style.display='none';});sendDiscover();}
function discover_all(){if(cfg.use_mqtt)mq_discover_all();if(cfg.use_ws&&!isSSL())ws_discover_all();back_h();}
function mq_change(start=false){mq_show_err(1);mq_stop();if(start)mq_start();}
function update_cfg(el){cfg_changed=true;if(el.type=='text')el.value=el.value.trim();if(el.type=='checkbox')cfg[el.id]=el.checked;else cfg[el.id]=el.value;updateTheme();}
function save_cfg(){localStorage.setItem('config',JSON.stringify(cfg));}
function load_cfg(){if(localStorage.hasOwnProperty('config')){let cfg_r=JSON.parse(localStorage.getItem('config'));let dif=false;Object.keys(cfg).forEach(key=>{if(cfg_r[key]===undefined){cfg_r[key]=cfg[key];dif=true;}});if(cfg_r['version']!=cfg['version']){cfg_r['version']=cfg['version'];dif=true;show_version=true;}
cfg=cfg_r;if(dif)save_cfg();}else{if('Notification'in window&&Notification.permission=='default')Notification.requestPermission();}
updateTheme();}
function apply_cfg(){Object.keys(cfg).forEach(key=>{if(key=='version')return;let el=EL(key);if(el==undefined)return;if(el.type=='checkbox')el.checked=cfg[key];else el.value=cfg[key];});updateTheme();}
async function cfg_export(){try{const text=btoa(JSON.stringify(cfg))+','+btoa(encodeURIComponent(JSON.stringify(devices)));await navigator.clipboard.writeText(text);showPopup('Copied to clipboard');}catch(err){showPopupError('Export error');}}
async function cfg_import(){try{let text=await navigator.clipboard.readText();try{cfg=JSON.parse(atob(text.split(',')[0]));}catch(e){}
apply_cfg();save_cfg();try{devices=JSON.parse(decodeURIComponent(atob(text.split(',')[1])));}catch(e){}
render_devices();save_devices();showPopup('Import done');}catch(e){showPopupError('Wrong data');}}
function updateTheme(){let v=themes[cfg.theme];let r=document.querySelector(':root');r.style.setProperty('--back',theme_cols[v][0]);r.style.setProperty('--tab',theme_cols[v][1]);r.style.setProperty('--font',theme_cols[v][2]);r.style.setProperty('--font2',theme_cols[v][3]);r.style.setProperty('--dark',theme_cols[v][4]);r.style.setProperty('--thumb',theme_cols[v][5]);r.style.setProperty('--black',theme_cols[v][6]);r.style.setProperty('--scheme',theme_cols[v][7]);r.style.setProperty('--font_inv',theme_cols[v][8]);r.style.setProperty('--shad',theme_cols[v][9]);r.style.setProperty('--ui_width',cfg.ui_width+'px');r.style.setProperty('--prim',intToCol(colors[cfg.maincolor]));r.style.setProperty('--font_f',cfg.font);let b='block';let n='none';let f='var(--font)';let f3='var(--font3)';EL('ws_block').style.display=cfg.use_ws?b:n;EL('ws_label').style.color=cfg.use_ws?f:f3;EL('pin_block').style.display=cfg.use_pin?b:n;EL('pin_label').style.color=cfg.use_pin?f:f3;}
(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";window.sortPaths=require("./sort-paths.js");
},{"./sort-paths.js":3}],2:[function(require,module,exports){
"use strict";function splitRetain(e,t,r){if(r=defaults(r,{}),r.leadingSeparator=defaults(r.leadingSeparator,!1),assert.type(e,"string","`string` is not a string"),assert("string"==typeof t||t instanceof RegExp,"invalid `separator` type"),assert.type(r,"object","invalid `options` type"),assert.type(r.leadingSeparator,"boolean","invalid `options.leadingSeparator` type"),0===e.length)return[""];t=separatorToRegex(t);var n=e.split(t);if(1===n.length)return n;var s=[];for(r.leadingSeparator&&s.push(n.shift());n.length>0;)1===n.length?s.push(n.shift()):s.push(n.shift()+n.shift());return""===s[0]&&s.shift(),""===s[s.length-1]&&s.pop(),s}function separatorToRegex(e){return e instanceof RegExp?e:new RegExp("("+escapeRegex(e)+")","g")}function escapeRegex(e){return e.replace(/[-[\]{}()*+?.,\\^$|#\s]/g,"\\$&")}function assert(e,t){if(!e)throw new Error(t)}function defaults(e,t){return void 0===e?t:e}exports=module.exports=splitRetain,splitRetain.VERSION="1.0.1",assert.type=function(e,t,r){if(typeof e!==t)throw new Error(r)};
},{}],3:[function(require,module,exports){
"use strict";function sortPaths(t){assert(arguments.length>=2,"too few arguments"),assert(arguments.length<=3,"too many arguments");var r,e;2===arguments.length?(r=identity,e=arguments[1]):(r=arguments[1],e=arguments[2]),assert(isArray(t),"items is not an array"),assert(isFunction(r),"iteratee is not a function"),assert("string"==typeof e,"dirSeparator is not a String"),assert(1===e.length,"dirSeparator must be a single character");var n=t.map(function(t){var n=r(t);return assert("string"==typeof n,"item or iteratee(item) must be a String"),{item:t,pathTokens:splitRetain(n,e)}});return n.sort(createItemDTOComparator(e)),n.map(function(t){return t.item})}function createItemDTOComparator(t){return function(r,e){for(var n=r.pathTokens,a=e.pathTokens,o=0,i=Math.max(n.length,a.length);o<i;o++){if(!(o in n))return-1;if(!(o in a))return 1;var s=n[o].toLowerCase(),u=a[o].toLowerCase();if(s!==u){var c=s[s.length-1]===t;return c===(u[u.length-1]===t)?s<u?-1:1:c?1:-1}}return 0}}function assert(t,r){if(!t)throw new Error(r)}function identity(t){return t}function isFunction(t){return Boolean(t)&&"[object Function]"===Object.prototype.toString.call(t)}function isArray(t){return Boolean(t)&&"[object Array]"===Object.prototype.toString.call(t)}var splitRetain=require("split-retain");module.exports=sortPaths,sortPaths.VERSION="1.1.1";
},{"split-retain":2}]},{},[1]);
!function(t,e){"object"==typeof exports&&"object"==typeof module?module.exports=e():"function"==typeof define&&define.amd?define([],e):"object"==typeof exports?exports.Pickr=e():t.Pickr=e()}(self,(function(){return(()=>{"use strict";var t={d:(e,o)=>{for(var n in o)t.o(o,n)&&!t.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:o[n]})},o:(t,e)=>Object.prototype.hasOwnProperty.call(t,e),r:t=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})}},e={};t.d(e,{default:()=>L});var o={};function n(t,e,o,n,i={}){e instanceof HTMLCollection||e instanceof NodeList?e=Array.from(e):Array.isArray(e)||(e=[e]),Array.isArray(o)||(o=[o]);for(const s of e)for(const e of o)s[t](e,n,{capture:!1,...i});return Array.prototype.slice.call(arguments,1)}t.r(o),t.d(o,{adjustableInputNumbers:()=>p,createElementFromString:()=>r,createFromTemplate:()=>a,eventPath:()=>l,off:()=>s,on:()=>i,resolveElement:()=>c});const i=n.bind(null,"addEventListener"),s=n.bind(null,"removeEventListener");function r(t){const e=document.createElement("div");return e.innerHTML=t.trim(),e.firstElementChild}function a(t){const e=(t,e)=>{const o=t.getAttribute(e);return t.removeAttribute(e),o},o=(t,n={})=>{const i=e(t,":obj"),s=e(t,":ref"),r=i?n[i]={}:n;s&&(n[s]=t);for(const n of Array.from(t.children)){const t=e(n,":arr"),i=o(n,t?{}:r);t&&(r[t]||(r[t]=[])).push(Object.keys(i).length?i:n)}return n};return o(r(t))}function l(t){let e=t.path||t.composedPath&&t.composedPath();if(e)return e;let o=t.target.parentElement;for(e=[t.target,o];o=o.parentElement;)e.push(o);return e.push(document,window),e}function c(t){return t instanceof Element?t:"string"==typeof t?t.split(/>>/g).reduce(((t,e,o,n)=>(t=t.querySelector(e),o<n.length-1?t.shadowRoot:t)),document):null}function p(t,e=(t=>t)){function o(o){const n=[.001,.01,.1][Number(o.shiftKey||2*o.ctrlKey)]*(o.deltaY<0?1:-1);let i=0,s=t.selectionStart;t.value=t.value.replace(/[\d.]+/g,((t,o)=>o<=s&&o+t.length>=s?(s=o,e(Number(t),n,i)):(i++,t))),t.focus(),t.setSelectionRange(s,s),o.preventDefault(),t.dispatchEvent(new Event("input"))}i(t,"focus",(()=>i(window,"wheel",o,{passive:!1}))),i(t,"blur",(()=>s(window,"wheel",o)))}const{min:u,max:h,floor:d,round:m}=Math;function f(t,e,o){e/=100,o/=100;const n=d(t=t/360*6),i=t-n,s=o*(1-e),r=o*(1-i*e),a=o*(1-(1-i)*e),l=n%6;return[255*[o,r,s,s,a,o][l],255*[a,o,o,r,s,s][l],255*[s,s,a,o,o,r][l]]}function v(t,e,o){const n=(2-(e/=100))*(o/=100)/2;return 0!==n&&(e=1===n?0:n<.5?e*o/(2*n):e*o/(2-2*n)),[t,100*e,100*n]}function b(t,e,o){const n=u(t/=255,e/=255,o/=255),i=h(t,e,o),s=i-n;let r,a;if(0===s)r=a=0;else{a=s/i;const n=((i-t)/6+s/2)/s,l=((i-e)/6+s/2)/s,c=((i-o)/6+s/2)/s;t===i?r=c-l:e===i?r=1/3+n-c:o===i&&(r=2/3+l-n),r<0?r+=1:r>1&&(r-=1)}return[360*r,100*a,100*i]}function y(t,e,o,n){e/=100,o/=100;return[...b(255*(1-u(1,(t/=100)*(1-(n/=100))+n)),255*(1-u(1,e*(1-n)+n)),255*(1-u(1,o*(1-n)+n)))]}function g(t,e,o){e/=100;const n=2*(e*=(o/=100)<.5?o:1-o)/(o+e)*100,i=100*(o+e);return[t,isNaN(n)?0:n,i]}function _(t){return b(...t.match(/.{2}/g).map((t=>parseInt(t,16))))}function w(t){t=t.match(/^[a-zA-Z]+$/)?function(t){if("black"===t.toLowerCase())return"#000";const e=document.createElement("canvas").getContext("2d");return e.fillStyle=t,"#000"===e.fillStyle?null:e.fillStyle}(t):t;const e={cmyk:/^cmyk[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)/i,rgba:/^((rgba)|rgb)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,hsla:/^((hsla)|hsl)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,hsva:/^((hsva)|hsv)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,hexa:/^#?(([\dA-Fa-f]{3,4})|([\dA-Fa-f]{6})|([\dA-Fa-f]{8}))$/i},o=t=>t.map((t=>/^(|\d+)\.\d+|\d+$/.test(t)?Number(t):void 0));let n;t:for(const i in e){if(!(n=e[i].exec(t)))continue;const s=t=>!!n[2]==("number"==typeof t);switch(i){case"cmyk":{const[,t,e,s,r]=o(n);if(t>100||e>100||s>100||r>100)break t;return{values:y(t,e,s,r),type:i}}case"rgba":{const[,,,t,e,r,a]=o(n);if(t>255||e>255||r>255||a<0||a>1||!s(a))break t;return{values:[...b(t,e,r),a],a,type:i}}case"hexa":{let[,t]=n;4!==t.length&&3!==t.length||(t=t.split("").map((t=>t+t)).join(""));const e=t.substring(0,6);let o=t.substring(6);return o=o?parseInt(o,16)/255:void 0,{values:[..._(e),o],a:o,type:i}}case"hsla":{const[,,,t,e,r,a]=o(n);if(t>360||e>100||r>100||a<0||a>1||!s(a))break t;return{values:[...g(t,e,r),a],a,type:i}}case"hsva":{const[,,,t,e,r,a]=o(n);if(t>360||e>100||r>100||a<0||a>1||!s(a))break t;return{values:[t,e,r,a],a,type:i}}}}return{values:null,type:null}}function A(t=0,e=0,o=0,n=1){const i=(t,e)=>(o=-1)=>e(~o?t.map((t=>Number(t.toFixed(o)))):t),s={h:t,s:e,v:o,a:n,toHSVA(){const t=[s.h,s.s,s.v,s.a];return t.toString=i(t,(t=>`hsva(${t[0]}, ${t[1]}%, ${t[2]}%, ${s.a})`)),t},toHSLA(){const t=[...v(s.h,s.s,s.v),s.a];return t.toString=i(t,(t=>`hsla(${t[0]}, ${t[1]}%, ${t[2]}%, ${s.a})`)),t},toRGBA(){const t=[...f(s.h,s.s,s.v),s.a];return t.toString=i(t,(t=>`rgba(${t[0]}, ${t[1]}, ${t[2]}, ${s.a})`)),t},toCMYK(){const t=function(t,e,o){const n=f(t,e,o),i=n[0]/255,s=n[1]/255,r=n[2]/255,a=u(1-i,1-s,1-r);return[100*(1===a?0:(1-i-a)/(1-a)),100*(1===a?0:(1-s-a)/(1-a)),100*(1===a?0:(1-r-a)/(1-a)),100*a]}(s.h,s.s,s.v);return t.toString=i(t,(t=>`cmyk(${t[0]}%, ${t[1]}%, ${t[2]}%, ${t[3]}%)`)),t},toHEXA(){const t=function(t,e,o){return f(t,e,o).map((t=>m(t).toString(16).padStart(2,"0")))}(s.h,s.s,s.v),e=s.a>=1?"":Number((255*s.a).toFixed(0)).toString(16).toUpperCase().padStart(2,"0");return e&&t.push(e),t.toString=()=>`#${t.join("").toUpperCase()}`,t},clone:()=>A(s.h,s.s,s.v,s.a)};return s}const C=t=>Math.max(Math.min(t,1),0);function $(t){const e={options:Object.assign({lock:null,onchange:()=>0,onstop:()=>0},t),_keyboard(t){const{options:o}=e,{type:n,key:i}=t;if(document.activeElement===o.wrapper){const{lock:o}=e.options,s="ArrowUp"===i,r="ArrowRight"===i,a="ArrowDown"===i,l="ArrowLeft"===i;if("keydown"===n&&(s||r||a||l)){let n=0,i=0;"v"===o?n=s||r?1:-1:"h"===o?n=s||r?-1:1:(i=s?-1:a?1:0,n=l?-1:r?1:0),e.update(C(e.cache.x+.01*n),C(e.cache.y+.01*i)),t.preventDefault()}else i.startsWith("Arrow")&&(e.options.onstop(),t.preventDefault())}},_tapstart(t){i(document,["mouseup","touchend","touchcancel"],e._tapstop),i(document,["mousemove","touchmove"],e._tapmove),t.cancelable&&t.preventDefault(),e._tapmove(t)},_tapmove(t){const{options:o,cache:n}=e,{lock:i,element:s,wrapper:r}=o,a=r.getBoundingClientRect();let l=0,c=0;if(t){const e=t&&t.touches&&t.touches[0];l=t?(e||t).clientX:0,c=t?(e||t).clientY:0,l<a.left?l=a.left:l>a.left+a.width&&(l=a.left+a.width),c<a.top?c=a.top:c>a.top+a.height&&(c=a.top+a.height),l-=a.left,c-=a.top}else n&&(l=n.x*a.width,c=n.y*a.height);"h"!==i&&(s.style.left=`calc(${l/a.width*100}% - ${s.offsetWidth/2}px)`),"v"!==i&&(s.style.top=`calc(${c/a.height*100}% - ${s.offsetHeight/2}px)`),e.cache={x:l/a.width,y:c/a.height};const p=C(l/a.width),u=C(c/a.height);switch(i){case"v":return o.onchange(p);case"h":return o.onchange(u);default:return o.onchange(p,u)}},_tapstop(){e.options.onstop(),s(document,["mouseup","touchend","touchcancel"],e._tapstop),s(document,["mousemove","touchmove"],e._tapmove)},trigger(){e._tapmove()},update(t=0,o=0){const{left:n,top:i,width:s,height:r}=e.options.wrapper.getBoundingClientRect();"h"===e.options.lock&&(o=t),e._tapmove({clientX:n+s*t,clientY:i+r*o})},destroy(){const{options:t,_tapstart:o,_keyboard:n}=e;s(document,["keydown","keyup"],n),s([t.wrapper,t.element],"mousedown",o),s([t.wrapper,t.element],"touchstart",o,{passive:!1})}},{options:o,_tapstart:n,_keyboard:r}=e;return i([o.wrapper,o.element],"mousedown",n),i([o.wrapper,o.element],"touchstart",n,{passive:!1}),i(document,["keydown","keyup"],r),e}function k(t={}){t=Object.assign({onchange:()=>0,className:"",elements:[]},t);const e=i(t.elements,"click",(e=>{t.elements.forEach((o=>o.classList[e.target===o?"add":"remove"](t.className))),t.onchange(e),e.stopPropagation()}));return{destroy:()=>s(...e)}}const S={variantFlipOrder:{start:"sme",middle:"mse",end:"ems"},positionFlipOrder:{top:"tbrl",right:"rltb",bottom:"btrl",left:"lrbt"},position:"bottom",margin:8},O=(t,e,o)=>{const{container:n,margin:i,position:s,variantFlipOrder:r,positionFlipOrder:a}={container:document.documentElement.getBoundingClientRect(),...S,...o},{left:l,top:c}=e.style;e.style.left="0",e.style.top="0";const p=t.getBoundingClientRect(),u=e.getBoundingClientRect(),h={t:p.top-u.height-i,b:p.bottom+i,r:p.right+i,l:p.left-u.width-i},d={vs:p.left,vm:p.left+p.width/2+-u.width/2,ve:p.left+p.width-u.width,hs:p.top,hm:p.bottom-p.height/2-u.height/2,he:p.bottom-u.height},[m,f="middle"]=s.split("-"),v=a[m],b=r[f],{top:y,left:g,bottom:_,right:w}=n;for(const t of v){const o="t"===t||"b"===t,n=h[t],[i,s]=o?["top","left"]:["left","top"],[r,a]=o?[u.height,u.width]:[u.width,u.height],[l,c]=o?[_,w]:[w,_],[p,m]=o?[y,g]:[g,y];if(!(n<p||n+r>l))for(const r of b){const l=d[(o?"v":"h")+r];if(!(l<m||l+a>c))return e.style[s]=l-u[s]+"px",e.style[i]=n-u[i]+"px",t+r}}return e.style.left=l,e.style.top=c,null};function E(t,e,o){return e in t?Object.defineProperty(t,e,{value:o,enumerable:!0,configurable:!0,writable:!0}):t[e]=o,t}class L{constructor(t){E(this,"_initializingActive",!0),E(this,"_recalc",!0),E(this,"_nanopop",null),E(this,"_root",null),E(this,"_color",A()),E(this,"_lastColor",A()),E(this,"_swatchColors",[]),E(this,"_setupAnimationFrame",null),E(this,"_eventListener",{init:[],save:[],hide:[],show:[],clear:[],change:[],changestop:[],cancel:[],swatchselect:[]}),this.options=t=Object.assign({...L.DEFAULT_OPTIONS},t);const{swatches:e,components:o,theme:n,sliders:i,lockOpacity:s,padding:r}=t;["nano","monolith"].includes(n)&&!i&&(t.sliders="h"),o.interaction||(o.interaction={});const{preview:a,opacity:l,hue:c,palette:p}=o;o.opacity=!s&&l,o.palette=p||a||l||c,this._preBuild(),this._buildComponents(),this._bindEvents(),this._finalBuild(),e&&e.length&&e.forEach((t=>this.addSwatch(t)));const{button:u,app:h}=this._root;this._nanopop=((t,e,o)=>{const n="object"!=typeof t||t instanceof HTMLElement?{reference:t,popper:e,...o}:t;return{update(t=n){const{reference:e,popper:o}=Object.assign(n,t);if(!o||!e)throw new Error("Popper- or reference-element missing.");return O(e,o,n)}}})(u,h,{margin:r}),u.setAttribute("role","button"),u.setAttribute("aria-label",this._t("btn:toggle"));const d=this;this._setupAnimationFrame=requestAnimationFrame((function e(){if(!h.offsetWidth)return requestAnimationFrame(e);d.setColor(t.default),d._rePositioningPicker(),t.defaultRepresentation&&(d._representation=t.defaultRepresentation,d.setColorRepresentation(d._representation)),t.showAlways&&d.show(),d._initializingActive=!1,d._emit("init")}))}_preBuild(){const{options:t}=this;for(const e of["el","container"])t[e]=c(t[e]);this._root=(t=>{const{components:e,useAsButton:o,inline:n,appClass:i,theme:s,lockOpacity:r}=t.options,l=t=>t?"":'style="display:none" hidden',c=e=>t._t(e),p=a(`\n      <div :ref="root" class="pickr">\n\n        ${o?"":'<button type="button" :ref="button" class="pcr-button"></button>'}\n\n        <div :ref="app" class="pcr-app ${i||""}" data-theme="${s}" ${n?'style="position: unset"':""} aria-label="${c("ui:dialog")}" role="window">\n          <div class="pcr-selection" ${l(e.palette)}>\n            <div :obj="preview" class="pcr-color-preview" ${l(e.preview)}>\n              <button type="button" :ref="lastColor" class="pcr-last-color" aria-label="${c("btn:last-color")}"></button>\n              <div :ref="currentColor" class="pcr-current-color"></div>\n            </div>\n\n            <div :obj="palette" class="pcr-color-palette">\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="palette" class="pcr-palette" tabindex="0" aria-label="${c("aria:palette")}" role="listbox"></div>\n            </div>\n\n            <div :obj="hue" class="pcr-color-chooser" ${l(e.hue)}>\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="slider" class="pcr-hue pcr-slider" tabindex="0" aria-label="${c("aria:hue")}" role="slider"></div>\n            </div>\n\n            <div :obj="opacity" class="pcr-color-opacity" ${l(e.opacity)}>\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="slider" class="pcr-opacity pcr-slider" tabindex="0" aria-label="${c("aria:opacity")}" role="slider"></div>\n            </div>\n          </div>\n\n          <div class="pcr-swatches ${e.palette?"":"pcr-last"}" :ref="swatches"></div>\n\n          <div :obj="interaction" class="pcr-interaction" ${l(Object.keys(e.interaction).length)}>\n            <input :ref="result" class="pcr-result" type="text" spellcheck="false" ${l(e.interaction.input)} aria-label="${c("aria:input")}">\n\n            <input :arr="options" class="pcr-type" data-type="HEXA" value="${r?"HEX":"HEXA"}" type="button" ${l(e.interaction.hex)}>\n            <input :arr="options" class="pcr-type" data-type="RGBA" value="${r?"RGB":"RGBA"}" type="button" ${l(e.interaction.rgba)}>\n            <input :arr="options" class="pcr-type" data-type="HSLA" value="${r?"HSL":"HSLA"}" type="button" ${l(e.interaction.hsla)}>\n            <input :arr="options" class="pcr-type" data-type="HSVA" value="${r?"HSV":"HSVA"}" type="button" ${l(e.interaction.hsva)}>\n            <input :arr="options" class="pcr-type" data-type="CMYK" value="CMYK" type="button" ${l(e.interaction.cmyk)}>\n\n            <input :ref="save" class="pcr-save" value="${c("btn:save")}" type="button" ${l(e.interaction.save)} aria-label="${c("aria:btn:save")}">\n            <input :ref="cancel" class="pcr-cancel" value="${c("btn:cancel")}" type="button" ${l(e.interaction.cancel)} aria-label="${c("aria:btn:cancel")}">\n            <input :ref="clear" class="pcr-clear" value="${c("btn:clear")}" type="button" ${l(e.interaction.clear)} aria-label="${c("aria:btn:clear")}">\n          </div>\n        </div>\n      </div>\n    `),u=p.interaction;return u.options.find((t=>!t.hidden&&!t.classList.add("active"))),u.type=()=>u.options.find((t=>t.classList.contains("active"))),p})(this),t.useAsButton&&(this._root.button=t.el),t.container.appendChild(this._root.root)}_finalBuild(){const t=this.options,e=this._root;if(t.container.removeChild(e.root),t.inline){const o=t.el.parentElement;t.el.nextSibling?o.insertBefore(e.app,t.el.nextSibling):o.appendChild(e.app)}else t.container.appendChild(e.app);t.useAsButton?t.inline&&t.el.remove():t.el.parentNode.replaceChild(e.root,t.el),t.disabled&&this.disable(),t.comparison||(e.button.style.transition="none",t.useAsButton||(e.preview.lastColor.style.transition="none")),this.hide()}_buildComponents(){const t=this,e=this.options.components,o=(t.options.sliders||"v").repeat(2),[n,i]=o.match(/^[vh]+$/g)?o:[],s=()=>this._color||(this._color=this._lastColor.clone()),r={palette:$({element:t._root.palette.picker,wrapper:t._root.palette.palette,onstop:()=>t._emit("changestop","slider",t),onchange(o,n){if(!e.palette)return;const i=s(),{_root:r,options:a}=t,{lastColor:l,currentColor:c}=r.preview;t._recalc&&(i.s=100*o,i.v=100-100*n,i.v<0&&(i.v=0),t._updateOutput("slider"));const p=i.toRGBA().toString(0);this.element.style.background=p,this.wrapper.style.background=`\n                        linear-gradient(to top, rgba(0, 0, 0, ${i.a}), transparent),\n                        linear-gradient(to left, hsla(${i.h}, 100%, 50%, ${i.a}), rgba(255, 255, 255, ${i.a}))\n                    `,a.comparison?a.useAsButton||t._lastColor||l.style.setProperty("--pcr-color",p):(r.button.style.setProperty("--pcr-color",p),r.button.classList.remove("clear"));const u=i.toHEXA().toString();for(const{el:e,color:o}of t._swatchColors)e.classList[u===o.toHEXA().toString()?"add":"remove"]("pcr-active");c.style.setProperty("--pcr-color",p)}}),hue:$({lock:"v"===i?"h":"v",element:t._root.hue.picker,wrapper:t._root.hue.slider,onstop:()=>t._emit("changestop","slider",t),onchange(o){if(!e.hue||!e.palette)return;const n=s();t._recalc&&(n.h=360*o),this.element.style.backgroundColor=`hsl(${n.h}, 100%, 50%)`,r.palette.trigger()}}),opacity:$({lock:"v"===n?"h":"v",element:t._root.opacity.picker,wrapper:t._root.opacity.slider,onstop:()=>t._emit("changestop","slider",t),onchange(o){if(!e.opacity||!e.palette)return;const n=s();t._recalc&&(n.a=Math.round(100*o)/100),this.element.style.background=`rgba(0, 0, 0, ${n.a})`,r.palette.trigger()}}),selectable:k({elements:t._root.interaction.options,className:"active",onchange(e){t._representation=e.target.getAttribute("data-type").toUpperCase(),t._recalc&&t._updateOutput("swatch")}})};this._components=r}_bindEvents(){const{_root:t,options:e}=this,o=[i(t.interaction.clear,"click",(()=>this._clearColor())),i([t.interaction.cancel,t.preview.lastColor],"click",(()=>{this.setHSVA(...(this._lastColor||this._color).toHSVA(),!0),this._emit("cancel")})),i(t.interaction.save,"click",(()=>{!this.applyColor()&&!e.showAlways&&this.hide()})),i(t.interaction.result,["keyup","input"],(t=>{this.setColor(t.target.value,!0)&&!this._initializingActive&&(this._emit("change",this._color,"input",this),this._emit("changestop","input",this)),t.stopImmediatePropagation()})),i(t.interaction.result,["focus","blur"],(t=>{this._recalc="blur"===t.type,this._recalc&&this._updateOutput(null)})),i([t.palette.palette,t.palette.picker,t.hue.slider,t.hue.picker,t.opacity.slider,t.opacity.picker],["mousedown","touchstart"],(()=>this._recalc=!0),{passive:!0})];if(!e.showAlways){const n=e.closeWithKey;o.push(i(t.button,"click",(()=>this.isOpen()?this.hide():this.show())),i(document,"keyup",(t=>this.isOpen()&&(t.key===n||t.code===n)&&this.hide())),i(document,["touchstart","mousedown"],(e=>{this.isOpen()&&!l(e).some((e=>e===t.app||e===t.button))&&this.hide()}),{capture:!0}))}if(e.adjustableNumbers){const e={rgba:[255,255,255,1],hsva:[360,100,100,1],hsla:[360,100,100,1],cmyk:[100,100,100,100]};p(t.interaction.result,((t,o,n)=>{const i=e[this.getColorRepresentation().toLowerCase()];if(i){const e=i[n],s=t+(e>=100?1e3*o:o);return s<=0?0:Number((s<e?s:e).toPrecision(3))}return t}))}if(e.autoReposition&&!e.inline){let t=null;const n=this;o.push(i(window,["scroll","resize"],(()=>{n.isOpen()&&(e.closeOnScroll&&n.hide(),null===t?(t=setTimeout((()=>t=null),100),requestAnimationFrame((function e(){n._rePositioningPicker(),null!==t&&requestAnimationFrame(e)}))):(clearTimeout(t),t=setTimeout((()=>t=null),100)))}),{capture:!0}))}this._eventBindings=o}_rePositioningPicker(){const{options:t}=this;if(!t.inline){if(!this._nanopop.update({container:document.body.getBoundingClientRect(),position:t.position})){const t=this._root.app,e=t.getBoundingClientRect();t.style.top=(window.innerHeight-e.height)/2+"px",t.style.left=(window.innerWidth-e.width)/2+"px"}}}_updateOutput(t){const{_root:e,_color:o,options:n}=this;if(e.interaction.type()){const t=`to${e.interaction.type().getAttribute("data-type")}`;e.interaction.result.value="function"==typeof o[t]?o[t]().toString(n.outputPrecision):""}!this._initializingActive&&this._recalc&&this._emit("change",o,t,this)}_clearColor(t=!1){const{_root:e,options:o}=this;o.useAsButton||e.button.style.setProperty("--pcr-color","rgba(0, 0, 0, 0.15)"),e.button.classList.add("clear"),o.showAlways||this.hide(),this._lastColor=null,this._initializingActive||t||(this._emit("save",null),this._emit("clear"))}_parseLocalColor(t){const{values:e,type:o,a:n}=w(t),{lockOpacity:i}=this.options,s=void 0!==n&&1!==n;return e&&3===e.length&&(e[3]=void 0),{values:!e||i&&s?null:e,type:o}}_t(t){return this.options.i18n[t]||L.I18N_DEFAULTS[t]}_emit(t,...e){this._eventListener[t].forEach((t=>t(...e,this)))}on(t,e){return this._eventListener[t].push(e),this}off(t,e){const o=this._eventListener[t]||[],n=o.indexOf(e);return~n&&o.splice(n,1),this}addSwatch(t){const{values:e}=this._parseLocalColor(t);if(e){const{_swatchColors:t,_root:o}=this,n=A(...e),s=r(`<button type="button" style="--pcr-color: ${n.toRGBA().toString(0)}" aria-label="${this._t("btn:swatch")}"/>`);return o.swatches.appendChild(s),t.push({el:s,color:n}),this._eventBindings.push(i(s,"click",(()=>{this.setHSVA(...n.toHSVA(),!0),this._emit("swatchselect",n),this._emit("change",n,"swatch",this)}))),!0}return!1}removeSwatch(t){const e=this._swatchColors[t];if(e){const{el:o}=e;return this._root.swatches.removeChild(o),this._swatchColors.splice(t,1),!0}return!1}applyColor(t=!1){const{preview:e,button:o}=this._root,n=this._color.toRGBA().toString(0);return e.lastColor.style.setProperty("--pcr-color",n),this.options.useAsButton||o.style.setProperty("--pcr-color",n),o.classList.remove("clear"),this._lastColor=this._color.clone(),this._initializingActive||t||this._emit("save",this._color),this}destroy(){cancelAnimationFrame(this._setupAnimationFrame),this._eventBindings.forEach((t=>s(...t))),Object.keys(this._components).forEach((t=>this._components[t].destroy()))}destroyAndRemove(){this.destroy();const{root:t,app:e}=this._root;t.parentElement&&t.parentElement.removeChild(t),e.parentElement.removeChild(e),Object.keys(this).forEach((t=>this[t]=null))}hide(){return!!this.isOpen()&&(this._root.app.classList.remove("visible"),this._emit("hide"),!0)}show(){return!this.options.disabled&&!this.isOpen()&&(this._root.app.classList.add("visible"),this._rePositioningPicker(),this._emit("show",this._color),this)}isOpen(){return this._root.app.classList.contains("visible")}setHSVA(t=360,e=0,o=0,n=1,i=!1){const s=this._recalc;if(this._recalc=!1,t<0||t>360||e<0||e>100||o<0||o>100||n<0||n>1)return!1;this._color=A(t,e,o,n);const{hue:r,opacity:a,palette:l}=this._components;return r.update(t/360),a.update(n),l.update(e/100,1-o/100),i||this.applyColor(),s&&this._updateOutput(),this._recalc=s,!0}setColor(t,e=!1){if(null===t)return this._clearColor(e),!0;const{values:o,type:n}=this._parseLocalColor(t);if(o){const t=n.toUpperCase(),{options:i}=this._root.interaction,s=i.find((e=>e.getAttribute("data-type")===t));if(s&&!s.hidden)for(const t of i)t.classList[t===s?"add":"remove"]("active");return!!this.setHSVA(...o,e)&&this.setColorRepresentation(t)}return!1}setColorRepresentation(t){return t=t.toUpperCase(),!!this._root.interaction.options.find((e=>e.getAttribute("data-type").startsWith(t)&&!e.click()))}getColorRepresentation(){return this._representation}getColor(){return this._color}getSelectedColor(){return this._lastColor}getRoot(){return this._root}disable(){return this.hide(),this.options.disabled=!0,this._root.button.classList.add("disabled"),this}enable(){return this.options.disabled=!1,this._root.button.classList.remove("disabled"),this}}return E(L,"utils",o),E(L,"version","1.8.2"),E(L,"I18N_DEFAULTS",{"ui:dialog":"color picker dialog","btn:toggle":"toggle color picker dialog","btn:swatch":"color swatch","btn:last-color":"use previous color","btn:save":"Save","btn:cancel":"Cancel","btn:clear":"Clear","aria:btn:save":"save and close","aria:btn:cancel":"cancel and close","aria:btn:clear":"clear and close","aria:input":"color input field","aria:palette":"color selection area","aria:hue":"hue selection slider","aria:opacity":"selection slider"}),E(L,"DEFAULT_OPTIONS",{appClass:null,theme:"classic",useAsButton:!1,padding:8,disabled:!1,comparison:!0,closeOnScroll:!1,outputPrecision:0,lockOpacity:!1,autoReposition:!0,container:"body",components:{interaction:{}},i18n:{},swatches:null,inline:!1,sliders:null,default:"#42445a",defaultRepresentation:null,position:"bottom-middle",adjustableNumbers:!0,showAlways:!1,closeWithKey:"Escape"}),E(L,"create",(t=>new L(t))),e=e.default})()}));
