function getMaskList(){let list=[];for(let i=0;i<33;i++){let imask;if(i==32)imask=0xffffffff;else imask=~(0xffffffff>>>i);list.push(`${(imask >>> 24) & 0xff}.${(imask >>> 16) & 0xff}.${(imask >>> 8) & 0xff}.${imask & 0xff}`);}
return list;}
String.prototype.hashCode=function(){if(!this.length)return 0;let hash=new Uint32Array(1);for(let i=0;i<this.length;i++){hash[0]=((hash[0]<<5)-hash[0])+this.charCodeAt(i);}
return hash[0];}
class GyverHub{cfg={prefix:'MyDevices',client_id:new Date().getTime().toString(16).slice(-8),use_ws:false,use_hook:true,local_ip:'192.168.1.1',netmask:24,use_bt:false,use_serial:false,ser_baud:115200,use_mqtt:false,mq_host:'test.mosquitto.org',mq_port:'8081',mq_login:'',mq_pass:'',};bt=new Bluetooth();ser=new Serial();}
class Serial{onmessage(data){}
onopen(){}
onclose(){}
onerror(e){}
onchange(){}
state(){return this.lock;}
port=null;lock=false;reader=null;async select(){await this.close();const ports=await navigator.serial.getPorts();for(let port of ports)await port.forget();try{await navigator.serial.requestPort();this.onchange(true);}catch(e){this.onerror('[Serial] '+e);this.onchange(false);}}
async start(baud){if(this.lock)return this.onerror("[Serial] Already open");try{this.lock=true;const ports=await navigator.serial.getPorts();if(!ports.length)return this.onerror("[Serial] No port");this.port=ports[0];await this.port.open({baudRate:baud});this.onopen();while(this.port.readable){this.reader=this.port.readable.getReader();try{while(true&&this.lock){const{value,done}=await this.reader.read();if(done)break;const data=new TextDecoder().decode(value);this.onmessage(data);}}catch(e){this.onerror('[Serial] '+e);}finally{await this.reader.releaseLock();await this.port.close();this.onclose();break;}}}catch(e){this.onerror('[Serial] '+e);}
this.reader=null;this.lock=false;}
async close(){if(this.reader)this.reader.cancel();this.lock=false;}
async send(text){if(!this.lock)return this.onerror("[Serial] Not open");try{const encoder=new TextEncoder();const writer=this.port.writable.getWriter();await writer.write(encoder.encode(text+'\0'));writer.releaseLock();}catch(e){this.onerror('[Serial] '+e);}}}
class Bluetooth{constructor(){this._maxCharacteristicValueLength=20;this._device=null;this._characteristic=null;this._serviceUuid=0xFFE0;this._characteristicUuid=0xFFE1;this._boundHandleDisconnection=this._handleDisconnection.bind(this);this._boundHandleCharacteristicValueChanged=this._handleCharacteristicValueChanged.bind(this);}
onmessage(data){}
onopen(){}
onclose(){}
onerror(e){}
state(){return(this._device);}
open(){return this._connectToDevice(this._device).then(()=>this.onopen()).catch(e=>this._onerror(e));}
close(){this._disconnectFromDevice(this._device);if(this._characteristic){this._characteristic.removeEventListener('characteristicvaluechanged',this._boundHandleCharacteristicValueChanged);this._characteristic=null;}
if(this._device)this.onclose();this._device=null;}
send(data){if(!this._characteristic)return this._onerror('No device');data+='\0';const chunks=this.constructor._splitByLength(data,this._maxCharacteristicValueLength);let promise=this._writeToCharacteristic(this._characteristic,chunks[0]);for(let i=1;i<chunks.length;i++){promise=promise.then(()=>new Promise((resolve,reject)=>{if(!this._characteristic){this._onerror('Device has been disconnected');reject();}
this._writeToCharacteristic(this._characteristic,chunks[i]).then(resolve).catch(reject);}));}
return promise;}
getName(){return this._device?this._device.name:'';}
_onerror(e){this.onerror('[BT] '+e);}
_connectToDevice(device){return(device?Promise.resolve(device):this._requestBluetoothDevice()).then((device)=>this._connectDeviceAndCacheCharacteristic(device)).then((characteristic)=>this._startNotifications(characteristic)).catch((error)=>{this._onerror(error);return Promise.reject(error);});}
_disconnectFromDevice(device){if(!device)return;device.removeEventListener('gattserverdisconnected',this._boundHandleDisconnection);if(!device.gatt.connected)return;device.gatt.disconnect();}
_requestBluetoothDevice(){return navigator.bluetooth.requestDevice({filters:[{services:[this._serviceUuid]}],}).then((device)=>{this._device=device;this._device.addEventListener('gattserverdisconnected',this._boundHandleDisconnection);return this._device;});}
_connectDeviceAndCacheCharacteristic(device){if(device.gatt.connected&&this._characteristic){return Promise.resolve(this._characteristic);}
return device.gatt.connect().then((server)=>{return server.getPrimaryService(this._serviceUuid);}).then((service)=>{return service.getCharacteristic(this._characteristicUuid);}).then((characteristic)=>{this._characteristic=characteristic;return this._characteristic;});}
_startNotifications(characteristic){return characteristic.startNotifications().then(()=>{characteristic.addEventListener('characteristicvaluechanged',this._boundHandleCharacteristicValueChanged);});}
_stopNotifications(characteristic){return characteristic.stopNotifications().then(()=>{characteristic.removeEventListener('characteristicvaluechanged',this._boundHandleCharacteristicValueChanged);});}
_handleDisconnection(event){const device=event.target;this.onclose();this._connectDeviceAndCacheCharacteristic(device).then((characteristic)=>this._startNotifications(characteristic)).then(()=>{this.onopen();}).catch((e)=>this._onerror(e));}
_handleCharacteristicValueChanged(event){const value=new TextDecoder().decode(event.target.value);this.onmessage(value);}
_writeToCharacteristic(characteristic,data){return characteristic.writeValue(new TextEncoder().encode(data));}
static _splitByLength(string,length){return string.match(new RegExp('(.|[\r\n]){1,'+length+'}','g'));}}
let hub=new GyverHub();function render_main(v){head_cont.innerHTML=`
<div class="title" id="title_cont">
<div class="title_inn">
<div id="title_row" class="title_row" onclick="back_h()">
<span class="icon i_hover back_btn" id="back"></span>
<span><span id="title"></span><sup id="conn"></sup><span class='version' id='version'>${v}</span></span>
</div>
<div id="conn_icons" style="display:flex">
<span id='mqtt_ok' style="display:none;margin:0" class="icon cfg_icon"></span>
<span id='serial_ok' style="display:none;margin:0" class="icon cfg_icon"></span>
<span id='bt_ok' style="display:none;margin:0" class="icon cfg_icon"></span>
</div>
<div class="head_btns">
<span class="icon i_hover" id='icon_refresh' onclick="refresh_h()"></span>
<span class="icon i_hover" id='icon_cfg' style="display:none" onclick="config_h()"></span>
<span class="icon i_hover" id='icon_menu' style="display:none" onclick="menu_h()"></span>
</div>
</div>
</div>
`;cli_cont.innerHTML=`
<div class="cli_block">
<div class="cli_area" id="cli"></div>
<div class="cli_row">
<span class="icon cli_icon"></span>
<input type="text" class="cfg_inp cli_inp" id="cli_input" onkeydown="checkCLI()">
<button class="icon cfg_btn cli_icon cli_enter" onclick="sendCLI()"></button>
</div>
</div>
`;main_cont.innerHTML=`
<div id="menu_overlay" onclick="menu_show(0)"></div>
<div id="menu" class="main_col menu">
<div class="menu_inn">
<div id="menu_user"></div>
<div>
<div id="menu_info" class="menu_item" onclick="info_h()">Info</div>
<div id="menu_fsbr" class="menu_item" onclick="fsbr_h()">File & OTA</div>
</div>
</div>
</div>
<div class="main_inn">
<div id="devices" class="main_col"></div>
<div id="controls" class="main_col" style="max-width:unset"></div>
<div id="info" class="main_col">
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Settings</label>
</div>
<div class="cfg_row">
<label>Console</label>
<label class="switch"><input type="checkbox" id="info_cli_sw" onchange="showCLI(this.checked);save_devices()">
<span class="slider"></span></label>
</div>
<div class="cfg_row">
<label>Break Widgets</label>
<label class="switch"><input type="checkbox" id="info_break_sw" onchange="devices[focused].break_widgets=this.checked;save_devices()">
<span class="slider"></span></label>
</div>
<div class="cfg_row">
<label>Show names</label>
<label class="switch"><input type="checkbox" id="info_names_sw" onchange="devices[focused].show_names=this.checked;save_devices()">
<span class="slider"></span></label>
</div>
<div class="cfg_row">
<button id="reboot_btn" class="c_btn btn_mini" onclick="reboot_h()"><span class="icon info_icon"></span>Reboot</button>
</div>
</div>
<div class="cfg_col" id="info_topics">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Topics</label>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Version</label>
</div>
<div id="info_version"></div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Network</label>
</div>
<div id="info_net"></div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Memory</label>
</div>
<div id="info_memory"></div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>System</label>
</div>
<div id="info_system"></div>
</div>
</div>
<div id="fsbr_edit" class="main_col">
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Editor</label>
</div>
<div class="cfg_row">
<label id="edit_path"></label>
</div>
<div class="cfg_row">
<label>Wrap text</label>
<label class="switch"><input type="checkbox" id="editor_wrap" onchange="this.checked?editor_area.classList.remove('c_area_wrap'):editor_area.classList.add('c_area_wrap')"><span class="slider"></span></label>
</div>
<div class="cfg_row">
<textarea rows=20 id="editor_area" class="cfg_inp c_log c_area_wrap"></textarea>
</div>
<div class="cfg_row">
<button id="editor_save" onclick="editor_save()" class="c_btn btn_mini">Save & Upload</button>
<button onclick="editor_cancel()" class="c_btn btn_mini">Cancel</button>
</div>
</div>
</div>
<div id="fsbr" class="main_col">
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>FS Browser</label>
</div>
<div id="fs_browser">
<div id="fsbr_inner"></div>
<div class="cfg_row">
<div>
<button id="fs_format" onclick="format_h()" class="c_btn btn_mini">Format</button>
<button id="fs_update" onclick="updatefs_h()" class="c_btn btn_mini">Refresh</button>
</div>
</div>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>Upload to</label>
</div>
<div id="fs_upload">
<div class="upload_row">
<input class="cfg_inp inp_wbtn" type="text" id="file_upload_path" value="/">
<input type="file" id="file_upload" style="display:none" onchange="uploadFile(this.files[0], file_upload_path.value)">
<button id="file_upload_btn" onclick="file_upload.click()" class="c_btn upl_button">Upload</button>
</div>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>OTA FILE</label>
</div>
<div id="fs_otaf">
<div class="cfg_row">
<div>
<input type="file" id="ota_upload" style="display:none" onchange="uploadOta(this.files[0], 'flash')">
<button onclick="ota_upload.click()" class="c_btn btn_mini drop_area" ondrop="uploadOta(event.dataTransfer.files[0], 'flash')">Flash</button>
<input type="file" id="ota_upload_fs" style="display:none" onchange="uploadOta(this.files[0], 'fs')">
<button onclick="ota_upload_fs.click()" class="c_btn btn_mini drop_area" ondrop="uploadOta(event.dataTransfer.files[0], 'fs')">Filesystem</button>
</div>
<label style="font-size:18px" id="ota_label">IDLE</label>
</div>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label><span class="icon cfg_icon"></span>OTA URL</label>
</div>
<div id="fs_otaurl">
<div class="upload_row">
<input class="cfg_inp inp_wbtn" type="text" id="ota_url_f">
<button id="ota_url_btn" onclick="otaUrl(ota_url_f.value,'flash')" class="c_btn upl_button">Flash</button>
</div>
<div class="upload_row">
<input class="cfg_inp inp_wbtn" type="text" id="ota_url_fs">
<button id="ota_url_btn" onclick="otaUrl(ota_url_fs.value,'fs')" class="c_btn upl_button">FS</button>
</div>
</div>
</div>
</div>
<div id="config" class="cfg_in">
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label class="cfg_label"><span class="icon cfg_icon"></span>Search</label>
<div>
<button class="icon cfg_btn_tab" onclick="discover_all()" title="Find new devices"></button>
</div>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head cfg_clickable" onclick="use_ws.click()">
<label class="cfg_label cfg_clickable" id="ws_label"><span class="icon cfg_icon"></span>WS</label>
<input type="checkbox" id="use_ws" onchange="update_cfg(this)" style="display:none">
</div>
<div id="ws_block" style="display:none">
<div class="cfg_row" id="http_only_http" style="display:none">
<span style="color:#c60000">Works only on <strong class="span_btn" onclick="window.location.href = window.location.href.replace('https', 'http')">HTTP</strong>!</span>
</div>
<div id="http_settings">
<div class="cfg_row">
<label class="cfg_label">My IP</label>
<div class="cfg_inp_row cfg_inp_row_fix">
<input class="cfg_inp" type="text" id="local_ip" onchange="update_cfg(this)">
<div class="cfg_btn_block">
<button class="icon cfg_btn" onclick="update_ip_h();update_cfg(EL('local_ip'))"></button>
</div>
</div>
</div>
<div class="cfg_row">
<label>Netmask</label>
<select class="cfg_inp c_inp_block с_inp_fix" id="netmask" onchange="update_cfg(this)"></select>
</div>
<div class="cfg_row">
<label class="cfg_label">Add by IP</label>
<div class="cfg_inp_row cfg_inp_row_fix">
<input class="cfg_inp" type="text" value="192.168.1.1" id="ws_manual_ip">
<div class="cfg_btn_block">
<button class="icon cfg_btn" onclick="manual_ws_h(ws_manual_ip.value)"></button>
</div>
</div>
</div>
<div class="cfg_row">
<label>HTTP hook</label>
<label class="switch"><input type="checkbox" id="use_hook" onchange="update_cfg(this)"><span class="slider"></span></label>
</div>
<!--APP-->
<span class="notice_block">Disable: <u>${browser()}://flags/#block-insecure-private-network-requests</u></span>
<!--/APP-->
</div>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head">
<label class="cfg_label"><span class="icon cfg_icon"></span>Settings</label>
</div>
<div class="cfg_row">
<label class="cfg_label">Prefix</label>
<div class="cfg_inp_row cfg_inp_row_fix">
<input class="cfg_inp" type="text" id="prefix" onchange="update_cfg(this)">
</div>
</div>
<div class="cfg_row">
<label class="cfg_label">Client ID</label>
<div class="cfg_inp_row cfg_inp_row_fix"><input class="cfg_inp" type="text" id="client_id" onchange="update_cfg(this)" oninput="if(this.value.length>8)this.value=this.value.slice(0,-1)">
</div>
</div>
<div class="cfg_row">
<label class="cfg_label">Theme</label>
<select class="cfg_inp c_inp_block с_inp_fix" id='theme' onchange="update_cfg(this)"></select>
</div>
<div class="cfg_row">
<label class="cfg_label">Main Color</label>
<select class="cfg_inp c_inp_block с_inp_fix" id='maincolor' onchange="update_cfg(this)"></select>
</div>
<div class="cfg_row">
<label class="cfg_label">Font</label>
<select class="cfg_inp c_inp_block с_inp_fix" id='font' onchange="update_cfg(this)"></select>
</div>
<div class="cfg_row">
<label class="cfg_label">UI Width</label>
<div class="cfg_inp_row cfg_inp_row_fix">
<input class="cfg_inp" type="number" id="ui_width" onchange="update_cfg(this);update_theme()">
</div>
</div>
<div class="cfg_row">
<label>Check updates</label>
<label class="switch"><input type="checkbox" id="check_upd" onchange="update_cfg(this)"><span class="slider"></span></label>
</div>
<div class="cfg_row">
<label class="cfg_label">Settings</label>
<div class="cfg_btn_row">
<button class="c_btn btn_mini" onclick="cfg_export()">Export</button>
<button class="c_btn btn_mini" onclick="cfg_import()">Import</button>
</div>
</div>
</div>
<div class="cfg_col">
<div class="cfg_row cfg_head cfg_clickable" onclick="use_pin.click()">
<label id="pin_label" class="cfg_label cfg_clickable"><span class="icon cfg_icon"></span>PIN</label>
<input type="checkbox" id="use_pin" onchange="update_cfg(this)" style="display:none">
</div>
<div id="pin_block" style="display:none">
<div class="cfg_row">
<label class="cfg_label">PIN</label>
<div class="cfg_inp_row cfg_inp_row_fix"><input class="cfg_inp" type="password" pattern="[0-9]*" inputmode="numeric"
id="pin" onchange="this.value=this.value.hashCode();update_cfg(this)" oninput="check_type(this)">
</div>
</div>
</div>
</div>
<div class="cfg_col" id="app_block">
<div class="cfg_row cfg_head">
<label class="cfg_label"><span class="icon cfg_icon"></span>App</label>
<div class="cfg_btn_row">
<button class="c_btn btn_mini" onclick="openURL('https://play.google.com/store/apps/details?id=ru.alexgyver.GyverHub')">Android</button>
<button class="c_btn btn_mini" onclick="openURL('https://github.com/GyverLibs/GyverHub/raw/main/app/GyverHub.apk')">.apk</button>
</div>
</div>
</div>
<div class="cfg_col">
<div class="cfg_info">
Contribution:
<a href="https://github.com/Simonwep/pickr" target="_blank">Pickr</a>
<a href="https://github.com/mqttjs/MQTT.js" target="_blank">MQTT.js</a>
<a href="https://github.com/ghornich/sort-paths" target="_blank">sort-paths</a>
<a href="https://fontawesome.com/v5/search?o=r&m=free&s=solid" target="_blank">Fontawesome</a>
</div>
</div>
</div>
<div id="password" class="main_col">
<div class="pass_inp_inner">
<input class="cfg_inp pass_inp" type="number" pattern="[0-9]*" inputmode="numeric" id="pass_inp" oninput="pass_type('')">
</div>
<div class="cfg_row pass_inner">
<button class="c_btn pass_btn" onclick="pass_type(1)">1</button>
<button class="c_btn pass_btn" onclick="pass_type(2)">2</button>
<button class="c_btn pass_btn" onclick="pass_type(3)">3</button>
</div>
<div class="cfg_row pass_inner">
<button class="c_btn pass_btn" onclick="pass_type(4)">4</button>
<button class="c_btn pass_btn" onclick="pass_type(5)">5</button>
<button class="c_btn pass_btn" onclick="pass_type(6)">6</button>
</div>
<div class="cfg_row pass_inner">
<button class="c_btn pass_btn" onclick="pass_type(7)">7</button>
<button class="c_btn pass_btn" onclick="pass_type(8)">8</button>
<button class="c_btn pass_btn" onclick="pass_type(9)">9</button>
</div>
<div class="cfg_row pass_inner">
<button class="c_btn pass_btn empty_b"></button>
<button class="c_btn pass_btn" onclick="pass_type(0)">0</button>
<button class="c_btn pass_btn red_btn" onclick="pass_inp.value=pass_inp.value.slice(0, -1)">&lt;</button>
</div>
</div>
</div>
<div id="bottom_space"></div>
`;}
const app_title='GyverHub';const non_esp='';const non_app='__APP__';const app_version='0.50b';const log_enable=true;const log_network=false;const colors={ORANGE:0xd55f30,YELLOW:0xd69d27,GREEN:0x37A93C,MINT:0x25b18f,AQUA:0x2ba1cd,BLUE:0x297bcd,VIOLET:0x825ae7,PINK:0xc8589a,};const fonts=['monospace','system-ui','cursive','Arial','Verdana','Tahoma','Trebuchet MS','Georgia','Garamond',];const themes={DARK:0,LIGHT:1};const baudrates=[4800,9600,19200,38400,57600,74880,115200,230400,250000,500000,1000000,2000000];const theme_cols=[['#1b1c20','#26272c','#eee','#ccc','#141516','#444','#0e0e0e','dark','#222','#000'],['#eee','#fff','#111','#333','#ddd','#999','#bdbdbd','light','#fff','#000000a3']];function isSSL(){return window.location.protocol=='https:';}
function isLocal(){return window.location.href.startsWith('file')||checkIP(window_ip())||window_ip()=='localhost';}
function isApp(){return!non_app;}
function isPWA(){return(window.matchMedia('(display-mode: standalone)').matches)||(window.navigator.standalone)||document.referrer.includes('android-app://');}
function isESP(){return!non_esp;}
function isTouch(){return navigator.maxTouchPoints||'ontouchstart'in document.documentElement;}
function getMime(name){const mime_table={'avi':'video/x-msvideo','bin':'application/octet-stream','bmp':'image/bmp','css':'text/css','csv':'text/csv','gz':'application/gzip','gif':'image/gif','html':'text/html','jpeg':'image/jpeg','jpg':'image/jpeg','js':'text/javascript','json':'application/json','png':'image/png','svg':'image/svg+xml','txt':'text/plain','wav':'audio/wav','xml':'application/xml',};let ext=name.split('.').pop();if(ext in mime_table)return mime_table[ext];else return'text/plain';}
function EL(id){return document.getElementById(id);}
function log(text){let texts=text.toString();if(!log_network&&(texts.includes('discover')||texts.startsWith('Post')||texts.startsWith('Got')))return;console.log(text);}
function openURL(url){window.open(url,'_blank').focus();}
function intToCol(val){return"#"+Number(val).toString(16).padStart(6,'0');}
function intToColA(val){return"#"+Number(val).toString(16).padStart(8,'0');}
function colToInt(str){return parseInt(str.substr(1),16);}
function random(min,max){return Math.floor(Math.random()*(max-min+1)+min)}
function randomChar(){let code;switch(random(0,2)){case 0:code=random(48,57);break;case 1:code=random(65,90);break;case 2:code=random(97,122);break;}
return String.fromCharCode(code);}
function notSupported(){alert('Browser not supported');}
function browser(){if(navigator.userAgent.includes("Opera")||navigator.userAgent.includes('OPR'))return'opera';else if(navigator.userAgent.includes("Edg"))return'edge';else if(navigator.userAgent.includes("Chrome"))return'chrome';else if(navigator.userAgent.includes("Safari"))return'safari';else if(navigator.userAgent.includes("Firefox"))return'firefox';else if((navigator.userAgent.includes("MSIE"))||(!!document.documentMode==true))return'IE';else return'unknown';}
function disableScroll(){TopScroll=window.pageYOffset||document.documentElement.scrollTop;LeftScroll=window.pageXOffset||document.documentElement.scrollLeft,window.onscroll=function(){window.scrollTo(LeftScroll,TopScroll);};}
function enableScroll(){window.onscroll=function(){};}
function refreshSpin(val){if(val)EL('icon_refresh').classList.add('spinning');else EL('icon_refresh').classList.remove('spinning');}
function ratio(){return window.devicePixelRatio;}
function resize_h(){showGauges();}
function waitAnimationFrame(){return new Promise(res=>{requestAnimationFrame(()=>res());});}
function sleep(ms){return new Promise(resolve=>setTimeout(resolve,ms));}
let popupT1=null,popupT2=null;function showPopup(text,color='#37a93c'){if(popupT1)clearTimeout(popupT1);if(popupT2)clearTimeout(popupT2);EL('notice').innerHTML=text;EL('notice').style.background=color;EL('notice').style.display='block';EL('notice').style.animation="fade-in 0.5s forwards";popupT1=setTimeout(()=>{popupT1=null;EL('notice').style.display='none'},3500);popupT2=setTimeout(()=>{popupT2=null;EL('notice').style.animation="fade-out 0.5s forwards"},3000);}
function showPopupError(text){showPopup(text,'#a93737');}
function showErr(v){EL('head_cont').style.background=v?'var(--err)':'var(--prim)';}
function update_ip_h(){if(isESP())EL('local_ip').value=window_ip();}
function checkIP(ip){return Boolean(ip.match(/^((25[0-5]|(2[0-4]|1[0-9]|[1-9]|)[0-9])(\.(?!$)|$)){4}$/));}
function window_ip(){let ip=window.location.href.split('/')[2].split(':')[0];return checkIP(ip)?ip:'error';}
function getIPs(){let ip=EL('local_ip').value;if(!checkIP(ip)){showPopupError('Wrong IP!');return null;}
let ip_a=ip.split('.');let sum_ip=(ip_a[0]<<24)|(ip_a[1]<<16)|(ip_a[2]<<8)|ip_a[3];let cidr=Number(hub.cfg.netmask);let mask=~(0xffffffff>>>cidr);let network=0,broadcast=0,start_ip=0,end_ip=0;if(cidr===32){network=sum_ip;broadcast=network;start_ip=network;end_ip=network;}else{network=sum_ip&mask;broadcast=network+(~mask);if(cidr===31){start_ip=network;end_ip=broadcast;}else{start_ip=network+1;end_ip=broadcast-1;}}
let ips=['192.168.4.1'];for(let ip=start_ip;ip<=end_ip;ip++){ips.push(`${(ip >>> 24) & 0xff}.${(ip >>> 16) & 0xff}.${(ip >>> 8) & 0xff}.${ip & 0xff}`);}
return ips;}
let devices={};let devices_t={};let controls={};let focused=null;let touch=0;let pressId=null;let dup_names=[];let gauges={};let canvases={};let pickers={};let joys={};let prompts={};let confirms={};let oninp_buffer={};let files=[];let wid_row_id=null;let wid_row_count=0;let wid_row_size=0;let btn_row_id=null;let btn_row_count=0;let dis_scroll_f=false;function waiter(size=50,col='var(--prim)',block=true){return`<div class="waiter ${block ? 'waiter_b' : ''}"><span style="font-size:${size}px;color:${col}" class="icon spinning"></span></div>`;}
const Modules={INFO:(1<<0),FSBR:(1<<1),FORMAT:(1<<2),DOWNLOAD:(1<<3),UPLOAD:(1<<4),OTA:(1<<5),OTA_URL:(1<<6),REBOOT:(1<<7),SET:(1<<8),READ:(1<<9),DELETE:(1<<10),RENAME:(1<<11)};function save_devices(){localStorage.setItem('devices',JSON.stringify(devices));}
function load_devices(){if(localStorage.hasOwnProperty('devices')){devices=JSON.parse(localStorage.getItem('devices'));}}
function readModule(module){return!(devices[focused].modules&module);}
function addDevice(id){let icon=(!isESP()&&devices[id].icon.length)?`<span class="icon icon_min" id="icon#${id}">${devices[id].icon}</span>`:'';EL('devices').innerHTML+=`<div class="device offline" id="device#${id}" onclick="device_h('${id}')" title="${id} [${devices[id].prefix}]">
<div class="device_inner">
<div class="d_icon ${icon ? '' : 'd_icon_empty'}">${icon}</div>
<div class="d_head">
<span><span class="d_name" id="name#${id}">${devices[id].name}</span><sup class="conn_dev" id="Serial#${id}">S</sup><sup class="conn_dev" id="BT#${id}">B</sup><sup class="conn_dev" id="WS#${id}">W</sup><sup class="conn_dev" id="MQTT#${id}">M</sup></span>
</div>
<div class="icon d_delete" onclick="delete_h('${id}')"></div>
</div>
</div>`;}
function addButton(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);if(wid_row_id){let label=ctrl.wlabel,icon='';if(ctrl.wlabel.charCodeAt(0)>=0xF005){icon=label[0];if(isESP())icon="";label=label.slice(1).trim();}
endButtons();let inner=renderButton(ctrl.name,'icon btn_icon',ctrl.name,icon,ctrl.size*3,ctrl.color,true);addWidget(ctrl.tab_w,ctrl.name,label,inner);}else{if(!btn_row_id)beginButtons();let label=ctrl.clabel,icon='';if(ctrl.clabel.charCodeAt(0)>=0xF005){icon=label[0];label=label.slice(1).trim();label=`<span class="icon icon_min">${icon}</span>&nbsp;`+label;}
EL(btn_row_id).innerHTML+=`${renderButton(ctrl.name, 'c_btn', ctrl.name, label, ctrl.size, ctrl.color, false)}`;}}
function addButtonIcon(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);if(isESP())ctrl.label="";if(wid_row_id){endButtons();let inner=renderButton(ctrl.name,'icon btn_icon',ctrl.name,ctrl.label,ctrl.size,ctrl.color,true);addWidget(ctrl.tab_w,ctrl.name,'',inner,0,true);}else{if(!btn_row_id)beginButtons();EL(btn_row_id).innerHTML+=`${renderButton(ctrl.name, 'icon btn_icon', ctrl.name, ctrl.label, ctrl.size, ctrl.color, true)}`;}}
function beginButtons(){btn_row_id='buttons_row#'+btn_row_count;btn_row_count++;EL('controls').innerHTML+=`
<div id="${btn_row_id}" class="control control_nob control_scroll"></div>
`;}
function endButtons(){if(btn_row_id&&EL(btn_row_id).getElementsByTagName('*').length==1){EL(btn_row_id).innerHTML="<div></div>"+EL(btn_row_id).innerHTML+"<div></div>";}
btn_row_id=null;}
function renderButton(title,className,name,label,size,color=null,is_icon=false){let col=(color!=null)?((is_icon?';color:':';background:')+intToCol(color)):'';return`<button id="#${name}" title='${title}' style="font-size:${size}px${col}" class="${className}" onclick="set_h('${name}',2)" onmousedown="if(!touch)click_h('${name}',1)" onmouseup="if(!touch&&pressId)click_h('${name}',0)" onmouseleave="if(pressId&&!touch)click_h('${name}',0);" ontouchstart="touch=1;click_h('${name}',1)" ontouchend="click_h('${name}',0)">${label}</button>`;}
function addTabs(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let tabs='';let labels=ctrl.text.toString().split(',');for(let i in labels){let sel=(i==ctrl.value)?'class="tab_act"':'';tabs+=`<li onclick="set_h('${ctrl.name}','${i}')" ${sel}>${labels[i]}</li>`;}
if(wid_row_id){let inner=`
<div class="navtab_tab">
<ul>
${tabs}
</ul>
</div>
`;addWidget(ctrl.tab_w,'',ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="navtab">
<ul>
${tabs}
</ul>
</div>
`;}}
function addMenu(ctrl){let inner='';let labels=ctrl.text.toString().split(',');for(let i in labels){let sel=(i==ctrl.value)?'menu_act':'';inner+=`<div onclick="menuClick(${i})" class="menu_item ${sel}">${labels[i]}</div>`;}
document.querySelector(':root').style.setProperty('--menu_h',((labels.length+2)*35+10)+'px');EL('menu_user').innerHTML=inner;}
function menuClick(num){menu_show(0);menuDeact();if(screen!='device')show_screen('device');set_h('_menu',num);}
function menuDeact(){let els=document.getElementById('menu_user').children;for(let el in els){if(els[el].tagName=='DIV')els[el].classList.remove('menu_act');}
EL('menu_info').classList.remove('menu_act');EL('menu_fsbr').classList.remove('menu_act');}
function addInput(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let col=(ctrl.color!=null)?('box-shadow: 0px 2px 0px 0px '+intToCol(ctrl.color)):'';if(wid_row_id){let inner=`
<div class="cfg_inp_row cfg_inp_row_tab">
<input class="cfg_inp c_inp input_t" style="${col}" type="text" value="${ctrl.value}" id="#${ctrl.name}" name="${ctrl.name}" onkeydown="checkEnter(this)" oninput="checkLen(this,${ctrl.max})" pattern="${ctrl.regex}">
<div class="cfg_btn_block">
<button class="icon cfg_btn" onclick="sendInput('${ctrl.name}')"></button>
</div>
</div>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<div class="cfg_inp_row">
<input class="cfg_inp c_inp input_t" style="${col}" type="text" value="${ctrl.value}" id="#${ctrl.name}" name="${ctrl.name}" onkeydown="checkEnter(this)" oninput="checkLen(this,${ctrl.max})" pattern="${ctrl.regex}">
<div class="cfg_btn_block">
<button class="icon cfg_btn" onclick="sendInput('${ctrl.name}')"></button>
</div>
</div>
</div>
`;}}
function sendInput(name){let inp=EL('#'+name);const r=new RegExp(inp.pattern);if(r.test(inp.value))set_h(name,inp.value);else showPopupError("Wrong text!");}
function checkLen(arg,len){if(len&&arg.value.length>len)arg.value=arg.value.substring(0,len);}
function checkEnter(arg){if(event.key=='Enter'){if(arg.pattern)sendInput(arg.name);else set_h(arg.name,arg.value);}}
function addPass(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let col=(ctrl.color!=null)?('box-shadow: 0px 2px 0px 0px '+intToCol(ctrl.color)):'';if(wid_row_id){let inner=`
<div class="cfg_inp_row cfg_inp_row_tab">
<input class="cfg_inp c_inp input_t" style="${col}" type="password" value="${ctrl.value}" id="#${ctrl.name}" name="${ctrl.name}" onkeydown="checkEnter(this)" oninput="checkLen(this,${ctrl.max})">
<div class="cfg_btn_block2">
<button class="icon cfg_btn" onclick="togglePass('#${ctrl.name}')"></button>
<button class="icon cfg_btn" onclick="set_h('${ctrl.name}',EL('#${ctrl.name}').value)"></button>
</div>
</div>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<div class="cfg_inp_row">
<input class="cfg_inp c_inp input_t" style="${col}" type="password" value="${ctrl.value}" id="#${ctrl.name}" name="${ctrl.name}" onkeydown="checkEnter(this)" oninput="checkLen(this,${ctrl.max})">
<div class="cfg_btn_block2">
<button class="icon cfg_btn" onclick="togglePass('#${ctrl.name}')"></button>
<button class="icon cfg_btn" onclick="set_h('${ctrl.name}',EL('#${ctrl.name}').value)"></button>
</div>
</div>
</div>
`;}}
function togglePass(id){if(EL(id).type=='text')EL(id).type='password';else EL(id).type='text';}
function addSlider(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let col=(ctrl.color!=null)?`background-image: linear-gradient(${intToCol(ctrl.color)}, ${intToCol(ctrl.color)})`:'';let formatted=formatToStep(ctrl.value,ctrl.step);if(wid_row_id){let inner=`
<input ontouchstart="dis_scroll_f=2" ontouchend="dis_scroll_f=0;enableScroll()" name="${ctrl.name}" id="#${ctrl.name}" oninput="moveSlider(this)" type="range" class="c_rangeW slider_t" style="${col}" value="${ctrl.value}" min="${ctrl.min}" max="${ctrl.max}" step="${ctrl.step}"><div class="sldW_out"><output id="out#${ctrl.name}">${formatted}</output></div>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<div class="sld_name">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<label>:&nbsp;</label>
<output id="out#${ctrl.name}">${formatted}</output>
</div>
<div class="cfg_inp_row">
<input ontouchstart="dis_scroll_f=2" ontouchend="dis_scroll_f=0;enableScroll()" name="${ctrl.name}" id="#${ctrl.name}" oninput="moveSlider(this)" type="range" class="c_range slider_t" style="${col}" value="${ctrl.value}" min="${ctrl.min}" max="${ctrl.max}" step="${ctrl.step}">      
</div>
</div>
`;}}
function moveSliders(){document.querySelectorAll('.c_range, .c_rangeW').forEach(x=>{moveSlider(x,false)});}
function moveSlider(arg,sendf=true){if(dis_scroll_f){dis_scroll_f--;if(!dis_scroll_f)disableScroll();}
arg.style.backgroundSize=(arg.value-arg.min)*100/(arg.max-arg.min)+'% 100%';EL('out'+arg.id).value=formatToStep(arg.value,arg.step);if(sendf)input_h(arg.name,arg.value);}
function addSwitch(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let ch=ctrl.value?'checked':'';let col=(ctrl.color!=null)?`<style>#swlabel_${ctrl.name} input:checked+.slider{background:${intToCol(ctrl.color)}}</style>`:'';if(wid_row_id){let inner=`${col}
<label id="swlabel_${ctrl.name}" class="switch"><input type="checkbox" class="switch_t" id='#${ctrl.name}' onclick="set_h('${ctrl.name}',(this.checked ? 1 : 0))" ${ch}><span class="slider"></span></label>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`${col}
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<label id="swlabel_${ctrl.name}" class="switch"><input type="checkbox" class="switch_t" id='#${ctrl.name}' onclick="set_h('${ctrl.name}',(this.checked ? 1 : 0))" ${ch}><span class="slider"></span></label>
</div>
`;}}
function addSwitchIcon(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let ch=ctrl.value?'checked':'';let text=ctrl.text?ctrl.text:'';if(isESP())text="";if(wid_row_id){let col=(ctrl.color!=null)?`<style>#swlabel_${ctrl.name} input:checked+.switch_i_tab{background:${intToCol(ctrl.color)};color:var(--font_inv)} #swlabel_${ctrl.name} .switch_i_tab{box-shadow: 0 0 0 2px ${intToCol(ctrl.color)};color:${intToCol(ctrl.color)}}</style>`:'';let inner=`${col}
<label id="swlabel_${ctrl.name}" class="switch_i_cont switch_i_cont_tab"><input type="checkbox" onclick="set_h('${ctrl.name}',(this.checked ? 1 : 0))" class="switch_t" id='#${ctrl.name}' ${ch}><span class="switch_i switch_i_tab">${text}</span></label>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner,120);}else{let col=(ctrl.color!=null)?`<style>#swlabel_${ctrl.name} input:checked+.switch_i{color:${intToCol(ctrl.color)}}</style>`:'';EL('controls').innerHTML+=`${col}
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<label id="swlabel_${ctrl.name}" class="switch_i_cont"><input type="checkbox" onclick="set_h('${ctrl.name}',(this.checked ? 1 : 0))" class="switch_t" id='#${ctrl.name}' ${ch}><span class="switch_i">${text}</span></label>
</div>
`;}}
function addSwitchText(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let ch=ctrl.value?'checked':'';let text=ctrl.text?ctrl.text:'ON';if(wid_row_id){let col=(ctrl.color!=null)?`<style>#swlabel_${ctrl.name} input:checked+.switch_i_tab{background:${intToCol(ctrl.color)};color:var(--font_inv)} #swlabel_${ctrl.name} .switch_i_tab{box-shadow: 0 0 0 2px ${intToCol(ctrl.color)};color:${intToCol(ctrl.color)}}</style>`:'';let inner=`${col}
<label id="swlabel_${ctrl.name}" class="switch_i_cont switch_i_cont_tab"><input type="checkbox" onclick="set_h('${ctrl.name}',(this.checked ? 1 : 0))" class="switch_t" id='#${ctrl.name}' ${ch}><span class="switch_i switch_i_tab switch_txt switch_txt_tab">${text}</span></label>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner,120);}else{let col=(ctrl.color!=null)?`<style>#swlabel_${ctrl.name} input:checked+.switch_i{color:${intToCol(ctrl.color)}}</style>`:'';EL('controls').innerHTML+=`${col}
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<label id="swlabel_${ctrl.name}" class="switch_i_cont"><input type="checkbox" onclick="set_h('${ctrl.name}',(this.checked ? 1 : 0))" class="switch_t" id='#${ctrl.name}' ${ch}><span class="switch_i switch_txt">${text}</span></label>
</div>
`;}}
function addDate(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let date=new Date(ctrl.value*1000).toISOString().split('T')[0];let col=(ctrl.color!=null)?`color:${intToCol(ctrl.color)}`:'';if(wid_row_id){let inner=`
<input id='#${ctrl.name}' class="cfg_inp c_inp_block c_inp_block_tab date_t" style="${col}" type="date" value="${date}" onclick="this.showPicker()" onchange="set_h('${ctrl.name}',getUnix(this))">
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<input id='#${ctrl.name}' class="cfg_inp c_inp_block datime date_t" style="${col}" type="date" value="${date}" onclick="this.showPicker()" onchange="set_h('${ctrl.name}',getUnix(this))">
</div>
`;}}
function addTime(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let time=new Date(ctrl.value*1000).toISOString().split('T')[1].split('.')[0];let col=(ctrl.color!=null)?`color:${intToCol(ctrl.color)}`:'';if(wid_row_id){let inner=`
<input id='#${ctrl.name}' class="cfg_inp c_inp_block c_inp_block_tab time_t" style="${col}" type="time" value="${time}" onclick="this.showPicker()" onchange="set_h('${ctrl.name}',getUnix(this))" step="1">
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<input id='#${ctrl.name}' class="cfg_inp c_inp_block datime time_t" style="${col}" type="time" value="${time}" onclick="this.showPicker()" onchange="set_h('${ctrl.name}',getUnix(this))" step="1">
</div>
`;}}
function addDateTime(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let datetime=new Date(ctrl.value*1000).toISOString().split('.')[0];let col=(ctrl.color!=null)?`color:${intToCol(ctrl.color)}`:'';if(wid_row_id){let inner=`
<input id='#${ctrl.name}' class="cfg_inp c_inp_block c_inp_block_tab datetime_t" style="${col}" type="datetime-local" value="${datetime}" onclick="this.showPicker()" onchange="set_h('${ctrl.name}',getUnix(this))" step="1">
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<input id='#${ctrl.name}' class="cfg_inp c_inp_block datime datime_w datetime_t" style="${col}" type="datetime-local" value="${datetime}" onclick="this.showPicker()" onchange="set_h('${ctrl.name}',getUnix(this))" step="1">
</div>
`;}}
function getUnix(arg){return Math.floor(arg.valueAsNumber/1000);}
function addColor(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let color=intToCol(ctrl.value);let inner=`
<div id="color_cont#${ctrl.name}" style="visibility: hidden">
<div id='#${ctrl.name}'></div>
</div>
<button id="color_btn#${ctrl.name}" style="margin-left:-30px;color:${color}" class="icon cfg_btn_tab" onclick="openPicker('${ctrl.name}')"></button>
`;if(wid_row_id){addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
${inner}
</div>
`;}
pickers[ctrl.name]=color;}
function openPicker(id){EL('color_cont#'+id).getElementsByTagName('button')[0].click()}
function showPickers(){for(let picker in pickers){let id='#'+picker;let obj=Pickr.create({el:EL(id),theme:'nano',default:pickers[picker],defaultRepresentation:'HEXA',components:{preview:true,hue:true,interaction:{hex:false,input:true,save:true}}}).on('save',(color)=>{let col=color.toHEXA().toString();set_h(picker,colToInt(col));EL('color_btn'+id).style.color=col;});pickers[picker]=obj;}}
function addSpinner(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let formatted=formatToStep(ctrl.value,ctrl.step);if(wid_row_id){let inner=`
<div class="spinner_row">
<button class="icon cfg_btn btn_no_pad" onclick="spinSpinner(this, -1);set_h('${ctrl.name}',EL('#${ctrl.name}').value);"></button>
<input id="#${ctrl.name}" name="${ctrl.name}" class="cfg_inp spinner input_t" type="number" oninput="resizeSpinner(this)" onkeydown="checkEnter(this)" value="${formatted}" min="${ctrl.min}"
max="${ctrl.max}" step="${ctrl.step}">
<button class="icon cfg_btn btn_no_pad" onclick="spinSpinner(this, 1);set_h('${ctrl.name}',EL('#${ctrl.name}').value);"></button>
</div>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<div class="spinner_row">
<button class="icon cfg_btn btn_no_pad" onclick="spinSpinner(this, -1);set_h('${ctrl.name}',EL('#${ctrl.name}').value);"></button>
<input id="#${ctrl.name}" name="${ctrl.name}" class="cfg_inp spinner input_t" type="number" oninput="resizeSpinner(this)" onkeydown="checkEnter(this)" value="${formatted}" min="${ctrl.min}"
max="${ctrl.max}" step="${ctrl.step}">
<button class="icon cfg_btn btn_no_pad" onclick="spinSpinner(this, 1);set_h('${ctrl.name}',EL('#${ctrl.name}').value);"></button>
</div>
</div>
`;}}
function spinSpinner(el,dir){let num=(dir==1)?el.previousElementSibling:el.nextElementSibling;let val=Number(num.value)+Number(num.step)*Number(dir);val=Math.max(Number(num.min),val);val=Math.min(Number(num.max),val);num.value=formatToStep(val,num.step);resizeSpinner(num);}
function resizeSpinner(el){el.style.width=el.value.length+'ch';}
function resizeSpinners(){let spinners=document.querySelectorAll(".spinner");spinners.forEach((sp)=>resizeSpinner(sp));}
function addFlags(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let flags="";let val=ctrl.value;let labels=ctrl.text.toString().split(',');for(let i=0;i<labels.length;i++){let ch=(!(val&1))?'':'checked';val>>=1;flags+=`<label id="swlabel_${ctrl.name}" class="chbutton chtext">
<input name="${ctrl.name}" type="checkbox" onclick="set_h('${ctrl.name}',encodeFlags('${ctrl.name}'))" ${ch}>
<span class="chbutton_s chtext_s">${labels[i]}</span></label>`;}
let col=(ctrl.color!=null)?`<style>#swlabel_${ctrl.name} input:checked+.chbutton_s{background:${intToCol(ctrl.color)}}</style>`:'';if(wid_row_id){let inner=`${col}
<div class="chbutton_cont chbutton_cont_tab flags_t" id='#${ctrl.name}'>
${flags}
</div>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`${col}
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<div class="chbutton_cont flags_t" id='#${ctrl.name}'>
${flags}
</div>
</div>
`;}}
function resizeFlags(){let chtext=document.querySelectorAll(".chtext");let chtext_s=document.querySelectorAll(".chtext_s");chtext.forEach((ch,i)=>{let len=chtext_s[i].innerHTML.length+2;chtext[i].style.width=(len+0.5)+'ch';chtext_s[i].style.width=len+'ch';});}
function encodeFlags(name){let weeks=document.getElementsByName(name);let encoded=0;weeks.forEach((w,i)=>{if(w.checked)encoded|=(1<<weeks.length);encoded>>=1;});return encoded;}
function addCanvas(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();if(wid_row_id){let inner=`
<canvas onclick="clickCanvas('${ctrl.name}',event)" class="${ctrl.active ? 'canvas_act' : ''} canvas_t" id="#${ctrl.name}"></canvas>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="cv_block">
<canvas onclick="clickCanvas('${ctrl.name}',event)" class="${ctrl.active ? 'canvas_act' : ''} canvas_t" id="#${ctrl.name}"></canvas>
</div>
`;}
canvases[ctrl.name]={name:ctrl.name,width:ctrl.width,height:ctrl.height,value:ctrl.value};}
function showCanvases(){Object.values(canvases).forEach(canvas=>{let cv=EL('#'+canvas.name);if(!cv||!cv.parentNode.clientWidth)return;let rw=cv.parentNode.clientWidth;canvas.scale=rw/canvas.width;let rh=Math.floor(canvas.height*canvas.scale);cv.style.width=rw+'px';cv.style.height=rh+'px';cv.width=Math.floor(rw*ratio());cv.height=Math.floor(rh*ratio());canvas.scale*=ratio();drawCanvas(canvas);});}
function drawCanvas(canvas){let ev_str='';let cv=EL('#'+canvas.name);function cv_map(v,h){v*=canvas.scale;return v>=0?v:(h?cv.height:cv.width)-v;}
function scale(){return canvas.scale;}
let cx=cv.getContext("2d");const cmd_list=['fillStyle','strokeStyle','shadowColor','shadowBlur','shadowOffsetX','shadowOffsetY','lineWidth','miterLimit','font','textAlign','textBaseline','lineCap','lineJoin','globalCompositeOperation','globalAlpha','scale','rotate','rect','fillRect','strokeRect','clearRect','moveTo','lineTo','quadraticCurveTo','bezierCurveTo','translate','arcTo','arc','fillText','strokeText','drawImage','roundRect','fill','stroke','beginPath','closePath','clip','save','restore'];const const_list=['butt','round','square','square','bevel','miter','start','end','center','left','right','alphabetic','top','hanging','middle','ideographic','bottom','source-over','source-atop','source-in','source-out','destination-over','destination-atop','destination-in','destination-out','lighter','copy','xor','top','bottom','middle','alphabetic'];for(d of canvas.value){let div=d.indexOf(':');let cmd=parseInt(d,10);if(!isNaN(cmd)&&cmd<=37){if(div==1||div==2){let val=d.slice(div+1);let vals=val.split(',');if(cmd<=2)ev_str+=('cx.'+cmd_list[cmd]+'=\''+intToColA(val)+'\';');else if(cmd<=7)ev_str+=('cx.'+cmd_list[cmd]+'='+(val*scale())+';');else if(cmd<=13)ev_str+=('cx.'+cmd_list[cmd]+'=\''+const_list[val]+'\';');else if(cmd<=14)ev_str+=('cx.'+cmd_list[cmd]+'='+val+';');else if(cmd<=16)ev_str+=('cx.'+cmd_list[cmd]+'('+val+');');else if(cmd<=26){let str='cx.'+cmd_list[cmd]+'(';for(let i in vals){if(i>0)str+=',';str+=`cv_map(${vals[i]},${(i % 2)})`;}
ev_str+=(str+');');}else if(cmd==27){ev_str+=(`cx.${cmd_list[cmd]}(cv_map(${vals[0]},0),cv_map(${vals[1]},1),cv_map(${vals[2]},0),${vals[3]},${vals[4]},${vals[5]});`);}else if(cmd<=29){ev_str+=(`cx.${cmd_list[cmd]}(${vals[0]},cv_map(${vals[1]},0),cv_map(${vals[2]},1),${vals[3]});`);}else if(cmd==30){let str='cx.'+cmd_list[cmd]+'(';for(let i in vals){if(i>0){str+=`,cv_map(${vals[i]},${!(i % 2)})`;}else str+=vals[i];}
ev_str+=(str+');');}else if(cmd==31){let str='cx.'+cmd_list[cmd]+'(';for(let i=0;i<4;i++){if(i>0)str+=',';str+=`cv_map(${vals[i]},${(i % 2)})`;}
if(vals.length==5)str+=`,${vals[4] * scale()}`;else{str+=',[';for(let i=4;i<vals.length;i++){if(i>4)str+=',';str+=`cv_map(${vals[i]},${(i % 2)})`;}
str+=']';}
ev_str+=(str+');');}}else{if(cmd>=32)ev_str+=('cx.'+cmd_list[cmd]+'();');}}else{ev_str+=d+';';}}
eval(ev_str);canvas.value=null;}
function clickCanvas(id,e){if(!(id in canvases))return;let rect=EL('#'+id).getBoundingClientRect();let scale=canvases[id].scale;let x=Math.round((e.clientX-rect.left)/scale*ratio());if(x<0)x=0;let y=Math.round((e.clientY-rect.top)/scale*ratio());if(y<0)y=0;set_h(id,(x<<16)|y);}
function addGauge(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();if(wid_row_id){let inner=`
<canvas class="gauge_t" id="#${ctrl.name}"></canvas>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="cv_block cv_block_back">
<canvas class="gauge_t" id="#${ctrl.name}"></canvas>
</div>
`;}
gauges[ctrl.name]={perc:null,name:ctrl.name,value:Number(ctrl.value),min:Number(ctrl.min),max:Number(ctrl.max),step:Number(ctrl.step),text:ctrl.text,color:ctrl.color};}
function drawGauge(g){let cv=EL('#'+g.name);if(!cv||!cv.parentNode.clientWidth)return;let perc=(g.value-g.min)*100/(g.max-g.min);if(perc<0)perc=0;if(perc>100)perc=100;if(g.perc==null)g.perc=perc;else{if(Math.abs(g.perc-perc)<=0.2)g.perc=perc;else g.perc+=(perc-g.perc)*0.2;if(g.perc!=perc)setTimeout(()=>drawGauge(g),30);}
let cx=cv.getContext("2d");let v=themes[cfg.theme];let col=g.color==null?intToCol(colors[cfg.maincolor]):intToCol(g.color);let rw=cv.parentNode.clientWidth;let rh=Math.floor(rw*0.47);cv.style.width=rw+'px';cv.style.height=rh+'px';cv.width=Math.floor(rw*ratio());cv.height=Math.floor(rh*ratio());cx.clearRect(0,0,cv.width,cv.height);cx.lineWidth=cv.width/8;cx.strokeStyle=theme_cols[v][4];cx.beginPath();cx.arc(cv.width/2,cv.height*0.97,cv.width/2-cx.lineWidth,Math.PI*(1+g.perc/100),Math.PI*2);cx.stroke();cx.strokeStyle=col;cx.beginPath();cx.arc(cv.width/2,cv.height*0.97,cv.width/2-cx.lineWidth,Math.PI,Math.PI*(1+g.perc/100));cx.stroke();let font=cfg.font;cx.fillStyle=col;cx.font='10px '+font;cx.textAlign="center";let text=g.text;let len=Math.max((formatToStep(g.value,g.step)+text).length,(formatToStep(g.min,g.step)+text).length,(formatToStep(g.max,g.step)+text).length);if(len==1)text+='  ';else if(len==2)text+=' ';let w=Math.max(cx.measureText(formatToStep(g.value,g.step)+text).width,cx.measureText(formatToStep(g.min,g.step)+text).width,cx.measureText(formatToStep(g.max,g.step)+text).width);cx.fillStyle=theme_cols[v][3];cx.font=cv.width*0.45*10/w+'px '+font;cx.fillText(formatToStep(g.value,g.step)+g.text,cv.width/2,cv.height*0.93);cx.font='10px '+font;w=Math.max(cx.measureText(Math.round(g.min)).width,cx.measureText(Math.round(g.max)).width);cx.fillStyle=theme_cols[v][2];cx.font=cx.lineWidth*0.55*10/w+'px '+font;cx.fillText(g.min,cx.lineWidth,cv.height*0.92);cx.fillText(g.max,cv.width-cx.lineWidth,cv.height*0.92);}
function showGauges(){Object.values(gauges).forEach(gauge=>{drawGauge(gauge);});}
function addJoy(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let inner=`
<div class="joyCont"><canvas id="#${ctrl.name}"></canvas></div>
`;if(wid_row_id){addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=inner;}
joys[ctrl.name]=ctrl;}
function showJoys(){for(let joy in joys){joys[joy].joy=new Joystick(joy,joys[joy].type=='dpad',intToCol(joys[joy].color==null?colors[cfg.maincolor]:joys[joy].color),joys[joy].auto,joys[joy].exp,function(data){input_h(joy,((data.x+255)<<16)|(data.y+255));});}}
function addSpace(ctrl){if(wid_row_id){checkWidget(ctrl);wid_row_size+=ctrl.tab_w;if(wid_row_size>100){beginWidgets();wid_row_size=ctrl.tab_w;}
EL(wid_row_id).innerHTML+=`
<div class="widget" style="width:${ctrl.tab_w}%"><div class="widget_inner widget_space"></div></div>
`;}else{endButtons();EL('controls').innerHTML+=`
<div style="height:${ctrl.height}px"></div>
`;}}
function addTitle(ctrl){endWidgets();endButtons();EL('controls').innerHTML+=`
<div class="control control_title">
<span class="c_title">${ctrl.label}</span>
</div>
`;}
function addLED(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let ch=ctrl.value?'checked':'';if(ctrl.text&&!isESP()){if(wid_row_id){let inner=`
<label id="swlabel_${ctrl.name}" class="led_i_cont led_i_cont_tab"><input type="checkbox" class="switch_t" id='#${ctrl.name}' ${ch} disabled><span class="switch_i led_i led_i_tab">${ctrl.text}</span></label>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<label id="swlabel_${ctrl.name}" class="led_i_cont"><input type="checkbox" class="switch_t" id='#${ctrl.name}' ${ch} disabled><span class="switch_i led_i">${ctrl.text}</span></label>
</div>
`;}}else{if(wid_row_id){let inner=`
<label class="led_cont"><input type="checkbox" class="switch_t" id='#${ctrl.name}' ${ch} disabled><span class="led"></span></label>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<label class="led_cont"><input type="checkbox" class="switch_t" id='#${ctrl.name}' ${ch} disabled><span class="led"></span></label>
</div>
`;}}}
function addIcon(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();if(isESP())ctrl.text="";let col=(ctrl.color!=null)?`color:${intToCol(ctrl.color)}`:'';if(wid_row_id){let inner=`
<span class="icon icon_t" id='#${ctrl.name}' style="${col}">${ctrl.text}</span>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<span class="icon icon_t" id='#${ctrl.name}' style="${col}">${ctrl.text}</span>
</div>
`;}}
function addLabel(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let col=(ctrl.color)?(`color:${intToCol(ctrl.color)}`):'';if(wid_row_id){let inner=`
<label class="c_label text_t c_label_tab" id='#${ctrl.name}' style="${col};font-size:${ctrl.size}px">${ctrl.value}</label>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<label class="c_label text_t" id='#${ctrl.name}' style="${col};font-size:${ctrl.size}px">${ctrl.value}</label>
</div>
`;}}
function addSelect(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let elms=ctrl.text.toString().split(',');let options='';for(let i in elms){let sel=(i==ctrl.value)?'selected':'';options+=`<option value="${i}" ${sel}>${elms[i]}</option>`;}
let col=(ctrl.color!=null)?`color:${intToCol(ctrl.color)}`:'';if(wid_row_id){let inner=`
<select class="cfg_inp c_inp_block select_t" style="${col}" id='#${ctrl.name}' onchange="set_h('${ctrl.name}',this.value)">
${options}
</select>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<label title='${ctrl.name}'>${ctrl.clabel}</label>
<select class="cfg_inp c_inp_block select_t" style="${col}" id='#${ctrl.name}' onchange="set_h('${ctrl.name}',this.value)">
${options}
</select>
</div>
`;}}
function addLog(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();if(ctrl.text.endsWith('\n'))ctrl.text=ctrl.text.slice(0,-1);if(wid_row_id){let inner=`
<textarea id="#${ctrl.name}" title='${ctrl.name}' class="cfg_inp c_log text_t" readonly>${ctrl.text}</textarea>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<textarea id="#${ctrl.name}" title='${ctrl.name}' class="cfg_inp c_log text_t" readonly>${ctrl.text}</textarea>
</div>
`;}}
function addDisplay(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let col=(ctrl.color!=null)?('background:'+intToCol(ctrl.color)):'';if(wid_row_id){let inner=`
<textarea id="#${ctrl.name}" title='${ctrl.name}' class="cfg_inp c_area c_disp text_t" style="font-size:${ctrl.size}px;${col}" rows="${ctrl.rows}" readonly>${ctrl.value}</textarea>
`;addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control">
<textarea id="#${ctrl.name}" title='${ctrl.name}' class="cfg_inp c_area c_disp text_t" style="font-size:${ctrl.size}px;${col}" rows="${ctrl.rows}" readonly>${ctrl.value}</textarea>
</div>
`;}}
function addHTML(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let inner=`<div name="text" id="#${ctrl.name}" title='${ctrl.name}' class="c_text text_t">${ctrl.value}</div>`;if(wid_row_id){addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control control_nob">
${inner}
</div>
`;}}
function addImage(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let inner=`
<div class="image_t" name="${ctrl.value}" id="#${ctrl.name}">${waiter()}</div>
`;if(wid_row_id){addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="cv_block cv_block_back">
${inner}
</div>
`;}
files.push({id:'#'+ctrl.name,path:ctrl.value,type:'img'});}
function addStream(ctrl,conn,ip){checkWidget(ctrl);endButtons();let inner='<label>No connection</label>';if(conn==Conn.WS&&ip!='unset')inner=`<img style="width:100%" src="http://${ip}:${ctrl.port}/">`;if(wid_row_id){addWidget(ctrl.tab_w,'',ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="cv_block cv_block_back">
${inner}
</div>
`;}}
function addTable(ctrl){if(checkDup(ctrl))return;checkWidget(ctrl);endButtons();let table=parseCSV(ctrl.value);let aligns=ctrl.align.split(',');let widths=ctrl.width.split(',');let inner='<table class="c_table">';for(let row of table){inner+='<tr>';for(let col in row){inner+=`<td width="${widths[col] ? (widths[col] + '%') : ''}" align="${aligns[col] ? aligns[col] : 'center'}">${row[col]}</td>`;}
inner+='</tr>';}
inner+='</table>';if(wid_row_id){addWidget(ctrl.tab_w,ctrl.name,ctrl.wlabel,inner);}else{EL('controls').innerHTML+=`
<div class="control control_nob">
${inner}
</div>
`;}}
function checkWidget(ctrl){if(ctrl.tab_w&&!wid_row_id)beginWidgets(null,true);}
function beginWidgets(ctrl=null,check=false){if(!check)endButtons();wid_row_size=0;if(devices[focused].break_widgets)return;let st=(ctrl&&ctrl.height)?`style="height:${ctrl.height}px"`:'';wid_row_id='widgets_row#'+wid_row_count;wid_row_count++;EL('controls').innerHTML+=`
<div class="widget_row" id="${wid_row_id}" ${st}></div>
`;}
function endWidgets(){endButtons();wid_row_id=null;}
function addWidget(width,name,label,inner,height=0,noback=false){wid_row_size+=width;if(wid_row_size>100){beginWidgets();wid_row_size=width;}
let h=height?('height:'+height+'px'):'';let lbl=(label&&label!='_no')?`<div class="widget_label" title="${name}">${label}<span id="wlabel#${name}"></span></div>`:'';EL(wid_row_id).innerHTML+=`
<div class="widget" style="width:${width}%;${h}">
<div class="widget_inner ${noback ? 'widget_space' : ''}">
${lbl}
<div class="widget_block">
${inner}
</div>
</div>
</div>
`;}
function showNotif(text,name){if(!("Notification"in window)||Notification.permission!='granted')return;let descr=name+' ('+new Date(Date.now()).toLocaleString()+')';navigator.serviceWorker.getRegistration().then(function(reg){reg.showNotification(text,{body:descr,vibrate:true});});}
function checkDup(ctrl){if(EL('#'+ctrl.name)){dup_names.push(' '+ctrl.name);return 1;}
return 0;}
function formatToStep(val,step){step=step.toString();if(step.includes('.'))return Number(val).toFixed((step.split('.')[1]).toString().length);else return val;}
function scrollDown(){let logs=document.querySelectorAll(".c_log");logs.forEach((log)=>log.scrollTop=log.scrollHeight);}
function parseCSV(str){const arr=[];let quote=false;for(let row=0,col=0,c=0;c<str.length;c++){let cc=str[c],nc=str[c+1];arr[row]=arr[row]||[];arr[row][col]=arr[row][col]||'';if(cc=='"'&&quote&&nc=='"'){arr[row][col]+=cc;++c;continue;}
if(cc=='"'){quote=!quote;continue;}
if(cc==','&&!quote){++col;continue;}
if(cc=='\r'&&nc=='\n'&&!quote){++row;col=0;++c;continue;}
if(cc=='\n'&&!quote){++row;col=0;continue;}
if(cc=='\r'&&!quote){++row;col=0;continue;}
arr[row][col]+=cc;}
return arr;}
function nextFile(){if(!files.length)return;fetch_to_file=true;if(devices_t[focused].conn==Conn.WS&&devices_t[focused].http_cfg.download&&files[0].path.startsWith(devices_t[focused].http_cfg.path)){downloadFile();EL('wlabel'+files[0].id).innerHTML=' [fetch...]';}else{fetch_path=files[0].path;post('fetch',fetch_path);}}
function downloadFile(){fetching=focused;var xhr=new XMLHttpRequest();xhr.responseType='blob';xhr.open('GET','http://'+devices[focused].ip+':'+http_port+files[0].path);xhr.onprogress=function(e){processFile(Math.round(e.loaded*100/e.total));};xhr.onloadend=function(e){if(e.loaded&&e.loaded==e.total){processFile(100);var reader=new FileReader();reader.readAsDataURL(xhr.response);reader.onloadend=function(){downloadFileEnd(this.result.split('base64,')[1]);}}else{errorFile();}}
xhr.send();}
function downloadFileEnd(data){switch(files[0].type){case'img':EL(files[0].id).innerHTML=`<img style="width:100%" src="data:${getMime(files[0].path)};base64,${data}">`;if(EL('wlabel'+files[0].id))EL('wlabel'+files[0].id).innerHTML='';break;}
files.shift();nextFile();fetching=null;stopFS();}
function processFile(perc){if(EL('wlabel'+files[0].id))EL('wlabel'+files[0].id).innerHTML=` [${perc}%]`;}
function errorFile(){if(EL('wlabel'+files[0].id))EL('wlabel'+files[0].id).innerHTML=' [error]';files.shift();nextFile();}
const http_port=80;const ws_port=81;const tout_prd=2800;const ping_prd=3000;const oninput_prd=100;const ws_tout=4000;let discovering=false;let mq_client;let mq_discover_flag=false;let mq_pref_list=[];let ws_focus_flag=false;let tout_interval=null;let ping_interval=null;let set_tout=null;let oninput_tout=null;let refresh_ui=false;let s_port=null,s_state=false,s_reader=null,s_buf='';const Conn={SERIAL:0,BT:1,WS:2,MQTT:3,NONE:4,ERROR:5,};const ConnNames=['Serial','BT','WS','MQTT','None','Error'];function post(cmd,name='',value=''){if(!focused)return;if(cmd=='set'&&!readModule(Modules.SET))return;if(cmd=='set'){if(set_tout)clearTimeout(set_tout);prev_set={name:name,value:value};set_tout=setTimeout(()=>{set_tout=prev_set=null;},tout_prd);}
let id=focused;cmd=cmd.toString();name=name.toString();value=value.toString();let uri0=devices[id].prefix+'/'+id+'/'+hub.cfg.client_id+'/'+cmd;let uri=uri0;if(name)uri+='/'+name;if(value)uri+='='+value;switch(devices_t[id].conn){case Conn.SERIAL:serial_send(uri);break;case Conn.BT:bt_send(uri);break;case Conn.WS:ws_send(id,uri);break;}
reset_ping();reset_tout();log('Post to #'+id+' via '+ConnNames[devices_t[id].conn]+', cmd='+cmd+(name?(', name='+name):'')+(value?(', value='+value):''))}
function release_all(){if(pressId)post('set',pressId,0);pressId=null;}
function click_h(name,dir){pressId=(dir==1)?name:null;post('set',name,dir);reset_ping();}
function set_h(name,value=''){post('set',name,value);reset_ping();}
function input_h(name,value){if(!(name in oninp_buffer))oninp_buffer[name]={'value':null,'tout':null};if(!oninp_buffer[name].tout){set_h(name,value);oninp_buffer[name].tout=setTimeout(()=>{if(oninp_buffer[name].value!=null&&!tout_interval)set_h(name,oninp_buffer[name].value);oninp_buffer[name].tout=null;oninp_buffer[name].value=null;},oninput_prd);}else{oninp_buffer[name].value=value;}}
function reboot_h(){post('reboot');}
function change_conn(conn){EL('conn').innerHTML=ConnNames[conn];}
function stop_tout(){refreshSpin(false);if(tout_interval)clearTimeout(tout_interval);tout_interval=null;}
function reset_tout(){if(tout_interval)return;refreshSpin(true);tout_interval=setTimeout(function(){log('Connection lost');refresh_ui=true;change_conn(Conn.ERROR);showErr(true);stop_tout();},tout_prd);}
function stop_ping(){if(ping_interval)clearInterval(ping_interval);ping_interval=null;}
function reset_ping(){stop_ping();ping_interval=setInterval(()=>{if(refresh_ui){refresh_ui=false;if(screen=='info')post('info');else if(screen=='fsbr')post('fsbr');else post('focus');}else{post('ping');}},ping_prd);}
function parsePacket(id,text,conn){function checkPacket(){if(devices_t[id]['buffer'][ConnNames[conn]].endsWith('}\n')){if(devices_t[id]['buffer'][ConnNames[conn]].startsWith('\n{'))parseDevice(id,devices_t[id]['buffer'][ConnNames[conn]],conn);devices_t[id]['buffer'][ConnNames[conn]]='';}}
if(conn==Conn.BT||conn==Conn.SERIAL){for(let i=0;i<text.length;i++){devices_t[id]['buffer'][ConnNames[conn]]+=text[i];checkPacket();}}else{devices_t[id]['buffer'][ConnNames[conn]]+=text;checkPacket();}}
function ws_start(id){if(!hub.cfg.use_ws)return;checkHTTP(id);if(devices_t[id].ws)return;if(devices[id].ip=='unset')return;log(`WS ${id} open...`);devices_t[id].ws=new WebSocket(`ws://${devices[id].ip}:${ws_port}/`,['hub']);devices_t[id].ws.onopen=function(){log(`WS ${id} opened`);if(ws_focus_flag){ws_focus_flag=false;post('focus');}
if(id!=focused)devices_t[id].ws.close();};devices_t[id].ws.onclose=function(){log(`WS ${id} closed`);devices_t[id].ws=null;ws_focus_flag=false;if(id==focused)setTimeout(()=>ws_start(id),500);};devices_t[id].ws.onerror=function(){log(`WS ${id} error`);};devices_t[id].ws.onmessage=function(event){reset_tout();parsePacket(id,event.data,Conn.WS);};}
function ws_stop(id){if(!devices_t[id].ws||devices_t[id].ws.readyState>=2)return;log(`WS ${id} close...`);devices_t[id].ws.close();}
function ws_state(id){return(devices_t[id].ws&&devices_t[id].ws.readyState==1);}
function ws_send(id,text){if(ws_state(id))devices_t[id].ws.send(text.toString()+'\0');}
function ws_discover(){for(let id in devices){if(devices[id].ip=='unset')continue;ws_discover_ip(devices[id].ip,id);log('WS discover');}}
function ws_discover_ip(ip,id='broadcast'){let ws=new WebSocket(`ws://${ip}:${ws_port}/`,['hub']);let tout=setTimeout(()=>{if(ws)ws.close();},ws_tout);ws.onopen=()=>ws.send(hub.cfg.prefix+(id!='broadcast'?('/'+id):'')+'\0');ws.onerror=()=>ws.close();ws.onclose=()=>ws=null;ws.onmessage=function(event){clearTimeout(tout);parseDevice(id,event.data,Conn.WS,ip);ws.close();};}
function ws_discover_ips(ips){discovering=true;refreshSpin(true);setTimeout(()=>{refreshSpin(false);discovering=false;},ws_tout/200*ips.length);for(let i in ips){setTimeout(()=>ws_discover_ip(ips[i]),ws_tout/200*i);}
log('WS discover all');}
function http_hook(ips){discovering=true;refreshSpin(true);setTimeout(()=>{refreshSpin(false);discovering=false;},ws_tout);function hook(ip){try{let xhr=new XMLHttpRequest();xhr.onreadystatechange=function(){if(this.readyState==4&&this.status==200){if(this.responseText=='OK')ws_discover_ip(ip);}}
xhr.timeout=tout_prd;xhr.open("GET",'http://'+ip+':'+http_port+'/hub_discover_all');xhr.send();}catch(e){}}
for(let i in ips){setTimeout(()=>hook(ips[i]),10*i);}
log('WS hook discover all');}
function ws_discover_all(){let ip_arr=getIPs();if(ip_arr==null)return;if(hub.cfg.use_hook)http_hook(ip_arr);else ws_discover_ips(ip_arr);}
function manual_ws_h(ip){if(!checkIP(ip)){showPopupError('Wrong IP!');return;}
log('WS manual '+ip);ws_discover_ip(ip);back_h();}
function checkHTTP(id){if(devices_t[id].http_cfg.upd)return;let xhr=new XMLHttpRequest();xhr.onreadystatechange=function(){if(this.readyState==4&&this.status==200){devices_t[id].http_cfg.upd=1;let resp;try{resp=JSON.parse(this.responseText);}catch(e){return;}
for(let i in resp){if(resp[i])devices_t[id].http_cfg[i]=resp[i];}}}
xhr.timeout=tout_prd;xhr.open("GET",'http://'+devices[id].ip+':'+http_port+'/hub_http_cfg');xhr.send();}
let fs_arr=[];let fetching=null;let fetch_name;let fetch_index;let fetch_file='';let fetch_path='';let fetch_tout;let fetch_to_file=false;let edit_idx=0;let uploading=null;let upload_tout;let upload_bytes=[];let upload_size;let ota_tout;function stopFS(){if(fetching)post('fetch_stop',fetch_path);stop_fetch_tout();stop_upload_tout();stop_ota_tout();upload_bytes=[];fetching=null;uploading=null;}
function stop_fetch_tout(){if(fetch_tout)clearTimeout(fetch_tout);}
function reset_fetch_tout(){stop_fetch_tout();fetch_tout=setTimeout(()=>{stopFS();if(!fetch_to_file)EL('process#'+fetch_index).innerHTML='Error!';},tout_prd);}
function stop_upload_tout(){if(upload_tout)clearTimeout(upload_tout);}
function reset_upload_tout(){stop_upload_tout();upload_tout=setTimeout(()=>{stopFS();EL('file_upload_btn').innerHTML='Error!';setTimeout(()=>EL('file_upload_btn').innerHTML='Upload',2000);},tout_prd);}
function stop_ota_tout(){if(ota_tout)clearTimeout(ota_tout);}
function reset_ota_tout(){stop_ota_tout();ota_tout=setTimeout(()=>{stopFS();EL('ota_label').innerHTML='Error!';setTimeout(()=>EL('ota_label').innerHTML='IDLE',3000);},tout_prd);}
function showFsbr(device){fs_arr=[];for(let path in device.fs)fs_arr.push(path);fs_arr=sortPaths(fs_arr,'/');let inner='';for(let i in fs_arr){if(fs_arr[i].endsWith('/')){inner+=`<div class="fs_file fs_folder drop_area" onclick="file_upload_path.value='${fs_arr[i]}'/*;file_upload_btn.click()*/" ondrop="file_upload_path.value='${fs_arr[i]}';uploadFile(event.dataTransfer.files[0],'${fs_arr[i]}')">${fs_arr[i]}</div>`;}else{let none="style='display:none'";inner+=`<div class="fs_file" onclick="openFSctrl(${i})">${fs_arr[i]}<div class="fs_weight">${(device.fs[fs_arr[i]] / 1000).toFixed(2)} kB</div></div>
<div id="fs#${i}" class="fs_controls">
<button ${readModule(Modules.RENAME) ? '' : none} title="Rename" class="icon cfg_btn_tab" onclick="renameFile(${i})"></button>
<button ${readModule(Modules.DELETE) ? '' : none} title="Delete" class="icon cfg_btn_tab" onclick="deleteFile(${i})"></button>
<button ${readModule(Modules.DOWNLOAD) ? '' : none} title="Fetch" class="icon cfg_btn_tab" onclick="fetchFile(${i})"></button>
<label id="process#${i}"></label>
<a id="download#${i}" title="Download" class="icon cfg_btn_tab" href="" download="" style="display:none"></a>
<button id="open#${i}" title="Open" class="icon cfg_btn_tab" onclick="openFile(EL('download#${i}').href)" style="display:none"></button>
<button ${readModule(Modules.UPLOAD) ? '' : none} id="edit#${i}" title="Edit" class="icon cfg_btn_tab" onclick="editFile(EL('download#${i}').href,'${i}')" style="display:none"></button>
</div>`;}}
if(device.total)inner+=`<div class="fs_info">Used ${(device.used / 1000).toFixed(2)}/${(device.total / 1000).toFixed(2)} kB [${Math.round(device.used / device.total * 100)}%]</div>`;else inner+=`<div class="fs_info">Used ${(device.used / 1000).toFixed(2)} kB</div>`;EL('fsbr_inner').innerHTML=inner;let ota_t='.'+devices[focused].ota_t;EL('ota_upload').accept=ota_t;EL('ota_upload_fs').accept=ota_t;EL('ota_url_f').value="http://url_to_flash"+ota_t;EL('ota_url_fs').value="http://url_to_filesystem"+ota_t;}
function openFSctrl(i){let current=EL(`fs#${i}`).style.display=='flex';document.querySelectorAll('.fs_controls').forEach(el=>el.style.display='none');if(!current)EL(`fs#${i}`).style.display='flex';}
function renameFile(i){if(fetching||uploading){showPopupError('Busy');return;}
let path=fs_arr[i];let res=prompt('Rename '+path+' to',path);if(res&&res!=path)post('rename',path,res);}
function deleteFile(i){if(fetching||uploading){showPopupError('Busy');return;}
let path=fs_arr[i];if(confirm('Delete '+path+'?'))post('delete',path);}
function fetchFile(i){if(fetching||uploading){showPopupError('Busy');return;}
EL('download#'+i).style.display='none';EL('open#'+i).style.display='none';EL('process#'+i).style.display='unset';EL('process#'+i).innerHTML='';fetch_path=fs_arr[i];fetch_index=i;fetch_name=fetch_path.split('/').pop();fetch_to_file=false;if(devices_t[focused].conn==Conn.WS&&devices_t[focused].http_cfg.download&&fetch_path.startsWith(devices_t[focused].http_cfg.path))fetchHTTP(fetch_path,fetch_name,fetch_index)
else post('fetch',fetch_path);}
function openFile(src){let w=window.open();src=w.document.write('<iframe src="'+src+'" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>');}
function format_h(){if(confirm('Format filesystem?'))post('format');}
function updatefs_h(){post('fsbr');}
function editFile(data,idx){function b64ToText(base64){const binString=atob(base64);return new TextDecoder().decode(Uint8Array.from(binString,(m)=>m.codePointAt(0)));}
EL('editor_area').value=b64ToText(data.split('base64,')[1]);EL('editor_area').scrollTop=0;EL('edit_path').innerHTML=fs_arr[idx];EL('fsbr').style.display='none';EL('fsbr_edit').style.display='block';edit_idx=idx;}
function editor_save(){editor_cancel();let div=fs_arr[edit_idx].lastIndexOf('/');let path=fs_arr[edit_idx].slice(0,div);let name=fs_arr[edit_idx].slice(div+1);uploadFile(new File([EL('editor_area').value],name,{type:getMime(name),lastModified:new Date()}),path);}
function editor_cancel(){EL('fsbr').style.display='block';EL('fsbr_edit').style.display='none';}
function fetchHTTP(path,name,index){fetching=focused;EL('process#'+index).innerHTML='0%';var xhr=new XMLHttpRequest();xhr.responseType='blob';xhr.open('GET','http://'+devices[focused].ip+':'+http_port+path);xhr.onprogress=function(e){EL('process#'+index).innerHTML=Math.round(e.loaded*100/e.total)+'%';};xhr.onloadend=function(e){if(e.loaded&&e.loaded==e.total){EL('process#'+index).innerHTML='100%';var reader=new FileReader();reader.readAsDataURL(xhr.response);reader.onloadend=function(){fetchEnd(name,index,this.result.split('base64,')[1]);}}else{EL('process#'+index).innerHTML='Error';showPopupError('Error fetch '+path);}}
xhr.send();}
function fetchEnd(name,index,data){if(!fetching)return;EL('download#'+index).style.display='inline-block';EL('download#'+index).href=('data:'+getMime(name)+';base64,'+data);EL('download#'+index).download=name;EL('open#'+index).style.display='inline-block';EL('edit#'+index).style.display='inline-block';EL('process#'+index).style.display='none';fetching=null;stopFS();}
function uploadFile(file,path){if(fetching||uploading){showPopupError('Busy');return clearFiles();}
let reader=new FileReader();reader.readAsArrayBuffer(file);reader.onload=function(e){if(!e.target.result)return clearFiles();let buffer=new Uint8Array(e.target.result);if(!path.startsWith('/'))path='/'+path;if(!path.endsWith('/'))path+='/';path+=file.name;if(!confirm('Upload '+path+' ('+buffer.length+' bytes)?'))return clearFiles();if(devices_t[focused].conn==Conn.WS&&devices_t[focused].http_cfg.upload){EL('file_upload_btn').innerHTML=waiter(22,'var(--font_inv)',false);let formData=new FormData();formData.append('upload',file,path);let xhr=new XMLHttpRequest();xhr.open("POST",'http://'+devices[focused].ip+':'+http_port+'/upload');xhr.onreadystatechange=function(){if(this.responseText=='OK')showPopup('Done');if(this.responseText=='FAIL')showPopupError('Error');}
xhr.onload=function(){setLabelTout('file_upload_btn','Done','Upload');post('fsbr');}
xhr.onerror=function(){setLabelTout('file_upload_btn','Error!','Upload');}
xhr.send(formData);}else{upload_bytes=[];for(b of buffer)upload_bytes.push(b);upload_size=upload_bytes.length;post('upload',path);}
clearFiles();}}
function uploadNextChunk(){let i=0;let data='';while(true){if(!upload_bytes.length)break;i++;data+=String.fromCharCode(upload_bytes.shift());if(i>=devices[focused].max_upl*3/4)break;}
EL('file_upload_btn').innerHTML=Math.round((upload_size-upload_bytes.length)/upload_size*100)+'%';post('upload_chunk',(upload_bytes.length)?'next':'last',window.btoa(data));}
function clearFiles(){EL('file_upload').value='';EL('ota_upload').value='';EL('ota_upload_fs').value='';}
function uploadOta(file,type){if(fetching||uploading){showPopupError('Busy');return clearFiles();}
if(!file.name.endsWith(devices[focused].ota_t)){alert('Wrong file! Use .'+devices[focused].ota_t);return clearFiles();}
if(!confirm('Upload OTA '+type+'?'))return clearFiles();let reader=new FileReader();reader.readAsArrayBuffer(file);reader.onload=function(e){if(!e.target.result)return clearFiles();if(devices_t[focused].conn==Conn.WS&&devices_t[focused].http_cfg.ota){EL('ota_label').innerHTML=waiter(25,'var(--font)',false);let formData=new FormData();formData.append(type,file,file.name);let xhr=new XMLHttpRequest();xhr.open("POST",'http://'+devices[focused].ip+':'+http_port+'/ota?type='+type);xhr.onreadystatechange=function(){if(this.responseText=='OK')showPopup('Done');if(this.responseText=='FAIL')showPopupError('Error');}
xhr.onload=function(){setLabelTout('ota_label','DONE','IDLE');}
xhr.onerror=function(){setLabelTout('ota_label','ERROR','IDLE');}
xhr.send(formData);}else{let buffer=new Uint8Array(e.target.result);upload_bytes=[];for(b of buffer)upload_bytes.push(b);upload_size=upload_bytes.length;post('ota',type);}
clearFiles();}}
function otaNextChunk(){let i=0;let data='';while(true){if(!upload_bytes.length)break;i++;data+=String.fromCharCode(upload_bytes.shift());if(i>=devices[focused].max_upl*3/4)break;}
EL('ota_label').innerHTML=Math.round((upload_size-upload_bytes.length)/upload_size*100)+'%';post('ota_chunk',(upload_bytes.length)?'next':'last',window.btoa(data));}
function otaUrl(url,type){post('ota_url',type,url);showPopup('OTA start');}
let push_timer=0;let prev_set=null;function applyUpdate(name,value){if(screen!='device')return;if(prev_set&&prev_set.name==name&&prev_set.value==value){prev_set=null;return;}
if(name in prompts){release_all();let res=prompt(value?value:prompts[name].label,prompts[name].value);if(res!==null){prompts[name].value=res;set_h(name,res);}
return;}
if(name in confirms){release_all();let res=confirm(value?value:confirms[name].label);set_h(name,res?1:0);return;}
if(name in pickers){pickers[name].setColor(intToCol(value));return;}
let el=EL('#'+name);if(!el)return;cl=el.classList;if(cl.contains('icon_t'))el.style.color=value;else if(cl.contains('text_t'))el.innerHTML=value;else if(cl.contains('input_t'))el.value=value;else if(cl.contains('date_t'))el.value=new Date(value*1000).toISOString().split('T')[0];else if(cl.contains('time_t'))el.value=new Date(value*1000).toISOString().split('T')[1].split('.')[0];else if(cl.contains('datetime_t'))el.value=new Date(value*1000).toISOString().split('.')[0];else if(cl.contains('slider_t'))el.value=value,EL('out#'+name).innerHTML=value,moveSlider(el,false);else if(cl.contains('switch_t'))el.checked=(value=='1');else if(cl.contains('select_t'))el.value=value;else if(cl.contains('image_t')){files.push({id:'#'+name,path:(value?value:EL('#'+name).getAttribute("name")),type:'img'});EL('wlabel#'+name).innerHTML=' [0%]';if(files.length==1)nextFile();}
else if(cl.contains('canvas_t')){if(name in canvases){if(!canvases[name].value){canvases[name].value=value;drawCanvas(canvases[name]);}}}
else if(cl.contains('gauge_t')){if(name in gauges){gauges[name].value=Number(value);drawGauge(gauges[name]);}}
else if(cl.contains('flags_t')){let flags=document.getElementById('#'+name).getElementsByTagName('input');let val=value;for(let i=0;i<flags.length;i++){flags[i].checked=val&1;val>>=1;}}}
function updateDevice(mem,dev){mem.id=dev.id;mem.name=dev.name;mem.icon=dev.icon;mem.PIN=dev.PIN;mem.version=dev.version;mem.max_upl=dev.max_upl;mem.modules=dev.modules;mem.ota_t=dev.ota_t;save_devices();}
function compareDevice(mem,dev){return mem.id!=dev.id||mem.name!=dev.name||mem.icon!=dev.icon||mem.PIN!=dev.PIN||mem.version!=dev.version||mem.max_upl!=dev.max_upl||mem.modules!=dev.modules||mem.ota_t!=dev.ota_t;}
function parseDevice(fromID,text,conn,ip='unset'){let device;text=text.trim().replaceAll(/([^\\])\\([^\"\\nrt])/ig,"$1\\\\$2").replaceAll(/\t/ig,"\\t").replaceAll(/\n/ig,"\\n").replaceAll(/\r/ig,"\\r");try{device=JSON.parse(text);}catch(e){log('Wrong packet (JSON):'+text);return;}
let id=device.id;if(!id)return log('Wrong packet (ID)');if(fromID!='broadcast'&&fromID!=id)return log('Wrong packet (Unknown ID)');if(fromID=='broadcast'&&device.type!='discover'&&device.type!='update'&&device.type!='push'&&device.type!='print'&&device.type!='data')return log('Wrong packet (error)');log('Got packet from #'+id+' '+device.type+' via '+ConnNames[conn]);if(id==focused){stop_tout();showErr(false);change_conn(devices_t[focused].conn);}
switch(device.type){case'data':break;case'alert':release_all();alert(device.text);break;case'notice':showPopup(device.text,intToCol(device.color));break;case'OK':break;case'ERR':showPopupError(device.text);break;case'discover':if(focused)return;if(device.modules==undefined)device.modules=0;if(device.ota_t==undefined)device.ota_t='bin';if(id in devices){let upd=false;if(compareDevice(devices[id],device))upd=true;if(devices[id].ip=='unset'&&ip!='unset'){devices[id].ip=ip;upd=true;}
if(upd){log('Update device #'+id);updateDevice(devices[id],device);EL(`name#${id}`).innerHTML=device.name?device.name:'Unknown';}}else{log('Add new device #'+id);devices[id]={prefix:hub.cfg.prefix,break_widgets:false,show_names:false,ip:ip};updateDevice(devices[id],device);addDevice(id);}
if(!(id in devices_t)){devices_t[id]={conn:Conn.NONE,ws:null,controls:null,granted:false,buffer:{WS:'',MQTT:'',Serial:'',BT:''},port:null,http_cfg:{upd:0,upload:0,download:0,ota:0,path:'/fs/'}};}
EL(`device#${id}`).className="device";EL(`${ConnNames[conn]}#${id}`).style.display='unset';if(conn<devices_t[id].conn)devices_t[id].conn=conn;break;case'print':if(id!=focused)return;printCLI(device.text,device.color);break;case'update':if(id!=focused)return;if(!(id in devices))return;for(let name in device.updates)applyUpdate(name,device.updates[name]);break;case'ui':if(id!=focused)return;devices_t[id].controls=device.controls;showControls(device.controls,false,conn,devices[focused].ip);break;case'info':if(id!=focused)return;showInfo(device);break;case'push':if(!(id in devices))return;let date=(new Date).getTime();if(date-push_timer<3000)return;push_timer=date;showNotif(device.text,devices[id].name);break;case'fsbr':if(id!=focused)return;showFsbr(device);break;case'fs_error':if(id!=focused)return;EL('fsbr_inner').innerHTML='<div class="fs_err">FS ERROR</div>';break;case'fetch_start':if(id!=focused)return;fetching=focused;fetch_file='';post('fetch_chunk',fetch_path);reset_fetch_tout();break;case'fetch_next_chunk':if(id!=fetching)return;fetch_file+=device.data;if(device.chunk==device.amount-1){if(fetch_to_file)downloadFileEnd(fetch_file);else fetchEnd(fetch_name,fetch_index,fetch_file);}else{let perc=Math.round(device.chunk/device.amount*100);if(fetch_to_file)processFile(perc);else EL('process#'+fetch_index).innerHTML=perc+'%';post('fetch_chunk',fetch_path);reset_fetch_tout();}
break;case'fetch_err':if(id!=focused)return;if(fetch_to_file)errorFile();else EL('process#'+fetch_index).innerHTML='Aborted';showPopupError('Fetch aborted');stopFS();break;case'upload_err':showPopupError('Upload aborted');setLabelTout('file_upload_btn','Error!','Upload');stopFS();break;case'upload_start':if(id!=focused)return;uploading=focused;uploadNextChunk();reset_upload_tout();break;case'upload_next_chunk':if(id!=uploading)return;uploadNextChunk();reset_upload_tout();break;case'upload_end':showPopup('Upload Done!');stopFS();setLabelTout('file_upload_btn','Done!','Upload');post('fsbr');break;case'ota_err':showPopupError('Ota aborted');setLabelTout('ota_label','ERROR','IDLE');stopFS();break;case'ota_start':if(id!=focused)return;uploading=focused;otaNextChunk();reset_ota_tout();break;case'ota_next_chunk':if(id!=uploading)return;otaNextChunk();reset_ota_tout();break;case'ota_end':showPopup('OTA Done! Reboot');stopFS();setLabelTout('ota_label','DONE','IDLE');break;case'ota_url_ok':showPopup('OTA Done!');break;case'ota_url_err':showPopupError('OTA Error!');break;}}
function showControls(controls,from_buffer=false,conn=Conn.NONE,ip='unset'){EL('controls').style.visibility='hidden';EL('controls').innerHTML='';if(!controls)return;oninp_buffer={};gauges={};canvases={};pickers={};joys={};prompts={};confirms={};dup_names=[];files=[];wid_row_count=0;btn_row_count=0;wid_row_id=null;btn_row_id=null;for(ctrl of controls){if(devices[focused].show_names&&ctrl.name)ctrl.label=ctrl.name;ctrl.wlabel=ctrl.label?ctrl.label:ctrl.type;ctrl.clabel=(ctrl.label&&ctrl.label!='_no')?ctrl.label:ctrl.type;ctrl.clabel=ctrl.clabel.charAt(0).toUpperCase()+ctrl.clabel.slice(1);switch(ctrl.type){case'button':addButton(ctrl);break;case'button_i':addButtonIcon(ctrl);break;case'spacer':addSpace(ctrl);break;case'tabs':addTabs(ctrl);break;case'title':addTitle(ctrl);break;case'led':addLED(ctrl);break;case'label':addLabel(ctrl);break;case'icon':addIcon(ctrl);break;case'input':addInput(ctrl);break;case'pass':addPass(ctrl);break;case'slider':addSlider(ctrl);break;case'sliderW':addSliderW(ctrl);break;case'switch':addSwitch(ctrl);break;case'switch_i':addSwitchIcon(ctrl);break;case'switch_t':addSwitchText(ctrl);break;case'date':addDate(ctrl);break;case'time':addTime(ctrl);break;case'datetime':addDateTime(ctrl);break;case'select':addSelect(ctrl);break;case'week':addWeek(ctrl);break;case'color':addColor(ctrl);break;case'spinner':addSpinner(ctrl);break;case'display':addDisplay(ctrl);break;case'html':addHTML(ctrl);break;case'flags':addFlags(ctrl);break;case'log':addLog(ctrl);break;case'row_b':case'widget_b':beginWidgets(ctrl);break;case'row_e':case'widget_e':endWidgets();break;case'canvas':addCanvas(ctrl);break;case'gauge':addGauge(ctrl);break;case'image':addImage(ctrl);break;case'stream':addStream(ctrl,conn,ip);break;case'dpad':case'joy':addJoy(ctrl);break;case'js':eval(ctrl.value);break;case'confirm':confirms[ctrl.name]={label:ctrl.label};break;case'prompt':prompts[ctrl.name]={label:ctrl.label,value:ctrl.value};break;case'menu':addMenu(ctrl);break;case'table':addTable(ctrl);break;}}
if(devices[focused].show_names){let labels=document.querySelectorAll(".widget_label");for(let lbl of labels)lbl.classList.add('widget_label_name');}
resizeFlags();moveSliders();scrollDown();resizeSpinners();renderElms(from_buffer);}
async function renderElms(from_buffer){while(1){await waitAnimationFrame();let end=1;for(let i in gauges)if(EL('#'+i)==null)end=0;for(let i in canvases)if(EL('#'+i)==null)end=0;for(let i in joys)if(EL('#'+i)==null)end=0;for(let i in pickers)if(EL('#'+i)==null)end=0;if(end){if(dup_names.length)showPopupError('Duplicated names: '+dup_names);showCanvases();showGauges();showPickers();showJoys();EL('controls').style.visibility='visible';if(!from_buffer)nextFile();break;}}}
function showInfo(device){function addInfo(el,label,value,title=''){EL(el).innerHTML+=`
<div class="cfg_row info">
<label>${label}</label>
<label title="${title}" class="lbl_info">${value}</label>
</div>`;}
EL('info_version').innerHTML='';EL('info_net').innerHTML='';EL('info_memory').innerHTML='';EL('info_system').innerHTML='';for(let i in device.info.version)addInfo('info_version',i,device.info.version[i]);for(let i in device.info.net)addInfo('info_net',i,device.info.net[i]);for(let i in device.info.memory){if(typeof(device.info.memory[i])=='object'){let used=device.info.memory[i][0];let total=device.info.memory[i][1];let mem=(used/1000).toFixed(1)+' kB';if(total)mem+=' ['+(used/total*100).toFixed(0)+'%]';addInfo('info_memory',i,mem,`Total ${(total / 1000).toFixed(1)} kB`);}else addInfo('info_memory',i,device.info.memory[i]);}
for(let i in device.info.system){if(i=='Uptime'){let sec=device.info.system[i];let upt=Math.floor(sec/86400)+':'+new Date(sec*1000).toISOString().slice(11,19);let d=new Date();let utc=d.getTime()-(d.getTimezoneOffset()*60000);addInfo('info_system',i,upt);addInfo('info_system','Started',new Date(utc-sec*1000).toISOString().split('.')[0].replace('T',' '));continue;}
addInfo('info_system',i,device.info.system[i]);}}
function setLabelTout(el,text1,text2){EL(el).innerHTML=text1;setTimeout(()=>EL(el).innerHTML=text2,3000);}
let screen='main';let deferredPrompt=null;let pin_id=null;let show_version=false;let cfg_changed=false;let menu_f=false;let updates=[];let cfg={use_pin:false,pin:'',ui_width:450,theme:'DARK',maincolor:'GREEN',font:'monospace',version:app_version,check_upd:true,};window.onload=function(){render_main(app_version);EL('title').innerHTML=app_title;let title='GyverHub v'+app_version+' ['+hub.cfg.client_id+'] '+(isPWA()?'PWA ':'')+(isSSL()?'SSL ':'')+(isLocal()?'Local ':'')+(isESP()?'ESP ':'')+(isApp()?'App ':'');EL('title').title=title;load_cfg();load_hcfg();if(isESP())hub.cfg.use_ws=true;update_ip();update_theme();set_drop();key_change();handle_back();register_SW();if(cfg.use_pin)show_keypad(true);else startup();}
function startup(){render_selects();render_info();apply_cfg();update_theme();show_screen('main');load_devices();render_devices();discover();if('Notification'in window&&Notification.permission=='default')Notification.requestPermission();}
function register_SW(){}
function set_drop(){function preventDrop(e){e.preventDefault()
e.stopPropagation()}
['dragenter','dragover','dragleave','drop'].forEach(e=>{document.body.addEventListener(e,preventDrop,false);});['dragenter','dragover'].forEach(e=>{document.body.addEventListener(e,function(){document.querySelectorAll('.drop_area').forEach((el)=>{el.classList.add('active');});},false);});['dragleave','drop'].forEach(e=>{document.body.addEventListener(e,function(){document.querySelectorAll('.drop_area').forEach((el)=>{el.classList.remove('active');});},false);});}
function key_change(){document.addEventListener('keydown',function(e){switch(e.keyCode){case 116:if(!e.ctrlKey){e.preventDefault();refresh_h();}
break;case 192:if(focused){e.preventDefault();toggleCLI();}
break;default:break;}});}
function handle_back(){window.history.pushState({page:1},"","");window.onpopstate=function(e){window.history.pushState({page:1},"","");back_h();}}
function update_ip(){if(isESP()){EL('local_ip').value=window_ip();hub.cfg.local_ip=window_ip();}}
function pass_type(v){pass_inp.value+=v;let hash=pass_inp.value.hashCode();if(pin_id){if(hash==devices[pin_id].PIN){open_device(pin_id);pass_inp.value='';devices_t[pin_id].granted=true;}}else{if(hash==cfg.pin){EL('password').style.display='none';startup();pass_inp.value='';}}}
function check_type(arg){if(arg.value.length>0){let c=arg.value[arg.value.length-1];if(c<'0'||c>'9')arg.value=arg.value.slice(0,-1);}}
function show_keypad(v){if(v){EL('password').style.display='block';EL('pass_inp').focus();}else{EL('password').style.display='none';}}
function render_devices(){EL('devices').innerHTML='';for(let id in devices)addDevice(id);}
function render_info(){const info_labels_topics={info_id:'ID',info_set:'Set',info_read:'Read',info_get:'Get',info_status:'Status',};for(let id in info_labels_topics){EL('info_topics').innerHTML+=`
<div class="cfg_row info">
<label>${info_labels_topics[id]}</label>
<label id="${id}" class="lbl_info info_small">-</label>
</div>`;}}
function update_info(){let id=focused;EL('info_break_sw').checked=devices[id].break_widgets;EL('info_names_sw').checked=devices[id].show_names;EL('info_cli_sw').checked=EL('cli_cont').style.display=='block';EL('info_id').innerHTML=id;EL('info_set').innerHTML=devices[id].prefix+'/'+id+'/set/*';EL('info_read').innerHTML=devices[id].prefix+'/'+id+'/read/*';EL('info_get').innerHTML=devices[id].prefix+'/hub/'+id+'/get/*';EL('info_status').innerHTML=devices[id].prefix+'/hub/'+id+'/status';EL('reboot_btn').style.display=readModule(Modules.REBOOT)?'block':'none';EL('info_version').innerHTML='';EL('info_net').innerHTML='';EL('info_memory').innerHTML='';EL('info_system').innerHTML='';}
function render_selects(){for(let color in colors){EL('maincolor').innerHTML+=`
<option value="${color}">${color}</option>`;}
for(let font of fonts){EL('font').innerHTML+=`
<option value="${font}">${font}</option>`;}
for(let theme in themes){EL('theme').innerHTML+=`
<option value="${theme}">${theme}</option>`;}
let masks=getMaskList();for(let mask in masks){EL('netmask').innerHTML+=`<option value="${mask}">${masks[mask]}</option>`;}}
function test_h(){show_screen('test');}
function projects_h(){EL('projects').innerHTML='';show_screen('projects');loadProjects();}
function refresh_h(){if(screen=='device')post('focus');else if(screen=='info')post('info');else if(screen=='fsbr')post('fsbr');else discover();}
function back_h(){if(EL('fsbr_edit').style.display=='block'){editor_cancel();return;}
stopFS();if(menu_f){menuDeact();menu_show(0);return;}
switch(screen){case'device':release_all();close_device();break;case'info':case'fsbr':menuDeact();showControls(devices_t[focused].controls);show_screen('device');break;case'config':config_h();break;case'pin':case'projects':case'test':show_screen('main');break;}}
function config_h(){if(screen=='config'){if(cfg_changed)save_cfg();cfg_changed=false;show_screen('main');discover();}else{show_screen('config');}}
function menu_show(state){menu_f=state;let cl=EL('menu').classList;if(menu_f)cl.add('menu_show');else cl.remove('menu_show');EL('icon_menu').innerHTML=menu_f?'':'';EL('menu_overlay').style.display=menu_f?'block':'none';}
function menu_h(){menu_show(!menu_f);}
function info_h(){stopFS();menuDeact();menu_show(0);if(readModule(Modules.INFO))post('info');show_screen('info');EL('menu_info').classList.add('menu_act');}
function fsbr_h(){menuDeact();menu_show(0);if(readModule(Modules.FSBR)){post('fsbr');EL('fsbr_inner').innerHTML=waiter();}
EL('fs_browser').style.display=readModule(Modules.FSBR)?'block':'none';EL('fs_upload').style.display=readModule(Modules.UPLOAD)?'block':'none';EL('fs_otaf').style.display=readModule(Modules.OTA)?'block':'none';EL('fs_otaurl').style.display=readModule(Modules.OTA_URL)?'block':'none';EL('fs_format').style.display=readModule(Modules.FORMAT)?'inline-block':'none';EL('fs_update').style.display=readModule(Modules.FSBR)?'inline-block':'none';show_screen('fsbr');EL('menu_fsbr').classList.add('menu_act');}
function device_h(id){if(discovering)return;if(!(id in devices_t)||devices_t[id].conn==Conn.NONE){return;}
if(!devices[id])return;if(devices[id].PIN&&!devices_t[id].granted){pin_id=id;show_screen('pin');}else open_device(id);}
function open_device(id){focused=id;switch(devices_t[id].conn){case Conn.SERIAL:post('focus');break;case Conn.BT:post('focus');break;case Conn.WS:refreshSpin(true);ws_start(id);ws_focus_flag=true;break;case Conn.MQTT:post('focus');break;}
log('Open device #'+id+' via '+ConnNames[devices_t[id].conn]);EL('menu_user').innerHTML='';showControls(devices_t[id].controls,true);show_screen('device');reset_ping();}
function close_device(){showErr(false);switch(devices_t[focused].conn){case Conn.SERIAL:post('unfocus');break;case Conn.BT:post('unfocus');break;case Conn.WS:ws_stop(focused);refreshSpin(false);break;case Conn.MQTT:post('unfocus');break;}
log('Close device #'+focused);focused=null;show_screen('main');stop_ping();stop_tout();}
function clear_all(){EL('devices').innerHTML="";devices={};devices_t={};save_devices();show_screen('main');}
function show_screen(nscreen){stopFS();screen=nscreen;show_keypad(false);let footer_s=EL('footer_cont').style;let conns_s=EL('conn_icons').style;let proj_s=EL('projects_cont').style;let test_s=EL('test_cont').style;let main_s=EL('main_cont').style;let config_s=EL('config').style;let devices_s=EL('devices').style;let controls_s=EL('controls').style;let info_s=EL('info').style;let fsbr_s=EL('fsbr').style;let icon_cfg_s=EL('icon_cfg').style;let icon_menu_s=EL('icon_menu').style;let icon_refresh_s=EL('icon_refresh').style;let back_s=EL('back').style;let version_s=EL('version').style;let title_row_s=EL('title_row').style;conns_s.display='none';main_s.display='block';test_s.display='none';proj_s.display='none';config_s.display='none';devices_s.display='none';controls_s.display='none';info_s.display='none';icon_menu_s.display='none';icon_cfg_s.display='none';fsbr_s.display='none';back_s.display='none';icon_refresh_s.display='none';version_s.display='none';title_row_s.cursor='pointer';footer_s.display='none';EL('title').innerHTML=app_title;if(screen=='main'){conns_s.display='flex';version_s.display='unset';devices_s.display='grid';icon_cfg_s.display='inline-block';icon_refresh_s.display='inline-block';title_row_s.cursor='unset';footer_s.display='block';EL('conn').innerHTML='';showCLI(false);}else if(screen=='test'){main_s.display='none';test_s.display='block';back_s.display='inline-block';EL('title').innerHTML='UI Test';}else if(screen=='projects'){main_s.display='none';proj_s.display='block';back_s.display='inline-block';EL('title').innerHTML='Projects';}else if(screen=='device'){controls_s.display='block';icon_menu_s.display='inline-block';back_s.display='inline-block';icon_refresh_s.display='inline-block';EL('title').innerHTML=devices[focused].name;}else if(screen=='config'){conns_s.display='flex';config_s.display='block';icon_cfg_s.display='inline-block';back_s.display='inline-block';EL('title').innerHTML='Config';}else if(screen=='info'){info_s.display='block';icon_menu_s.display='inline-block';back_s.display='inline-block';EL('title').innerHTML=devices[focused].name+'/info';update_info();}else if(screen=='fsbr'){fsbr_s.display='block';icon_menu_s.display='inline-block';back_s.display='inline-block';EL('title').innerHTML=devices[focused].name+'/fs';}else if(screen=='pin'){back_s.display='inline-block';show_keypad(true);}}
function delete_h(id){if(confirm('Delete '+id+'?')){document.getElementById("device#"+id).remove();delete devices[id];save_devices();return 1;}
return 0;}
function printCLI(text,color){if(EL('cli_cont').style.display=='block'){if(EL('cli').innerHTML)EL('cli').innerHTML+='\n';let st=color?`style="color:${intToCol(color)}"`:'';EL('cli').innerHTML+=`><span ${st}">${text}</span>`;EL('cli').scrollTop=EL('cli').scrollHeight;}}
function toggleCLI(){EL('cli').innerHTML="";EL('cli_input').value="";showCLI(!(EL('cli_cont').style.display=='block'));}
function showCLI(v){EL('bottom_space').style.height=v?'170px':'50px';EL('cli_cont').style.display=v?'block':'none';if(v)EL('cli_input').focus();EL('info_cli_sw').checked=v;}
function checkCLI(){if(event.key=='Enter')sendCLI();}
function sendCLI(){post('cli','cli',EL('cli_input').value);EL('cli_input').value="";}
function sendDiscover(){if(hub.cfg.use_ws&&!isSSL())ws_discover();}
function discover(){if(isESP()){let has=false;for(let id in devices){if(window.location.href.includes(devices[id].ip))has=true;}
if(!has&&checkIP(window_ip()))ws_discover_ip(window_ip());}
for(let id in devices){if(id in devices_t)devices_t[id].conn=Conn.NONE;EL(`device#${id}`).className="device offline";EL(`Serial#${id}`).style.display='none';EL(`BT#${id}`).style.display='none';EL(`WS#${id}`).style.display='none';EL(`MQTT#${id}`).style.display='none';}
sendDiscover();}
function discover_all(){if(hub.cfg.use_ws&&!isSSL())ws_discover_all();back_h();}
function update_cfg(el){if(el.type=='text')el.value=el.value.trim();let val=(el.type=='checkbox')?el.checked:el.value;if(el.id in cfg)cfg[el.id]=val;else if(el.id in hub.cfg)hub.cfg[el.id]=val;cfg_changed=true;update_theme();}
function save_cfg(){localStorage.setItem('config',JSON.stringify(cfg));localStorage.setItem('hub_config',JSON.stringify(hub.cfg));}
function load_cfg(){if(localStorage.hasOwnProperty('config')){let cfg_r=JSON.parse(localStorage.getItem('config'));if(cfg_r.version!=cfg.version){cfg_r.version=cfg.version;show_version=true;}
if(Object.keys(cfg).length==Object.keys(cfg_r).length){cfg=cfg_r;if(!show_version)return;}}
localStorage.setItem('config',JSON.stringify(cfg));}
function load_hcfg(){if(localStorage.hasOwnProperty('hub_config')){let cfg_r=JSON.parse(localStorage.getItem('hub_config'));if(Object.keys(hub.cfg).length==Object.keys(cfg_r).length){hub.cfg=cfg_r;return;}}
localStorage.setItem('hub_config',JSON.stringify(hub.cfg));}
function apply_cfg(){for(let key in cfg){if(key=='version')continue;let el=EL(key);if(el==undefined)continue;if(el.type=='checkbox')el.checked=cfg[key];else el.value=cfg[key];}
for(let key in hub.cfg){let el=EL(key);if(el==undefined)continue;if(el.type=='checkbox')el.checked=hub.cfg[key];else el.value=hub.cfg[key];}}
async function cfg_export(){try{const text=btoa(JSON.stringify(cfg))+';'+btoa(JSON.stringify(hub.cfg))+';'+btoa(encodeURIComponent(JSON.stringify(devices)));await navigator.clipboard.writeText(text);showPopup('Copied to clipboard');}catch(e){showPopupError('Export error');}}
async function cfg_import(){try{let text=await navigator.clipboard.readText();text=text.split(';');try{cfg=JSON.parse(atob(text[0]));}catch(e){}
try{hub.cfg=JSON.parse(atob(text[1]));}catch(e){}
try{devices=JSON.parse(decodeURIComponent(atob(text[2])));}catch(e){}
save_cfg();save_devices();showPopup('Import done');setTimeout(()=>location.reload(),1500);}catch(e){showPopupError('Wrong data');}}
function update_theme(){let v=themes[cfg.theme];let r=document.querySelector(':root');r.style.setProperty('--back',theme_cols[v][0]);r.style.setProperty('--tab',theme_cols[v][1]);r.style.setProperty('--font',theme_cols[v][2]);r.style.setProperty('--font2',theme_cols[v][3]);r.style.setProperty('--dark',theme_cols[v][4]);r.style.setProperty('--thumb',theme_cols[v][5]);r.style.setProperty('--black',theme_cols[v][6]);r.style.setProperty('--scheme',theme_cols[v][7]);r.style.setProperty('--font_inv',theme_cols[v][8]);r.style.setProperty('--shad',theme_cols[v][9]);r.style.setProperty('--ui_width',cfg.ui_width+'px');r.style.setProperty('--prim',intToCol(colors[cfg.maincolor]));r.style.setProperty('--font_f',cfg.font);let b='block';let n='none';let f='var(--font)';let f3='var(--font3)';EL('ws_block').style.display=hub.cfg.use_ws?b:n;EL('ws_label').style.color=hub.cfg.use_ws?f:f3;EL('pin_block').style.display=cfg.use_pin?b:n;EL('pin_label').style.color=cfg.use_pin?f:f3;}
(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";window.sortPaths=require("./sort-paths.js");
},{"./sort-paths.js":3}],2:[function(require,module,exports){
"use strict";function splitRetain(e,t,r){if(r=defaults(r,{}),r.leadingSeparator=defaults(r.leadingSeparator,!1),assert.type(e,"string","`string` is not a string"),assert("string"==typeof t||t instanceof RegExp,"invalid `separator` type"),assert.type(r,"object","invalid `options` type"),assert.type(r.leadingSeparator,"boolean","invalid `options.leadingSeparator` type"),0===e.length)return[""];t=separatorToRegex(t);var n=e.split(t);if(1===n.length)return n;var s=[];for(r.leadingSeparator&&s.push(n.shift());n.length>0;)1===n.length?s.push(n.shift()):s.push(n.shift()+n.shift());return""===s[0]&&s.shift(),""===s[s.length-1]&&s.pop(),s}function separatorToRegex(e){return e instanceof RegExp?e:new RegExp("("+escapeRegex(e)+")","g")}function escapeRegex(e){return e.replace(/[-[\]{}()*+?.,\\^$|#\s]/g,"\\$&")}function assert(e,t){if(!e)throw new Error(t)}function defaults(e,t){return void 0===e?t:e}exports=module.exports=splitRetain,splitRetain.VERSION="1.0.1",assert.type=function(e,t,r){if(typeof e!==t)throw new Error(r)};
},{}],3:[function(require,module,exports){
"use strict";function sortPaths(t){assert(arguments.length>=2,"too few arguments"),assert(arguments.length<=3,"too many arguments");var r,e;2===arguments.length?(r=identity,e=arguments[1]):(r=arguments[1],e=arguments[2]),assert(isArray(t),"items is not an array"),assert(isFunction(r),"iteratee is not a function"),assert("string"==typeof e,"dirSeparator is not a String"),assert(1===e.length,"dirSeparator must be a single character");var n=t.map(function(t){var n=r(t);return assert("string"==typeof n,"item or iteratee(item) must be a String"),{item:t,pathTokens:splitRetain(n,e)}});return n.sort(createItemDTOComparator(e)),n.map(function(t){return t.item})}function createItemDTOComparator(t){return function(r,e){for(var n=r.pathTokens,a=e.pathTokens,o=0,i=Math.max(n.length,a.length);o<i;o++){if(!(o in n))return-1;if(!(o in a))return 1;var s=n[o].toLowerCase(),u=a[o].toLowerCase();if(s!==u){var c=s[s.length-1]===t;return c===(u[u.length-1]===t)?s<u?-1:1:c?1:-1}}return 0}}function assert(t,r){if(!t)throw new Error(r)}function identity(t){return t}function isFunction(t){return Boolean(t)&&"[object Function]"===Object.prototype.toString.call(t)}function isArray(t){return Boolean(t)&&"[object Array]"===Object.prototype.toString.call(t)}var splitRetain=require("split-retain");module.exports=sortPaths,sortPaths.VERSION="1.1.1";
},{"split-retain":2}]},{},[1]);
!function(t,e){"object"==typeof exports&&"object"==typeof module?module.exports=e():"function"==typeof define&&define.amd?define([],e):"object"==typeof exports?exports.Pickr=e():t.Pickr=e()}(self,(function(){return(()=>{"use strict";var t={d:(e,o)=>{for(var n in o)t.o(o,n)&&!t.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:o[n]})},o:(t,e)=>Object.prototype.hasOwnProperty.call(t,e),r:t=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})}},e={};t.d(e,{default:()=>L});var o={};function n(t,e,o,n,i={}){e instanceof HTMLCollection||e instanceof NodeList?e=Array.from(e):Array.isArray(e)||(e=[e]),Array.isArray(o)||(o=[o]);for(const s of e)for(const e of o)s[t](e,n,{capture:!1,...i});return Array.prototype.slice.call(arguments,1)}t.r(o),t.d(o,{adjustableInputNumbers:()=>p,createElementFromString:()=>r,createFromTemplate:()=>a,eventPath:()=>l,off:()=>s,on:()=>i,resolveElement:()=>c});const i=n.bind(null,"addEventListener"),s=n.bind(null,"removeEventListener");function r(t){const e=document.createElement("div");return e.innerHTML=t.trim(),e.firstElementChild}function a(t){const e=(t,e)=>{const o=t.getAttribute(e);return t.removeAttribute(e),o},o=(t,n={})=>{const i=e(t,":obj"),s=e(t,":ref"),r=i?n[i]={}:n;s&&(n[s]=t);for(const n of Array.from(t.children)){const t=e(n,":arr"),i=o(n,t?{}:r);t&&(r[t]||(r[t]=[])).push(Object.keys(i).length?i:n)}return n};return o(r(t))}function l(t){let e=t.path||t.composedPath&&t.composedPath();if(e)return e;let o=t.target.parentElement;for(e=[t.target,o];o=o.parentElement;)e.push(o);return e.push(document,window),e}function c(t){return t instanceof Element?t:"string"==typeof t?t.split(/>>/g).reduce(((t,e,o,n)=>(t=t.querySelector(e),o<n.length-1?t.shadowRoot:t)),document):null}function p(t,e=(t=>t)){function o(o){const n=[.001,.01,.1][Number(o.shiftKey||2*o.ctrlKey)]*(o.deltaY<0?1:-1);let i=0,s=t.selectionStart;t.value=t.value.replace(/[\d.]+/g,((t,o)=>o<=s&&o+t.length>=s?(s=o,e(Number(t),n,i)):(i++,t))),t.focus(),t.setSelectionRange(s,s),o.preventDefault(),t.dispatchEvent(new Event("input"))}i(t,"focus",(()=>i(window,"wheel",o,{passive:!1}))),i(t,"blur",(()=>s(window,"wheel",o)))}const{min:u,max:h,floor:d,round:m}=Math;function f(t,e,o){e/=100,o/=100;const n=d(t=t/360*6),i=t-n,s=o*(1-e),r=o*(1-i*e),a=o*(1-(1-i)*e),l=n%6;return[255*[o,r,s,s,a,o][l],255*[a,o,o,r,s,s][l],255*[s,s,a,o,o,r][l]]}function v(t,e,o){const n=(2-(e/=100))*(o/=100)/2;return 0!==n&&(e=1===n?0:n<.5?e*o/(2*n):e*o/(2-2*n)),[t,100*e,100*n]}function b(t,e,o){const n=u(t/=255,e/=255,o/=255),i=h(t,e,o),s=i-n;let r,a;if(0===s)r=a=0;else{a=s/i;const n=((i-t)/6+s/2)/s,l=((i-e)/6+s/2)/s,c=((i-o)/6+s/2)/s;t===i?r=c-l:e===i?r=1/3+n-c:o===i&&(r=2/3+l-n),r<0?r+=1:r>1&&(r-=1)}return[360*r,100*a,100*i]}function y(t,e,o,n){e/=100,o/=100;return[...b(255*(1-u(1,(t/=100)*(1-(n/=100))+n)),255*(1-u(1,e*(1-n)+n)),255*(1-u(1,o*(1-n)+n)))]}function g(t,e,o){e/=100;const n=2*(e*=(o/=100)<.5?o:1-o)/(o+e)*100,i=100*(o+e);return[t,isNaN(n)?0:n,i]}function _(t){return b(...t.match(/.{2}/g).map((t=>parseInt(t,16))))}function w(t){t=t.match(/^[a-zA-Z]+$/)?function(t){if("black"===t.toLowerCase())return"#000";const e=document.createElement("canvas").getContext("2d");return e.fillStyle=t,"#000"===e.fillStyle?null:e.fillStyle}(t):t;const e={cmyk:/^cmyk[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)/i,rgba:/^((rgba)|rgb)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,hsla:/^((hsla)|hsl)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,hsva:/^((hsva)|hsv)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,hexa:/^#?(([\dA-Fa-f]{3,4})|([\dA-Fa-f]{6})|([\dA-Fa-f]{8}))$/i},o=t=>t.map((t=>/^(|\d+)\.\d+|\d+$/.test(t)?Number(t):void 0));let n;t:for(const i in e){if(!(n=e[i].exec(t)))continue;const s=t=>!!n[2]==("number"==typeof t);switch(i){case"cmyk":{const[,t,e,s,r]=o(n);if(t>100||e>100||s>100||r>100)break t;return{values:y(t,e,s,r),type:i}}case"rgba":{const[,,,t,e,r,a]=o(n);if(t>255||e>255||r>255||a<0||a>1||!s(a))break t;return{values:[...b(t,e,r),a],a,type:i}}case"hexa":{let[,t]=n;4!==t.length&&3!==t.length||(t=t.split("").map((t=>t+t)).join(""));const e=t.substring(0,6);let o=t.substring(6);return o=o?parseInt(o,16)/255:void 0,{values:[..._(e),o],a:o,type:i}}case"hsla":{const[,,,t,e,r,a]=o(n);if(t>360||e>100||r>100||a<0||a>1||!s(a))break t;return{values:[...g(t,e,r),a],a,type:i}}case"hsva":{const[,,,t,e,r,a]=o(n);if(t>360||e>100||r>100||a<0||a>1||!s(a))break t;return{values:[t,e,r,a],a,type:i}}}}return{values:null,type:null}}function A(t=0,e=0,o=0,n=1){const i=(t,e)=>(o=-1)=>e(~o?t.map((t=>Number(t.toFixed(o)))):t),s={h:t,s:e,v:o,a:n,toHSVA(){const t=[s.h,s.s,s.v,s.a];return t.toString=i(t,(t=>`hsva(${t[0]}, ${t[1]}%, ${t[2]}%, ${s.a})`)),t},toHSLA(){const t=[...v(s.h,s.s,s.v),s.a];return t.toString=i(t,(t=>`hsla(${t[0]}, ${t[1]}%, ${t[2]}%, ${s.a})`)),t},toRGBA(){const t=[...f(s.h,s.s,s.v),s.a];return t.toString=i(t,(t=>`rgba(${t[0]}, ${t[1]}, ${t[2]}, ${s.a})`)),t},toCMYK(){const t=function(t,e,o){const n=f(t,e,o),i=n[0]/255,s=n[1]/255,r=n[2]/255,a=u(1-i,1-s,1-r);return[100*(1===a?0:(1-i-a)/(1-a)),100*(1===a?0:(1-s-a)/(1-a)),100*(1===a?0:(1-r-a)/(1-a)),100*a]}(s.h,s.s,s.v);return t.toString=i(t,(t=>`cmyk(${t[0]}%, ${t[1]}%, ${t[2]}%, ${t[3]}%)`)),t},toHEXA(){const t=function(t,e,o){return f(t,e,o).map((t=>m(t).toString(16).padStart(2,"0")))}(s.h,s.s,s.v),e=s.a>=1?"":Number((255*s.a).toFixed(0)).toString(16).toUpperCase().padStart(2,"0");return e&&t.push(e),t.toString=()=>`#${t.join("").toUpperCase()}`,t},clone:()=>A(s.h,s.s,s.v,s.a)};return s}const C=t=>Math.max(Math.min(t,1),0);function $(t){const e={options:Object.assign({lock:null,onchange:()=>0,onstop:()=>0},t),_keyboard(t){const{options:o}=e,{type:n,key:i}=t;if(document.activeElement===o.wrapper){const{lock:o}=e.options,s="ArrowUp"===i,r="ArrowRight"===i,a="ArrowDown"===i,l="ArrowLeft"===i;if("keydown"===n&&(s||r||a||l)){let n=0,i=0;"v"===o?n=s||r?1:-1:"h"===o?n=s||r?-1:1:(i=s?-1:a?1:0,n=l?-1:r?1:0),e.update(C(e.cache.x+.01*n),C(e.cache.y+.01*i)),t.preventDefault()}else i.startsWith("Arrow")&&(e.options.onstop(),t.preventDefault())}},_tapstart(t){i(document,["mouseup","touchend","touchcancel"],e._tapstop),i(document,["mousemove","touchmove"],e._tapmove),t.cancelable&&t.preventDefault(),e._tapmove(t)},_tapmove(t){const{options:o,cache:n}=e,{lock:i,element:s,wrapper:r}=o,a=r.getBoundingClientRect();let l=0,c=0;if(t){const e=t&&t.touches&&t.touches[0];l=t?(e||t).clientX:0,c=t?(e||t).clientY:0,l<a.left?l=a.left:l>a.left+a.width&&(l=a.left+a.width),c<a.top?c=a.top:c>a.top+a.height&&(c=a.top+a.height),l-=a.left,c-=a.top}else n&&(l=n.x*a.width,c=n.y*a.height);"h"!==i&&(s.style.left=`calc(${l/a.width*100}% - ${s.offsetWidth/2}px)`),"v"!==i&&(s.style.top=`calc(${c/a.height*100}% - ${s.offsetHeight/2}px)`),e.cache={x:l/a.width,y:c/a.height};const p=C(l/a.width),u=C(c/a.height);switch(i){case"v":return o.onchange(p);case"h":return o.onchange(u);default:return o.onchange(p,u)}},_tapstop(){e.options.onstop(),s(document,["mouseup","touchend","touchcancel"],e._tapstop),s(document,["mousemove","touchmove"],e._tapmove)},trigger(){e._tapmove()},update(t=0,o=0){const{left:n,top:i,width:s,height:r}=e.options.wrapper.getBoundingClientRect();"h"===e.options.lock&&(o=t),e._tapmove({clientX:n+s*t,clientY:i+r*o})},destroy(){const{options:t,_tapstart:o,_keyboard:n}=e;s(document,["keydown","keyup"],n),s([t.wrapper,t.element],"mousedown",o),s([t.wrapper,t.element],"touchstart",o,{passive:!1})}},{options:o,_tapstart:n,_keyboard:r}=e;return i([o.wrapper,o.element],"mousedown",n),i([o.wrapper,o.element],"touchstart",n,{passive:!1}),i(document,["keydown","keyup"],r),e}function k(t={}){t=Object.assign({onchange:()=>0,className:"",elements:[]},t);const e=i(t.elements,"click",(e=>{t.elements.forEach((o=>o.classList[e.target===o?"add":"remove"](t.className))),t.onchange(e),e.stopPropagation()}));return{destroy:()=>s(...e)}}const S={variantFlipOrder:{start:"sme",middle:"mse",end:"ems"},positionFlipOrder:{top:"tbrl",right:"rltb",bottom:"btrl",left:"lrbt"},position:"bottom",margin:8},O=(t,e,o)=>{const{container:n,margin:i,position:s,variantFlipOrder:r,positionFlipOrder:a}={container:document.documentElement.getBoundingClientRect(),...S,...o},{left:l,top:c}=e.style;e.style.left="0",e.style.top="0";const p=t.getBoundingClientRect(),u=e.getBoundingClientRect(),h={t:p.top-u.height-i,b:p.bottom+i,r:p.right+i,l:p.left-u.width-i},d={vs:p.left,vm:p.left+p.width/2+-u.width/2,ve:p.left+p.width-u.width,hs:p.top,hm:p.bottom-p.height/2-u.height/2,he:p.bottom-u.height},[m,f="middle"]=s.split("-"),v=a[m],b=r[f],{top:y,left:g,bottom:_,right:w}=n;for(const t of v){const o="t"===t||"b"===t,n=h[t],[i,s]=o?["top","left"]:["left","top"],[r,a]=o?[u.height,u.width]:[u.width,u.height],[l,c]=o?[_,w]:[w,_],[p,m]=o?[y,g]:[g,y];if(!(n<p||n+r>l))for(const r of b){const l=d[(o?"v":"h")+r];if(!(l<m||l+a>c))return e.style[s]=l-u[s]+"px",e.style[i]=n-u[i]+"px",t+r}}return e.style.left=l,e.style.top=c,null};function E(t,e,o){return e in t?Object.defineProperty(t,e,{value:o,enumerable:!0,configurable:!0,writable:!0}):t[e]=o,t}class L{constructor(t){E(this,"_initializingActive",!0),E(this,"_recalc",!0),E(this,"_nanopop",null),E(this,"_root",null),E(this,"_color",A()),E(this,"_lastColor",A()),E(this,"_swatchColors",[]),E(this,"_setupAnimationFrame",null),E(this,"_eventListener",{init:[],save:[],hide:[],show:[],clear:[],change:[],changestop:[],cancel:[],swatchselect:[]}),this.options=t=Object.assign({...L.DEFAULT_OPTIONS},t);const{swatches:e,components:o,theme:n,sliders:i,lockOpacity:s,padding:r}=t;["nano","monolith"].includes(n)&&!i&&(t.sliders="h"),o.interaction||(o.interaction={});const{preview:a,opacity:l,hue:c,palette:p}=o;o.opacity=!s&&l,o.palette=p||a||l||c,this._preBuild(),this._buildComponents(),this._bindEvents(),this._finalBuild(),e&&e.length&&e.forEach((t=>this.addSwatch(t)));const{button:u,app:h}=this._root;this._nanopop=((t,e,o)=>{const n="object"!=typeof t||t instanceof HTMLElement?{reference:t,popper:e,...o}:t;return{update(t=n){const{reference:e,popper:o}=Object.assign(n,t);if(!o||!e)throw new Error("Popper- or reference-element missing.");return O(e,o,n)}}})(u,h,{margin:r}),u.setAttribute("role","button"),u.setAttribute("aria-label",this._t("btn:toggle"));const d=this;this._setupAnimationFrame=requestAnimationFrame((function e(){if(!h.offsetWidth)return requestAnimationFrame(e);d.setColor(t.default),d._rePositioningPicker(),t.defaultRepresentation&&(d._representation=t.defaultRepresentation,d.setColorRepresentation(d._representation)),t.showAlways&&d.show(),d._initializingActive=!1,d._emit("init")}))}_preBuild(){const{options:t}=this;for(const e of["el","container"])t[e]=c(t[e]);this._root=(t=>{const{components:e,useAsButton:o,inline:n,appClass:i,theme:s,lockOpacity:r}=t.options,l=t=>t?"":'style="display:none" hidden',c=e=>t._t(e),p=a(`\n      <div :ref="root" class="pickr">\n\n        ${o?"":'<button type="button" :ref="button" class="pcr-button"></button>'}\n\n        <div :ref="app" class="pcr-app ${i||""}" data-theme="${s}" ${n?'style="position: unset"':""} aria-label="${c("ui:dialog")}" role="window">\n          <div class="pcr-selection" ${l(e.palette)}>\n            <div :obj="preview" class="pcr-color-preview" ${l(e.preview)}>\n              <button type="button" :ref="lastColor" class="pcr-last-color" aria-label="${c("btn:last-color")}"></button>\n              <div :ref="currentColor" class="pcr-current-color"></div>\n            </div>\n\n            <div :obj="palette" class="pcr-color-palette">\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="palette" class="pcr-palette" tabindex="0" aria-label="${c("aria:palette")}" role="listbox"></div>\n            </div>\n\n            <div :obj="hue" class="pcr-color-chooser" ${l(e.hue)}>\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="slider" class="pcr-hue pcr-slider" tabindex="0" aria-label="${c("aria:hue")}" role="slider"></div>\n            </div>\n\n            <div :obj="opacity" class="pcr-color-opacity" ${l(e.opacity)}>\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="slider" class="pcr-opacity pcr-slider" tabindex="0" aria-label="${c("aria:opacity")}" role="slider"></div>\n            </div>\n          </div>\n\n          <div class="pcr-swatches ${e.palette?"":"pcr-last"}" :ref="swatches"></div>\n\n          <div :obj="interaction" class="pcr-interaction" ${l(Object.keys(e.interaction).length)}>\n            <input :ref="result" class="pcr-result" type="text" spellcheck="false" ${l(e.interaction.input)} aria-label="${c("aria:input")}">\n\n            <input :arr="options" class="pcr-type" data-type="HEXA" value="${r?"HEX":"HEXA"}" type="button" ${l(e.interaction.hex)}>\n            <input :arr="options" class="pcr-type" data-type="RGBA" value="${r?"RGB":"RGBA"}" type="button" ${l(e.interaction.rgba)}>\n            <input :arr="options" class="pcr-type" data-type="HSLA" value="${r?"HSL":"HSLA"}" type="button" ${l(e.interaction.hsla)}>\n            <input :arr="options" class="pcr-type" data-type="HSVA" value="${r?"HSV":"HSVA"}" type="button" ${l(e.interaction.hsva)}>\n            <input :arr="options" class="pcr-type" data-type="CMYK" value="CMYK" type="button" ${l(e.interaction.cmyk)}>\n\n            <input :ref="save" class="pcr-save" value="${c("btn:save")}" type="button" ${l(e.interaction.save)} aria-label="${c("aria:btn:save")}">\n            <input :ref="cancel" class="pcr-cancel" value="${c("btn:cancel")}" type="button" ${l(e.interaction.cancel)} aria-label="${c("aria:btn:cancel")}">\n            <input :ref="clear" class="pcr-clear" value="${c("btn:clear")}" type="button" ${l(e.interaction.clear)} aria-label="${c("aria:btn:clear")}">\n          </div>\n        </div>\n      </div>\n    `),u=p.interaction;return u.options.find((t=>!t.hidden&&!t.classList.add("active"))),u.type=()=>u.options.find((t=>t.classList.contains("active"))),p})(this),t.useAsButton&&(this._root.button=t.el),t.container.appendChild(this._root.root)}_finalBuild(){const t=this.options,e=this._root;if(t.container.removeChild(e.root),t.inline){const o=t.el.parentElement;t.el.nextSibling?o.insertBefore(e.app,t.el.nextSibling):o.appendChild(e.app)}else t.container.appendChild(e.app);t.useAsButton?t.inline&&t.el.remove():t.el.parentNode.replaceChild(e.root,t.el),t.disabled&&this.disable(),t.comparison||(e.button.style.transition="none",t.useAsButton||(e.preview.lastColor.style.transition="none")),this.hide()}_buildComponents(){const t=this,e=this.options.components,o=(t.options.sliders||"v").repeat(2),[n,i]=o.match(/^[vh]+$/g)?o:[],s=()=>this._color||(this._color=this._lastColor.clone()),r={palette:$({element:t._root.palette.picker,wrapper:t._root.palette.palette,onstop:()=>t._emit("changestop","slider",t),onchange(o,n){if(!e.palette)return;const i=s(),{_root:r,options:a}=t,{lastColor:l,currentColor:c}=r.preview;t._recalc&&(i.s=100*o,i.v=100-100*n,i.v<0&&(i.v=0),t._updateOutput("slider"));const p=i.toRGBA().toString(0);this.element.style.background=p,this.wrapper.style.background=`\n                        linear-gradient(to top, rgba(0, 0, 0, ${i.a}), transparent),\n                        linear-gradient(to left, hsla(${i.h}, 100%, 50%, ${i.a}), rgba(255, 255, 255, ${i.a}))\n                    `,a.comparison?a.useAsButton||t._lastColor||l.style.setProperty("--pcr-color",p):(r.button.style.setProperty("--pcr-color",p),r.button.classList.remove("clear"));const u=i.toHEXA().toString();for(const{el:e,color:o}of t._swatchColors)e.classList[u===o.toHEXA().toString()?"add":"remove"]("pcr-active");c.style.setProperty("--pcr-color",p)}}),hue:$({lock:"v"===i?"h":"v",element:t._root.hue.picker,wrapper:t._root.hue.slider,onstop:()=>t._emit("changestop","slider",t),onchange(o){if(!e.hue||!e.palette)return;const n=s();t._recalc&&(n.h=360*o),this.element.style.backgroundColor=`hsl(${n.h}, 100%, 50%)`,r.palette.trigger()}}),opacity:$({lock:"v"===n?"h":"v",element:t._root.opacity.picker,wrapper:t._root.opacity.slider,onstop:()=>t._emit("changestop","slider",t),onchange(o){if(!e.opacity||!e.palette)return;const n=s();t._recalc&&(n.a=Math.round(100*o)/100),this.element.style.background=`rgba(0, 0, 0, ${n.a})`,r.palette.trigger()}}),selectable:k({elements:t._root.interaction.options,className:"active",onchange(e){t._representation=e.target.getAttribute("data-type").toUpperCase(),t._recalc&&t._updateOutput("swatch")}})};this._components=r}_bindEvents(){const{_root:t,options:e}=this,o=[i(t.interaction.clear,"click",(()=>this._clearColor())),i([t.interaction.cancel,t.preview.lastColor],"click",(()=>{this.setHSVA(...(this._lastColor||this._color).toHSVA(),!0),this._emit("cancel")})),i(t.interaction.save,"click",(()=>{!this.applyColor()&&!e.showAlways&&this.hide()})),i(t.interaction.result,["keyup","input"],(t=>{this.setColor(t.target.value,!0)&&!this._initializingActive&&(this._emit("change",this._color,"input",this),this._emit("changestop","input",this)),t.stopImmediatePropagation()})),i(t.interaction.result,["focus","blur"],(t=>{this._recalc="blur"===t.type,this._recalc&&this._updateOutput(null)})),i([t.palette.palette,t.palette.picker,t.hue.slider,t.hue.picker,t.opacity.slider,t.opacity.picker],["mousedown","touchstart"],(()=>this._recalc=!0),{passive:!0})];if(!e.showAlways){const n=e.closeWithKey;o.push(i(t.button,"click",(()=>this.isOpen()?this.hide():this.show())),i(document,"keyup",(t=>this.isOpen()&&(t.key===n||t.code===n)&&this.hide())),i(document,["touchstart","mousedown"],(e=>{this.isOpen()&&!l(e).some((e=>e===t.app||e===t.button))&&this.hide()}),{capture:!0}))}if(e.adjustableNumbers){const e={rgba:[255,255,255,1],hsva:[360,100,100,1],hsla:[360,100,100,1],cmyk:[100,100,100,100]};p(t.interaction.result,((t,o,n)=>{const i=e[this.getColorRepresentation().toLowerCase()];if(i){const e=i[n],s=t+(e>=100?1e3*o:o);return s<=0?0:Number((s<e?s:e).toPrecision(3))}return t}))}if(e.autoReposition&&!e.inline){let t=null;const n=this;o.push(i(window,["scroll","resize"],(()=>{n.isOpen()&&(e.closeOnScroll&&n.hide(),null===t?(t=setTimeout((()=>t=null),100),requestAnimationFrame((function e(){n._rePositioningPicker(),null!==t&&requestAnimationFrame(e)}))):(clearTimeout(t),t=setTimeout((()=>t=null),100)))}),{capture:!0}))}this._eventBindings=o}_rePositioningPicker(){const{options:t}=this;if(!t.inline){if(!this._nanopop.update({container:document.body.getBoundingClientRect(),position:t.position})){const t=this._root.app,e=t.getBoundingClientRect();t.style.top=(window.innerHeight-e.height)/2+"px",t.style.left=(window.innerWidth-e.width)/2+"px"}}}_updateOutput(t){const{_root:e,_color:o,options:n}=this;if(e.interaction.type()){const t=`to${e.interaction.type().getAttribute("data-type")}`;e.interaction.result.value="function"==typeof o[t]?o[t]().toString(n.outputPrecision):""}!this._initializingActive&&this._recalc&&this._emit("change",o,t,this)}_clearColor(t=!1){const{_root:e,options:o}=this;o.useAsButton||e.button.style.setProperty("--pcr-color","rgba(0, 0, 0, 0.15)"),e.button.classList.add("clear"),o.showAlways||this.hide(),this._lastColor=null,this._initializingActive||t||(this._emit("save",null),this._emit("clear"))}_parseLocalColor(t){const{values:e,type:o,a:n}=w(t),{lockOpacity:i}=this.options,s=void 0!==n&&1!==n;return e&&3===e.length&&(e[3]=void 0),{values:!e||i&&s?null:e,type:o}}_t(t){return this.options.i18n[t]||L.I18N_DEFAULTS[t]}_emit(t,...e){this._eventListener[t].forEach((t=>t(...e,this)))}on(t,e){return this._eventListener[t].push(e),this}off(t,e){const o=this._eventListener[t]||[],n=o.indexOf(e);return~n&&o.splice(n,1),this}addSwatch(t){const{values:e}=this._parseLocalColor(t);if(e){const{_swatchColors:t,_root:o}=this,n=A(...e),s=r(`<button type="button" style="--pcr-color: ${n.toRGBA().toString(0)}" aria-label="${this._t("btn:swatch")}"/>`);return o.swatches.appendChild(s),t.push({el:s,color:n}),this._eventBindings.push(i(s,"click",(()=>{this.setHSVA(...n.toHSVA(),!0),this._emit("swatchselect",n),this._emit("change",n,"swatch",this)}))),!0}return!1}removeSwatch(t){const e=this._swatchColors[t];if(e){const{el:o}=e;return this._root.swatches.removeChild(o),this._swatchColors.splice(t,1),!0}return!1}applyColor(t=!1){const{preview:e,button:o}=this._root,n=this._color.toRGBA().toString(0);return e.lastColor.style.setProperty("--pcr-color",n),this.options.useAsButton||o.style.setProperty("--pcr-color",n),o.classList.remove("clear"),this._lastColor=this._color.clone(),this._initializingActive||t||this._emit("save",this._color),this}destroy(){cancelAnimationFrame(this._setupAnimationFrame),this._eventBindings.forEach((t=>s(...t))),Object.keys(this._components).forEach((t=>this._components[t].destroy()))}destroyAndRemove(){this.destroy();const{root:t,app:e}=this._root;t.parentElement&&t.parentElement.removeChild(t),e.parentElement.removeChild(e),Object.keys(this).forEach((t=>this[t]=null))}hide(){return!!this.isOpen()&&(this._root.app.classList.remove("visible"),this._emit("hide"),!0)}show(){return!this.options.disabled&&!this.isOpen()&&(this._root.app.classList.add("visible"),this._rePositioningPicker(),this._emit("show",this._color),this)}isOpen(){return this._root.app.classList.contains("visible")}setHSVA(t=360,e=0,o=0,n=1,i=!1){const s=this._recalc;if(this._recalc=!1,t<0||t>360||e<0||e>100||o<0||o>100||n<0||n>1)return!1;this._color=A(t,e,o,n);const{hue:r,opacity:a,palette:l}=this._components;return r.update(t/360),a.update(n),l.update(e/100,1-o/100),i||this.applyColor(),s&&this._updateOutput(),this._recalc=s,!0}setColor(t,e=!1){if(null===t)return this._clearColor(e),!0;const{values:o,type:n}=this._parseLocalColor(t);if(o){const t=n.toUpperCase(),{options:i}=this._root.interaction,s=i.find((e=>e.getAttribute("data-type")===t));if(s&&!s.hidden)for(const t of i)t.classList[t===s?"add":"remove"]("active");return!!this.setHSVA(...o,e)&&this.setColorRepresentation(t)}return!1}setColorRepresentation(t){return t=t.toUpperCase(),!!this._root.interaction.options.find((e=>e.getAttribute("data-type").startsWith(t)&&!e.click()))}getColorRepresentation(){return this._representation}getColor(){return this._color}getSelectedColor(){return this._lastColor}getRoot(){return this._root}disable(){return this.hide(),this.options.disabled=!0,this._root.button.classList.add("disabled"),this}enable(){return this.options.disabled=!1,this._root.button.classList.remove("disabled"),this}}return E(L,"utils",o),E(L,"version","1.8.2"),E(L,"I18N_DEFAULTS",{"ui:dialog":"color picker dialog","btn:toggle":"toggle color picker dialog","btn:swatch":"color swatch","btn:last-color":"use previous color","btn:save":"Save","btn:cancel":"Cancel","btn:clear":"Clear","aria:btn:save":"save and close","aria:btn:cancel":"cancel and close","aria:btn:clear":"clear and close","aria:input":"color input field","aria:palette":"color selection area","aria:hue":"hue selection slider","aria:opacity":"selection slider"}),E(L,"DEFAULT_OPTIONS",{appClass:null,theme:"classic",useAsButton:!1,padding:8,disabled:!1,comparison:!0,closeOnScroll:!1,outputPrecision:0,lockOpacity:!1,autoReposition:!0,container:"body",components:{interaction:{}},i18n:{},swatches:null,inline:!1,sliders:null,default:"#42445a",defaultRepresentation:null,position:"bottom-middle",adjustableNumbers:!0,showAlways:!1,closeWithKey:"Escape"}),E(L,"create",(t=>new L(t))),e=e.default})()}));
let Joystick=(function(cont,dpad,color,auto,exp,callback){let cv=document.getElementById('#'+cont);if(!cv||!cv.parentNode.clientWidth)return;let size=cv.parentNode.clientWidth;let ratio=window.devicePixelRatio;cv.style.width=size+'px';cv.style.height=size+'px';size*=ratio;cv.width=size;cv.height=size;cv.style.cursor='pointer';let cx=cv.getContext("2d");let r=size*0.23;let R=size*0.4;let centerX=size/2;let centerY=size/2;let movedX=centerX;let movedY=centerY;let pressed=0;let dpressed=0;if("ontouchstart"in document.documentElement){cv.addEventListener("touchstart",onTouchStart,false);if(!dpad)document.addEventListener("touchmove",onTouchMove,false);document.addEventListener("touchend",onTouchEnd,false);}else{cv.addEventListener("mousedown",onMouseDown,false);if(!dpad)document.addEventListener("mousemove",onMouseMove,false);document.addEventListener("mouseup",onMouseUp,false);}
function adjust(color,ratio){return'#'+color.replace(/^#/,'').replace(/../g,color=>('0'+Math.min(255,Math.max(0,Math.floor(parseInt(color,16)*(ratio+1)))).toString(16)).substr(-2));}
function constrain(val,min,max){return val<min?min:(val>max?max:val);}
function onTouchStart(event){pressed=1;if(dpad)onTouchMove(event);}
function onTouchMove(event){if(pressed&&event.targetTouches[0].target===cv){movedX=event.targetTouches[0].pageX*ratio;movedY=event.targetTouches[0].pageY*ratio;if(cv.offsetParent.tagName.toUpperCase()==="BODY"){movedX-=cv.offsetLeft*ratio;movedY-=cv.offsetTop*ratio;}else{movedX-=cv.offsetParent.offsetLeft*ratio;movedY-=cv.offsetParent.offsetTop*ratio;}
redraw();}}
function onTouchEnd(event){if(auto||dpad){movedX=centerX;movedY=centerY;redraw();}
if(!event.targetTouches.length)pressed=0;}
function onMouseDown(event){pressed=1;document.body.style.userSelect='none';document.body.style.cursor='pointer';if(dpad)onMouseMove(event);}
function onMouseMove(event){if(pressed){movedX=event.pageX*ratio;movedY=event.pageY*ratio;if(cv.offsetParent.tagName.toUpperCase()==="BODY"){movedX-=cv.offsetLeft*ratio;movedY-=cv.offsetTop*ratio;}else{movedX-=cv.offsetParent.offsetLeft*ratio;movedY-=cv.offsetParent.offsetTop*ratio;}
redraw();}}
function onMouseUp(event){if(auto||dpad){movedX=centerX;movedY=centerY;redraw();}
pressed=0;document.body.style.userSelect='unset';document.body.style.cursor='default';}
function redraw(){cx.clearRect(0,0,size,size);movedX=constrain(movedX,r,size-r);movedY=constrain(movedY,r,size-r);let x=Math.round((movedX-centerX)/(size/2-r)*255);let y=-Math.round((movedY-centerY)/(size/2-r)*255);if(dpad){if(Math.abs(x)<150&&Math.abs(y)<150){x=0,y=0;}else{dpressed=1;if(Math.abs(x)>Math.abs(y))x=Math.sign(x),y=0;else x=0,y=Math.sign(y);}
cx.beginPath();cx.arc(centerX,centerY,R*1.15,0,2*Math.PI,false);cx.lineWidth=R/20;cx.strokeStyle=color;cx.stroke();cx.lineWidth=R/10;let rr=R*0.9;let cw=R/4;let ch=rr-cw;let sh=[[1,0],[-1,0],[0,1],[0,-1]];for(let i=0;i<4;i++){cx.beginPath();cx.strokeStyle=(x==sh[i][0]&&y==-sh[i][1])?adjust(color,0.5):color;cx.moveTo(centerX+ch*sh[i][0]-cw*sh[i][1],centerY+ch*sh[i][1]-cw*sh[i][0]);cx.lineTo(centerX+rr*sh[i][0],centerY+rr*sh[i][1]);cx.lineTo(centerX+ch*sh[i][0]+cw*sh[i][1],centerY+ch*sh[i][1]+cw*sh[i][0]);cx.stroke();}
if(dpressed)callback({x:x,y:y});if(!x&&!y)dpressed=0;}else{cx.beginPath();cx.arc(centerX,centerY,R,0,2*Math.PI,false);let grd=cx.createRadialGradient(centerX,centerY,R*2/3,centerX,centerY,R);grd.addColorStop(0,'#00000005');grd.addColorStop(1,'#00000030');cx.fillStyle=grd;cx.fill();cx.beginPath();cx.arc(movedX,movedY,r,0,2*Math.PI,false);grd=cx.createRadialGradient(movedX,movedY,0,movedX,movedY,r);grd.addColorStop(0,adjust(color,0.4));grd.addColorStop(1,color);cx.fillStyle=grd;cx.fill();if(!pressed)return;if(exp){x=((x*x+255)>>8)*(x>0?1:-1);y=((y*y+255)>>8)*(y>0?1:-1);}
callback({x:x,y:y});}}
redraw();});
